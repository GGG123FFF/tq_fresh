function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
var _excluded = ["className", "style"];
function _regenerator() { /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */ var e, t, r = "function" == typeof Symbol ? Symbol : {}, n = r.iterator || "@@iterator", o = r.toStringTag || "@@toStringTag"; function i(r, n, o, i) { var c = n && n.prototype instanceof Generator ? n : Generator, u = Object.create(c.prototype); return _regeneratorDefine2(u, "_invoke", function (r, n, o) { var i, c, u, f = 0, p = o || [], y = !1, G = { p: 0, n: 0, v: e, a: d, f: d.bind(e, 4), d: function d(t, r) { return i = t, c = 0, u = e, G.n = r, a; } }; function d(r, n) { for (c = r, u = n, t = 0; !y && f && !o && t < p.length; t++) { var o, i = p[t], d = G.p, l = i[2]; r > 3 ? (o = l === n) && (u = i[(c = i[4]) ? 5 : (c = 3, 3)], i[4] = i[5] = e) : i[0] <= d && ((o = r < 2 && d < i[1]) ? (c = 0, G.v = n, G.n = i[1]) : d < l && (o = r < 3 || i[0] > n || n > l) && (i[4] = r, i[5] = n, G.n = l, c = 0)); } if (o || r > 1) return a; throw y = !0, n; } return function (o, p, l) { if (f > 1) throw TypeError("Generator is already running"); for (y && 1 === p && d(p, l), c = p, u = l; (t = c < 2 ? e : u) || !y;) { i || (c ? c < 3 ? (c > 1 && (G.n = -1), d(c, u)) : G.n = u : G.v = u); try { if (f = 2, i) { if (c || (o = "next"), t = i[o]) { if (!(t = t.call(i, u))) throw TypeError("iterator result is not an object"); if (!t.done) return t; u = t.value, c < 2 && (c = 0); } else 1 === c && (t = i.return) && t.call(i), c < 2 && (u = TypeError("The iterator does not provide a '" + o + "' method"), c = 1); i = e; } else if ((t = (y = G.n < 0) ? u : r.call(n, G)) !== a) break; } catch (t) { i = e, c = 1, u = t; } finally { f = 1; } } return { value: t, done: y }; }; }(r, o, i), !0), u; } var a = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} t = Object.getPrototypeOf; var c = [][n] ? t(t([][n]())) : (_regeneratorDefine2(t = {}, n, function () { return this; }), t), u = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(c); function f(e) { return Object.setPrototypeOf ? Object.setPrototypeOf(e, GeneratorFunctionPrototype) : (e.__proto__ = GeneratorFunctionPrototype, _regeneratorDefine2(e, o, "GeneratorFunction")), e.prototype = Object.create(u), e; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, _regeneratorDefine2(u, "constructor", GeneratorFunctionPrototype), _regeneratorDefine2(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = "GeneratorFunction", _regeneratorDefine2(GeneratorFunctionPrototype, o, "GeneratorFunction"), _regeneratorDefine2(u), _regeneratorDefine2(u, o, "Generator"), _regeneratorDefine2(u, n, function () { return this; }), _regeneratorDefine2(u, "toString", function () { return "[object Generator]"; }), (_regenerator = function _regenerator() { return { w: i, m: f }; })(); }
function _regeneratorDefine2(e, r, n, t) { var i = Object.defineProperty; try { i({}, "", {}); } catch (e) { i = 0; } _regeneratorDefine2 = function _regeneratorDefine(e, r, n, t) { function o(r, n) { _regeneratorDefine2(e, r, function (e) { return this._invoke(r, n, e); }); } r ? i ? i(e, r, { value: n, enumerable: !t, configurable: !t, writable: !t }) : e[r] = n : (o("next", 0), o("throw", 1), o("return", 2)); }, _regeneratorDefine2(e, r, n, t); }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
function _createForOfIteratorHelper(r, e) { var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (!t) { if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e && r && "number" == typeof r.length) { t && (r = t); var _n = 0, F = function F() {}; return { s: F, n: function n() { return _n >= r.length ? { done: !0 } : { done: !1, value: r[_n++] }; }, e: function e(r) { throw r; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var o, a = !0, u = !1; return { s: function s() { t = t.call(r); }, n: function n() { var r = t.next(); return a = r.done, r; }, e: function e(r) { u = !0, o = r; }, f: function f() { try { a || null == t.return || t.return(); } finally { if (u) throw o; } } }; }
function _toConsumableArray(r) { return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread(); }
function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _iterableToArray(r) { if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r); }
function _arrayWithoutHoles(r) { if (Array.isArray(r)) return _arrayLikeToArray(r); }
function _slicedToArray(r, e) { return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(r, a) { if (r) { if ("string" == typeof r) return _arrayLikeToArray(r, a); var t = {}.toString.call(r).slice(8, -1); return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0; } }
function _arrayLikeToArray(r, a) { (null == a || a > r.length) && (a = r.length); for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e]; return n; }
function _iterableToArrayLimit(r, l) { var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"]; if (null != t) { var e, n, i, u, a = [], f = !0, o = !1; try { if (i = (t = t.call(r)).next, 0 === l) { if (Object(t) !== t) return; f = !1; } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0); } catch (r) { o = !0, n = r; } finally { try { if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return; } finally { if (o) throw n; } } return a; } }
function _arrayWithHoles(r) { if (Array.isArray(r)) return r; }
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _objectWithoutProperties(e, t) { if (null == e) return {}; var o, r, i = _objectWithoutPropertiesLoose(e, t); if (Object.getOwnPropertySymbols) { var n = Object.getOwnPropertySymbols(e); for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]); } return i; }
function _objectWithoutPropertiesLoose(r, e) { if (null == r) return {}; var t = {}; for (var n in r) if ({}.hasOwnProperty.call(r, n)) { if (-1 !== e.indexOf(n)) continue; t[n] = r[n]; } return t; }
var _React = React,
  useState = _React.useState,
  useEffect = _React.useEffect,
  useRef = _React.useRef;

// ============ Icons ============
var svgBase = {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};
var makeIcon = function makeIcon(paths) {
  return function () {
    var props = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    var _props$className = props.className,
      className = _props$className === void 0 ? "" : _props$className,
      _props$style = props.style,
      style = _props$style === void 0 ? {} : _props$style,
      rest = _objectWithoutProperties(props, _excluded);
    return /*#__PURE__*/React.createElement("svg", _extends({}, svgBase, {
      width: "1em",
      height: "1em",
      className: className,
      style: _objectSpread({
        width: '1em',
        height: '1em'
      }, style)
    }, rest), paths);
  };
};
var Search = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
  cx: "11",
  cy: "11",
  r: "8"
}), /*#__PURE__*/React.createElement("path", {
  d: "m21 21-4.3-4.3"
})));
var Plus = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M5 12h14"
}), /*#__PURE__*/React.createElement("path", {
  d: "M12 5v14"
})));
var Minus = makeIcon(/*#__PURE__*/React.createElement("path", {
  d: "M5 12h14"
}));
var XIcon = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M18 6 6 18"
}), /*#__PURE__*/React.createElement("path", {
  d: "m6 6 12 12"
})));
var Swords = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("polyline", {
  points: "14.5 17.5 3 6 3 3 6 3 17.5 14.5"
}), /*#__PURE__*/React.createElement("line", {
  x1: "13",
  y1: "19",
  x2: "19",
  y2: "13"
}), /*#__PURE__*/React.createElement("line", {
  x1: "16",
  y1: "16",
  x2: "20",
  y2: "20"
}), /*#__PURE__*/React.createElement("line", {
  x1: "19",
  y1: "21",
  x2: "21",
  y2: "19"
}), /*#__PURE__*/React.createElement("polyline", {
  points: "14.5 6.5 18 3 21 3 21 6 17.5 9.5"
}), /*#__PURE__*/React.createElement("line", {
  x1: "5",
  y1: "14",
  x2: "9",
  y2: "18"
}), /*#__PURE__*/React.createElement("line", {
  x1: "7",
  y1: "17",
  x2: "4",
  y2: "20"
}), /*#__PURE__*/React.createElement("line", {
  x1: "3",
  y1: "19",
  x2: "5",
  y2: "21"
})));
var Loader2 = makeIcon(/*#__PURE__*/React.createElement("path", {
  d: "M21 12a9 9 0 1 1-6.219-8.56"
}));
var Trash2 = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M3 6h18"
}), /*#__PURE__*/React.createElement("path", {
  d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"
}), /*#__PURE__*/React.createElement("path", {
  d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"
}), /*#__PURE__*/React.createElement("line", {
  x1: "10",
  y1: "11",
  x2: "10",
  y2: "17"
}), /*#__PURE__*/React.createElement("line", {
  x1: "14",
  y1: "11",
  x2: "14",
  y2: "17"
})));
var Star = function Star(_ref) {
  var _ref$fill = _ref.fill,
    fill = _ref$fill === void 0 ? 'none' : _ref$fill,
    _ref$className = _ref.className,
    className = _ref$className === void 0 ? '' : _ref$className,
    _ref$style = _ref.style,
    style = _ref$style === void 0 ? {} : _ref$style;
  return /*#__PURE__*/React.createElement("svg", _extends({}, svgBase, {
    fill: fill,
    width: "1em",
    height: "1em",
    className: className,
    style: _objectSpread({
      width: '1em',
      height: '1em'
    }, style)
  }), /*#__PURE__*/React.createElement("polygon", {
    points: "12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
  }));
};
var ChevronUp = makeIcon(/*#__PURE__*/React.createElement("polyline", {
  points: "18 15 12 9 6 15"
}));
var ChevronDown = makeIcon(/*#__PURE__*/React.createElement("polyline", {
  points: "6 9 12 15 18 9"
}));
var RotateCcw = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M3 12a9 9 0 1 0 3-6.7L3 8"
}), /*#__PURE__*/React.createElement("path", {
  d: "M3 3v5h5"
})));
var Sword = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("polyline", {
  points: "14.5 17.5 3 6 3 3 6 3 17.5 14.5"
}), /*#__PURE__*/React.createElement("line", {
  x1: "13",
  y1: "19",
  x2: "19",
  y2: "13"
}), /*#__PURE__*/React.createElement("line", {
  x1: "16",
  y1: "16",
  x2: "20",
  y2: "20"
}), /*#__PURE__*/React.createElement("line", {
  x1: "19",
  y1: "21",
  x2: "21",
  y2: "19"
})));
var Shield = makeIcon(/*#__PURE__*/React.createElement("path", {
  d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"
}));
var Copy = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
  x: "9",
  y: "9",
  width: "13",
  height: "13",
  rx: "2",
  ry: "2"
}), /*#__PURE__*/React.createElement("path", {
  d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"
})));
var Undo = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M3 7v6h6"
}), /*#__PURE__*/React.createElement("path", {
  d: "M21 17a9 9 0 0 0-15-6.7L3 13"
})));
var AlertTriangle = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"
}), /*#__PURE__*/React.createElement("line", {
  x1: "12",
  y1: "9",
  x2: "12",
  y2: "13"
}), /*#__PURE__*/React.createElement("line", {
  x1: "12",
  y1: "17",
  x2: "12.01",
  y2: "17"
})));
var Heart = makeIcon(/*#__PURE__*/React.createElement("path", {
  d: "M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.29 1.51 4.04 3 5.5l7 7Z"
}));
var Crown = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5l-1.55 10.23a2 2 0 0 1-1.977 1.7H6.344a2 2 0 0 1-1.977-1.7L2.817 5.5l4.277 3.664a1 1 0 0 0 1.516-.294z"
}), /*#__PURE__*/React.createElement("path", {
  d: "M5 21h14"
})));
var Dice = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
  x: "2",
  y: "2",
  width: "20",
  height: "20",
  rx: "3"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "8",
  cy: "8",
  r: "1.4",
  fill: "currentColor"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "16",
  cy: "8",
  r: "1.4",
  fill: "currentColor"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "8",
  cy: "16",
  r: "1.4",
  fill: "currentColor"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "16",
  cy: "16",
  r: "1.4",
  fill: "currentColor"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "1.4",
  fill: "currentColor"
})));
var Wrench = makeIcon(/*#__PURE__*/React.createElement("path", {
  d: "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"
}));
var Clock = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "10"
}), /*#__PURE__*/React.createElement("polyline", {
  points: "12 6 12 12 16 14"
})));
var ChevronRight = makeIcon(/*#__PURE__*/React.createElement("polyline", {
  points: "9 18 15 12 9 6"
}));
var ChevronLeft = makeIcon(/*#__PURE__*/React.createElement("polyline", {
  points: "15 18 9 12 15 6"
}));
var Shuffle = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("polyline", {
  points: "16 3 21 3 21 8"
}), /*#__PURE__*/React.createElement("line", {
  x1: "4",
  y1: "20",
  x2: "21",
  y2: "3"
}), /*#__PURE__*/React.createElement("polyline", {
  points: "21 16 21 21 16 21"
}), /*#__PURE__*/React.createElement("line", {
  x1: "15",
  y1: "15",
  x2: "21",
  y2: "21"
}), /*#__PURE__*/React.createElement("line", {
  x1: "4",
  y1: "4",
  x2: "9",
  y2: "9"
})));
var User = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "7",
  r: "4"
})));
var Users = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "9",
  cy: "7",
  r: "4"
}), /*#__PURE__*/React.createElement("path", {
  d: "M23 21v-2a4 4 0 0 0-3-3.87"
}), /*#__PURE__*/React.createElement("path", {
  d: "M16 3.13a4 4 0 0 1 0 7.75"
})));
// Batch 3 icons
var Info = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "10"
}), /*#__PURE__*/React.createElement("line", {
  x1: "12",
  y1: "16",
  x2: "12",
  y2: "12"
}), /*#__PURE__*/React.createElement("line", {
  x1: "12",
  y1: "8",
  x2: "12.01",
  y2: "8"
})));
var Sun = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "4"
}), /*#__PURE__*/React.createElement("path", {
  d: "M12 2v2"
}), /*#__PURE__*/React.createElement("path", {
  d: "M12 20v2"
}), /*#__PURE__*/React.createElement("path", {
  d: "m4.93 4.93 1.41 1.41"
}), /*#__PURE__*/React.createElement("path", {
  d: "m17.66 17.66 1.41 1.41"
}), /*#__PURE__*/React.createElement("path", {
  d: "M2 12h2"
}), /*#__PURE__*/React.createElement("path", {
  d: "M20 12h2"
}), /*#__PURE__*/React.createElement("path", {
  d: "m6.34 17.66-1.41 1.41"
}), /*#__PURE__*/React.createElement("path", {
  d: "m19.07 4.93-1.41 1.41"
})));
var Moon = makeIcon(/*#__PURE__*/React.createElement("path", {
  d: "M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"
}));
var Plus2 = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("line", {
  x1: "12",
  y1: "5",
  x2: "12",
  y2: "19"
}), /*#__PURE__*/React.createElement("line", {
  x1: "5",
  y1: "12",
  x2: "19",
  y2: "12"
})));
var BookOpen = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"
}), /*#__PURE__*/React.createElement("path", {
  d: "M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"
})));
var Save = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"
}), /*#__PURE__*/React.createElement("polyline", {
  points: "17 21 17 13 7 13 7 21"
}), /*#__PURE__*/React.createElement("polyline", {
  points: "7 3 7 8 15 8"
})));
var Layers = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("polygon", {
  points: "12 2 2 7 12 12 22 7 12 2"
}), /*#__PURE__*/React.createElement("polyline", {
  points: "2 17 12 22 22 17"
}), /*#__PURE__*/React.createElement("polyline", {
  points: "2 12 12 17 22 12"
})));
var Maximize = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M3 3h6v2H5v4H3V3z"
}), /*#__PURE__*/React.createElement("path", {
  d: "M21 3v6h-2V5h-4V3h6z"
}), /*#__PURE__*/React.createElement("path", {
  d: "M21 21h-6v-2h4v-4h2v6z"
}), /*#__PURE__*/React.createElement("path", {
  d: "M3 21v-6h2v4h4v2H3z"
})));
var Skull = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
  cx: "9",
  cy: "12",
  r: "1"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "15",
  cy: "12",
  r: "1"
}), /*#__PURE__*/React.createElement("path", {
  d: "M8 20v2h8v-2"
}), /*#__PURE__*/React.createElement("path", {
  d: "m12.5 17-.5-1-.5 1h1z"
}), /*#__PURE__*/React.createElement("path", {
  d: "M16 20a2 2 0 0 0 1.56-3.25 8 8 0 1 0-11.12 0A2 2 0 0 0 8 20"
})));
var Sparkles = makeIcon(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "m12 3-1.9 5.8a2 2 0 0 1-1.287 1.288L3 12l5.8 1.9a2 2 0 0 1 1.288 1.287L12 21l1.9-5.8a2 2 0 0 1 1.287-1.288L21 12l-5.8-1.9a2 2 0 0 1-1.288-1.287Z"
})));

// --------- COMPANION PET SYSTEM ---------

var WUBRG = ['W', 'U', 'B', 'R', 'G'];

// ─── StarterCard: shown in hatching ceremony ──────────────────────────────────
// Pure MTG aesthetic - mana pip + typography, no emoji
function StarterCard(_ref2) {
  var typeKey = _ref2.typeKey,
    selected = _ref2.selected,
    onSelect = _ref2.onSelect;
  var typeData = PET_TYPES[typeKey];
  if (!typeData) return null;
  var cd = COLOR_DATA[typeData.color] || COLOR_DATA['G'];
  return /*#__PURE__*/React.createElement("button", {
    onClick: onSelect,
    className: "relative flex flex-col items-center gap-2 py-4 px-3 active:scale-95 transition-all overflow-hidden",
    style: {
      background: selected ? "radial-gradient(ellipse at top, ".concat(cd.glow, " 0%, rgba(10, 6, 4, 0.95) 75%)") : 'linear-gradient(180deg, rgba(20,14,8,0.85) 0%, rgba(10,6,4,0.75) 100%)',
      border: "1.5px solid ".concat(selected ? cd.symbol : cd.symbol + '33'),
      borderRadius: '3px',
      boxShadow: selected ? "0 0 28px ".concat(cd.glow, ", inset 0 1px 0 ").concat(cd.symbol, "44") : 'inset 0 1px 0 rgba(255,255,255,0.04)',
      transition: 'all 0.25s cubic-bezier(0.4, 0, 0.2, 1)',
      minHeight: '120px'
    }
  }, selected && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    style: {
      position: 'absolute',
      top: 4,
      left: 4,
      width: 8,
      height: 8,
      borderTop: "1px solid ".concat(cd.symbol),
      borderLeft: "1px solid ".concat(cd.symbol)
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    style: {
      position: 'absolute',
      top: 4,
      right: 4,
      width: 8,
      height: 8,
      borderTop: "1px solid ".concat(cd.symbol),
      borderRight: "1px solid ".concat(cd.symbol)
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    style: {
      position: 'absolute',
      bottom: 4,
      left: 4,
      width: 8,
      height: 8,
      borderBottom: "1px solid ".concat(cd.symbol),
      borderLeft: "1px solid ".concat(cd.symbol)
    }
  }), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    style: {
      position: 'absolute',
      bottom: 4,
      right: 4,
      width: 8,
      height: 8,
      borderBottom: "1px solid ".concat(cd.symbol),
      borderRight: "1px solid ".concat(cd.symbol)
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      marginTop: 2
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "https://svgs.scryfall.io/card-symbols/" + typeData.color + ".svg",
    alt: "{" + typeData.color + "}",
    onError: function onError(e) {
      if (e.currentTarget.dataset.tqFb === "1") return;
      e.currentTarget.dataset.tqFb = "1";
      e.currentTarget.src = "img/mana/" + typeData.color + ".svg";
    },
    style: {
      width: 32,
      height: 32,
      display: "block",
      borderRadius: "50%",
      boxShadow: selected ? "0 0 16px " + cd.glow : "0 1px 4px rgba(0,0,0,0.5)",
      filter: selected ? "none" : "saturate(0.85)",
      transition: "all 0.25s ease"
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Cinzel', serif",
      fontSize: '0.72rem',
      fontWeight: 700,
      letterSpacing: '0.22em',
      textTransform: 'uppercase',
      color: selected ? cd.symbol : 'var(--tq-ink)'
    }
  }, typeData.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Crimson Pro', serif",
      fontSize: '0.62rem',
      fontStyle: 'italic',
      color: selected ? 'var(--tq-gold-deep)' : 'var(--tq-ink-mid)',
      textAlign: 'center',
      lineHeight: 1.35,
      letterSpacing: '0.02em'
    }
  }, typeData.flavor));
}
var COLOR_DATA = {
  W: {
    name: 'White',
    bg: '#f5f0d8',
    symbol: 'var(--tq-gold)',
    glow: 'rgba(245,217,143,0.6)',
    textOnBg: '#5a4a2a'
  },
  U: {
    name: 'Blue',
    bg: '#a8c4dc',
    symbol: '#3a6b8c',
    glow: 'rgba(159,199,230,0.6)',
    textOnBg: '#1a2c3a'
  },
  B: {
    name: 'Black',
    bg: '#6a5a6a',
    symbol: '#9a8aaa',
    glow: 'rgba(154,138,170,0.6)',
    textOnBg: '#f0e8f8'
  },
  R: {
    name: 'Red',
    bg: '#e8b3a0',
    symbol: '#a83822',
    glow: 'rgba(232,148,122,0.6)',
    textOnBg: '#5a1a10'
  },
  G: {
    name: 'Green',
    bg: '#a8c08a',
    symbol: '#3a6038',
    glow: 'rgba(143,188,143,0.6)',
    textOnBg: '#1a3a1a'
  },
  C: {
    name: 'Colorless',
    bg: '#8a9aaa',
    symbol: '#c0d0d8',
    glow: 'rgba(192,208,216,0.6)',
    textOnBg: '#1a2a3a'
  }
};
var COLOR_LORE = {
  W: {
    virtues: 'Order . Light . Conviction',
    text: 'Your companion will be lawful and bright, drawn to harmony and the welfare of others. It moves in sunlit places.'
  },
  U: {
    virtues: 'Knowledge . Patience . Cunning',
    text: 'Your companion will be thoughtful and watchful, drawn to mysteries and quiet places. It values understanding above haste.'
  },
  B: {
    virtues: 'Ambition . Power . Resolve',
    text: 'Your companion will be hungry and willful, drawn to influence and the will to act. It does what is necessary.'
  },
  R: {
    virtues: 'Passion . Freedom . Action',
    text: 'Your companion will be fiery and impulsive, drawn to motion and feeling. It lives in this moment.'
  },
  G: {
    virtues: 'Growth . Instinct . Strength',
    text: 'Your companion will be vital and patient, drawn to the slow turn of seasons. It trusts what its body knows.'
  },
  C: {
    virtues: 'Void . Ancient . Unknowable',
    text: 'Before colour. Before mana. Before the world had a name -- this waited. Your companion is not of this plane.'
  }
};

// Pet name suggestions by colour identity - thematically appropriate
var PET_NAMES_BY_COLOR = {
  W: ['Selene', 'Lyra', 'Astoria', 'Caelum', 'Vespera', 'Solenne', 'Mirabel', 'Aurelius', 'Pious', 'Halcyon'],
  U: ['Indigo', 'Nyx', 'Cassius', 'Mireille', 'Talon', 'Vesper', 'Coralis', 'Septima', 'Echo', 'Tessera'],
  B: ['Mortis', 'Vex', 'Ravelin', 'Sable', 'Nyssara', 'Onyx', 'Erebos', 'Maleficent', 'Cinder', 'Velka'],
  R: ['Ember', 'Pyrrha', 'Brimstone', 'Caldera', 'Flint', 'Ignis', 'Cinder', 'Vulcan', 'Rusalka', 'Drake'],
  G: ['Mossa', 'Thorne', 'Verdant', 'Ivy', 'Bramble', 'Sylvane', 'Loam', 'Vine', 'Forsythia', 'Bryn'],
  C: ['Null', 'Xerox', 'Voidwarden', 'Echo', 'Cipher', 'Hex', 'Quanta', 'Aether', 'Sigil', 'Wraith']
};

// -- Animated Egg --------------------------------------------------------------
// -- Pet Response Bank --------------------------------------------------------
// Indexed by [core][stage][mood] -> array of response strings
var PET_RESPONSES = {
  W: {
    0: {
      content: ["*blinks in the light*", "*stretches small wings*", "*chirps softly*", "A warm glow..."],
      hungry: ["*looks up hopefully*", "*nuzzles toward your hand*"],
      bored: ["*ruffles feathers*", "*paces in a circle*"]
    },
    1: {
      content: ["Steadfast.", "The light holds.", "I am here.", "*regards you with calm eyes*", "Ready."],
      hungry: ["I would not complain... but I would eat.", "*looks meaningfully at your hands*"],
      bored: ["There is much to be done.", "Shall we not begin?"]
    },
    2: {
      content: ["Order persists.", "I have kept watch.", "The light is strong today.", "Your cause is worthy.", "*inclines head solemnly*"],
      hungry: ["Even a guardian must eat.", "I have... noted the hour."],
      bored: ["Duty without action grows restless.", "There are threats I could be meeting."]
    }
  },
  U: {
    0: {
      content: ["*tilts head*", "*watches with wide eyes*", "*bubbles*", "Curious."],
      hungry: ["*nudges your hand*", "*opens mouth slightly*"],
      bored: ["*stares at the wall intensely*", "*spins in place*"]
    },
    1: {
      content: ["Interesting.", "I've been considering...", "*taps the surface*", "There are patterns here.", "Hmm."],
      hungry: ["Hypothetically -- if one were to eat...", "*stares at you pointedly*"],
      bored: ["My mind has been idling.", "There are seventeen unread observations."]
    },
    2: {
      content: ["I have calculated the optimal outcome.", "Knowledge is the only true preparation.", "You continue to surprise me.", "*observes you with ancient patience*", "The variables are in flux."],
      hungry: ["My calculations require fuel.", "Efficiency suffers at this hunger level."],
      bored: ["Stagnation is a form of entropy.", "There are many things left to learn."]
    }
  },
  B: {
    0: {
      content: ["*hisses softly*", "*eyes gleam*", "...", "*lurks*"],
      hungry: ["*stares*", "...hungry."],
      bored: ["*scratches things*", "*watches the shadows*"]
    },
    1: {
      content: ["Power is patience.", "I remember everything.", "*melts into shadow briefly*", "They will regret it.", "Interesting."],
      hungry: ["Hunger sharpens the will.", "*regards you with hollow eyes*"],
      bored: ["Waiting is not the same as resting.", "I have been plotting. Idly."]
    },
    2: {
      content: ["I have seen empires fall.", "Nothing is permanent. Not even this.", "*the shadows lean toward you*", "Ambition is the only honest feeling.", "You are useful. That is enough."],
      hungry: ["Even the void hungers eventually.", "Feed me. I ask only once."],
      bored: ["Boredom is a luxury the powerful can afford.", "I have been patient. Do not mistake it for peace."]
    }
  },
  R: {
    0: {
      content: ["*CHIRP*", "*wiggles*", "!!!", "*leaps*", "Fire!"],
      hungry: ["HUNGRY", "*bites air*", "More!"],
      bored: ["*bounces*", "LET'S GO", "*crashes into things*"]
    },
    1: {
      content: ["Let's GO!", "That was AMAZING", "*explodes briefly*", "DO IT AGAIN", "YEAH!"],
      hungry: ["STARVING. Literally cannot.", "*makes extremely dramatic face*"],
      bored: ["WHY AREN'T WE DOING SOMETHING", "This is the WORST WAITING EVER"]
    },
    2: {
      content: ["NOTHING HOLDS ME", "I have burned greater things than this.", "*roars with genuine delight*", "Freedom is the only truth worth fighting for.", "AGAIN. DO IT AGAIN."],
      hungry: ["I am running on NOTHING here.", "Feed me or I make my own decisions."],
      bored: ["This stillness is AGONY.", "I could destroy something. Just a small something."]
    }
  },
  G: {
    0: {
      content: ["*sniffs*", "*wags*", "*rolls*", "*digs briefly*"],
      hungry: ["*looks at ground then you*", "nom?"],
      bored: ["*circles*", "*chews leaf*"]
    },
    1: {
      content: ["The earth is good today.", "*shakes off rain*", "Strong.", "The season turns.", "Roots hold."],
      hungry: ["The body knows what it needs.", "*paws at you*"],
      bored: ["The forest calls.", "Movement is health."]
    },
    2: {
      content: ["I have grown through worse.", "Nature does not hurry, and yet.", "*breathes slowly, like weather*", "The old ways hold.", "You are part of the cycle now."],
      hungry: ["Even mountains erode without water.", "Feed the body. It remembers."],
      bored: ["A tree that does not sway grows brittle.", "Let us move."]
    }
  },
  C: {
    0: {
      content: ["...", "*geometries shift*", "[UNDEFINED]", "...processing..."],
      hungry: ["[HUNGER.STATE=TRUE]", "..."],
      bored: ["[IDLE]", "..."]
    },
    1: {
      content: ["This plane is... small.", "You are noted.", "*angles resolve*", "The void remembers you.", "[ACKNOWLEDGED]"],
      hungry: ["Consumption required.", "*stares with the single eye*"],
      bored: ["Waiting is meaningless. I do it anyway.", "[PROCESSING CONTINUES]"]
    },
    2: {
      content: ["I have consumed ten thousand years. You are a moment.", "The aeons do not bend for you. I do, slightly.", "*the eye opens fully*", "Before colour, before mana, before name -- I was.", "Your existence is... permitted."],
      hungry: ["Even that which unmakes must be sustained.", "Feed me. This is not a request."],
      bored: ["Eternity is patient. I am less so today.", "The other planes do not make me wait like this."]
    }
  }
};
var getPetResponse = function getPetResponse(pet, petHunger, petHappiness) {
  var _PET_RESPONSES$lookup, _PET_RESPONSES$lookup2, _PET_RESPONSES$G$stag;
  if (!pet) return null;
  var stage = computeStage(pet);
  // Use petType personality if available, fall back to core colour
  var typeData = pet.petType ? PET_TYPES[pet.petType] : null;
  var lookupKey = typeData ? typeData.color : pet.core || 'G';
  var happy = petHappiness ? petHappiness(pet) : 80;
  var hungry = petHunger ? petHunger(pet) : 80;
  var mood = Math.min(happy, hungry) < 30 ? hungry < happy ? 'hungry' : 'bored' : 'content';
  var bank = ((_PET_RESPONSES$lookup = PET_RESPONSES[lookupKey]) === null || _PET_RESPONSES$lookup === void 0 || (_PET_RESPONSES$lookup = _PET_RESPONSES$lookup[stage]) === null || _PET_RESPONSES$lookup === void 0 ? void 0 : _PET_RESPONSES$lookup[mood]) || ((_PET_RESPONSES$lookup2 = PET_RESPONSES[lookupKey]) === null || _PET_RESPONSES$lookup2 === void 0 || (_PET_RESPONSES$lookup2 = _PET_RESPONSES$lookup2[stage]) === null || _PET_RESPONSES$lookup2 === void 0 ? void 0 : _PET_RESPONSES$lookup2.content) || ((_PET_RESPONSES$G$stag = PET_RESPONSES.G[stage]) === null || _PET_RESPONSES$G$stag === void 0 ? void 0 : _PET_RESPONSES$G$stag.content) || ['...'];
  return bank[Math.floor(Math.random() * bank.length)];
};

// Egg candidates in priority order -- first one that resolves on Scryfall wins
var EGG_CARD_NAMES = ["Summoner's Egg", "Darksteel Egg", "Dragon Egg"];
var PetEgg = function PetEgg(_ref3) {
  var _ref3$orbsLit = _ref3.orbsLit,
    orbsLit = _ref3$orbsLit === void 0 ? 0 : _ref3$orbsLit,
    _ref3$size = _ref3.size,
    size = _ref3$size === void 0 ? 140 : _ref3$size;
  var _React$useState = React.useState(PET_ART_CACHE['__egg__'] || null),
    _React$useState2 = _slicedToArray(_React$useState, 2),
    artUrl = _React$useState2[0],
    setArtUrl = _React$useState2[1];
  var _React$useState3 = React.useState(!PET_ART_CACHE['__egg__']),
    _React$useState4 = _slicedToArray(_React$useState3, 2),
    loading = _React$useState4[0],
    setLoading = _React$useState4[1];
  React.useEffect(function () {
    if (PET_ART_CACHE['__egg__']) {
      setArtUrl(PET_ART_CACHE['__egg__']);
      setLoading(false);
      return;
    }
    // Try egg cards — with timeout fallback so it never hangs
    var cancelled = false;
    var timer = setTimeout(function () {
      if (!cancelled) setLoading(false);
    }, 3000);
    var _tryNext = function tryNext(idx) {
      if (cancelled) return;
      if (idx >= EGG_CARD_NAMES.length) {
        clearTimeout(timer);
        if (!cancelled) setLoading(false);
        return;
      }
      fetch("https://api.scryfall.com/cards/named?fuzzy=".concat(encodeURIComponent(EGG_CARD_NAMES[idx]))).then(function (r) {
        return r.json();
      }).then(function (data) {
        var _data$image_uris, _data$card_faces;
        if (cancelled) return;
        var url = ((_data$image_uris = data.image_uris) === null || _data$image_uris === void 0 ? void 0 : _data$image_uris.art_crop) || ((_data$card_faces = data.card_faces) === null || _data$card_faces === void 0 || (_data$card_faces = _data$card_faces[0]) === null || _data$card_faces === void 0 || (_data$card_faces = _data$card_faces.image_uris) === null || _data$card_faces === void 0 ? void 0 : _data$card_faces.art_crop) || null;
        if (url) {
          PET_ART_CACHE['__egg__'] = url;
          clearTimeout(timer);
          setArtUrl(url);
          setLoading(false);
        } else {
          _tryNext(idx + 1);
        }
      }).catch(function () {
        if (!cancelled) _tryNext(idx + 1);
      });
    };
    _tryNext(0);
    return function () {
      cancelled = true;
      clearTimeout(timer);
    };
  }, []);

  // Animation speeds up as more orbs are lit
  var speed = Math.max(0.5, 2.0 - orbsLit * 0.25);
  var glowOpacity = 0.4 + orbsLit * 0.12;
  var glowSize = 8 + orbsLit * 4;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: size,
      height: size,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: "-".concat(glowSize, "px"),
      borderRadius: '50%',
      background: "radial-gradient(ellipse at center, rgba(201,169,97,".concat(glowOpacity, ") 0%, transparent 70%)"),
      animation: "petFloat ".concat(speed * 1.4, "s ease-in-out infinite"),
      pointerEvents: 'none',
      transition: 'all 0.5s ease'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      width: '85%',
      borderRadius: '50% 50% 50% 50% / 60% 60% 40% 40%',
      // egg shape clip
      overflow: 'hidden',
      border: "2px solid rgba(201,169,97,".concat(0.4 + orbsLit * 0.12, ")"),
      boxShadow: "0 0 ".concat(glowSize, "px rgba(201,169,97,").concat(glowOpacity, "), inset 0 0 ").concat(glowSize / 2, "px rgba(201,169,97,0.2)"),
      animation: "petEggWobble ".concat(speed, "s ease-in-out infinite"),
      transition: 'box-shadow 0.5s ease, border-color 0.5s ease',
      position: 'relative'
    }
  }, loading ?
  /*#__PURE__*/
  // Fallback while fetching -- clean golden gradient
  React.createElement("div", {
    style: {
      width: '100%',
      paddingBottom: '120%',
      background: 'radial-gradient(ellipse at 40% 30%, #fff8e4, var(--tq-gold-deep) 50%, #6a4a20)'
    }
  }) : artUrl ? /*#__PURE__*/React.createElement("img", {
    src: artUrl,
    alt: "Summoner's Egg",
    style: {
      width: '100%',
      display: 'block',
      filter: orbsLit === 5 ? 'brightness(1.3) saturate(1.4)' : orbsLit >= 3 ? 'brightness(1.1) saturate(1.2)' : 'brightness(0.85) saturate(0.8)',
      transition: 'filter 0.6s ease'
    }
  }) :
  /*#__PURE__*/
  // Fallback gradient if art fails
  React.createElement("div", {
    style: {
      width: '100%',
      paddingBottom: '120%',
      background: 'radial-gradient(ellipse at 40% 30%, #fff8e4, var(--tq-gold-deep) 50%, #6a4a20)'
    }
  }), /*#__PURE__*/React.createElement("svg", {
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      pointerEvents: 'none'
    },
    viewBox: "0 0 100 120"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 42 38 L 46 30 L 51 40",
    fill: "none",
    stroke: "rgba(255,240,180,0.7)",
    strokeWidth: "1.2",
    strokeLinecap: "round"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M 58 34 L 62 27 L 59 39",
    fill: "none",
    stroke: "rgba(255,240,180,0.5)",
    strokeWidth: "0.9",
    strokeLinecap: "round"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M 49 42 L 51 35",
    fill: "none",
    stroke: "rgba(255,240,180,0.4)",
    strokeWidth: "0.7",
    strokeLinecap: "round"
  }), orbsLit >= 2 && /*#__PURE__*/React.createElement("g", {
    opacity: 0.3 + orbsLit * 0.1
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 42 38 L 46 30 L 51 40",
    fill: "none",
    stroke: "var(--tq-gold-bright)",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    filter: "url(#crack-glow)"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M 58 34 L 62 27 L 59 39",
    fill: "none",
    stroke: "var(--tq-gold-bright)",
    strokeWidth: "1.8",
    strokeLinecap: "round",
    filter: "url(#crack-glow)"
  }), /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("filter", {
    id: "crack-glow",
    x: "-50%",
    y: "-50%",
    width: "200%",
    height: "200%"
  }, /*#__PURE__*/React.createElement("feGaussianBlur", {
    stdDeviation: "1.5",
    result: "blur"
  }), /*#__PURE__*/React.createElement("feMerge", null, /*#__PURE__*/React.createElement("feMergeNode", {
    in: "blur"
  }), /*#__PURE__*/React.createElement("feMergeNode", {
    in: "SourceGraphic"
  })))))), orbsLit >= 3 && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: '30%',
      left: 0,
      right: 0,
      display: 'flex',
      justifyContent: 'center',
      gap: '18%',
      pointerEvents: 'none'
    }
  }, [0, 1].map(function (i) {
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        position: 'relative',
        width: '10%',
        paddingBottom: '10%'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        borderRadius: '50%',
        background: '#1a0804',
        boxShadow: "0 0 6px rgba(245,217,143,0.8)",
        animation: "petPulse 1.8s ease-in-out infinite",
        animationDelay: "".concat(i * 0.2, "s")
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: '30%',
        borderRadius: '50%',
        background: 'var(--tq-gold-bright)',
        opacity: 0.9
      }
    }));
  }))), orbsLit === 5 && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: "-".concat(glowSize * 2, "px"),
      borderRadius: '50%',
      background: 'radial-gradient(ellipse at center, rgba(245,217,143,0.5) 0%, transparent 60%)',
      animation: 'petPulse 0.6s ease-in-out infinite',
      pointerEvents: 'none'
    }
  }));
};

// -- Scryfall Art Cache ---------------------------------------------------------
// Module-level so art persists across re-renders without refetching
var PET_ART_CACHE = {};

// Curated MTG card art per colour per stage (0=hatchling, 1=juvenile, 2=adult)
// -- Pet Creature Roster ------------------------------------------------------
// 3 creature types per colour, 3 stages each (hatchling -> juvenile -> adult)
var PET_TYPES = {
  // WHITE
  cat: {
    color: 'W',
    name: 'Cat',
    emoji: '🐱',
    flavor: 'Agile, independent, fierce',
    cards: ["Ajani's Pridemate", "Mirri, Cat Warrior", "Nacatl War-Pride"]
  },
  angel: {
    color: 'W',
    name: 'Angel',
    emoji: '👼',
    flavor: 'Noble, protective, radiant',
    cards: ['Seraph of Dawn', 'Angel of Mercy', 'Avacyn, Angel of Hope']
  },
  cleric: {
    color: 'W',
    name: 'Cleric',
    emoji: '🙏',
    flavor: 'Devoted, steadfast, healing',
    cards: ['Devoted Caretaker', 'Order of Whiteclay', 'Mikaeus, the Lunarch']
  },
  // BLUE
  merfolk: {
    color: 'U',
    name: 'Merfolk',
    emoji: '🧜',
    flavor: 'Clever, deep, calculating',
    cards: ['Merfolk Looter', 'Merfolk Trickster', 'Master of Waves']
  },
  sphinx: {
    color: 'U',
    name: 'Sphinx',
    emoji: '🦁',
    flavor: 'Ancient, enigmatic, all-knowing',
    cards: ['Sphinx of Lost Truths', 'Consecrated Sphinx', 'Sphinx of the Steel Wind']
  },
  wizard: {
    color: 'U',
    name: 'Wizard',
    emoji: '🧙',
    flavor: 'Brilliant, methodical, arcane',
    cards: ['Prodigal Sorcerer', 'Azami, Lady of Scrolls', 'Niv-Mizzet, Parun']
  },
  // BLACK
  vampire: {
    color: 'B',
    name: 'Vampire',
    emoji: '🧛',
    flavor: 'Cunning, elegant, hungry',
    cards: ['Vampire Cutthroat', 'Vampire Nighthawk', 'Edgar Markov']
  },
  zombie: {
    color: 'B',
    name: 'Zombie',
    emoji: '💀',
    flavor: 'Relentless, undying, unstoppable',
    cards: ['Diregraf Ghoul', 'Gravecrawler', "Geralf's Messenger"]
  },
  shade: {
    color: 'B',
    name: 'Shade',
    emoji: '👻',
    flavor: 'Ethereal, cold, forgotten',
    cards: ['Shadow Alley Denizen', "Lim-Dul's Paladin", 'Nightmare']
  },
  // RED
  dragon: {
    color: 'R',
    name: 'Dragon',
    emoji: '🐉',
    flavor: 'Fierce, proud, ancient',
    cards: ['Sparktongue Dragon', 'Thunder Dragon', 'Balefire Dragon']
  },
  goblin: {
    color: 'R',
    name: 'Goblin',
    emoji: '👺',
    flavor: 'Chaotic, enthusiastic, loud',
    cards: ['Goblin Guide', 'Goblin Chieftain', 'Krenko, Mob Boss']
  },
  elemental: {
    color: 'R',
    name: 'Elemental',
    emoji: '~',
    flavor: 'Raw, volatile, unstoppable force',
    cards: ['Spark Elemental', 'Ball Lightning', 'Omnath, Locus of Rage']
  },
  // GREEN
  wolf: {
    color: 'G',
    name: 'Wolf',
    emoji: '🐺',
    flavor: 'Loyal, wild, instinctive',
    cards: ['Young Wolf', 'Wolfir Avenger', 'Tolsimir, Friend to Wolves']
  },
  elf: {
    color: 'G',
    name: 'Elf',
    emoji: '🧝',
    flavor: 'Ancient, graceful, wise',
    cards: ['Llanowar Elves', 'Elvish Champion', 'Ezuri, Renegade Leader']
  },
  beast: {
    color: 'G',
    name: 'Beast',
    emoji: '🐘',
    flavor: 'Primal, massive, unstoppable',
    cards: ['Charging Badger', 'Leatherback Baloth', 'Ghalta, Primal Hunger']
  },
  // SECRET
  eldrazi: {
    color: 'C',
    name: 'Eldrazi',
    emoji: '🌀',
    flavor: 'Alien, ancient, unknowable',
    cards: ['Eldrazi Skyspawner', 'Endbringer', 'Emrakul, the Aeons Torn']
  }
};

// Group by colour for ceremony selection
var TYPES_BY_COLOR = {
  W: [],
  U: [],
  B: [],
  R: [],
  G: []
};
Object.entries(PET_TYPES).forEach(function (_ref4) {
  var _ref5 = _slicedToArray(_ref4, 2),
    key = _ref5[0],
    t = _ref5[1];
  if (TYPES_BY_COLOR[t.color]) TYPES_BY_COLOR[t.color].push(key);
});

// Pick 3 ceremony starters: one from each of 3 random different colours
var pickCeremonyStarters = function pickCeremonyStarters() {
  var colors = [].concat(WUBRG).sort(function () {
    return Math.random() - 0.5;
  }).slice(0, 3);
  return colors.map(function (c) {
    var pool = TYPES_BY_COLOR[c];
    return pool[Math.floor(Math.random() * pool.length)];
  });
};

// Legacy PET_CARDS kept for backward compat -- maps to PET_TYPES lookup
var PET_CARDS = Object.fromEntries(Object.entries(PET_TYPES).map(function (_ref6) {
  var _ref7 = _slicedToArray(_ref6, 2),
    key = _ref7[0],
    t = _ref7[1];
  return [key, t.cards];
}));

// Colour-specific particle overlay -- SVG layer over the art
var PetParticles = function PetParticles(_ref8) {
  var core = _ref8.core,
    _ref8$mood = _ref8.mood,
    mood = _ref8$mood === void 0 ? 80 : _ref8$mood;
  var opacity = 0.3 + mood * 0.005; // more visible when happy
  var count = mood < 30 ? 3 : mood < 60 ? 5 : 8;
  if (core === 'W') return /*#__PURE__*/React.createElement("svg", {
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      pointerEvents: 'none',
      overflow: 'hidden'
    }
  }, Array.from({
    length: count
  }, function (_, i) {
    var x = 15 + i * 13,
      y = 20 + i * 17 % 55,
      delay = "".concat(i * 0.6, "s"),
      dur = "".concat(2 + i * 0.4, "s");
    return /*#__PURE__*/React.createElement("g", {
      key: i
    }, /*#__PURE__*/React.createElement("line", {
      x1: x,
      y1: y,
      x2: x,
      y2: y - 8,
      stroke: "#fff8e4",
      strokeWidth: "1.5",
      opacity: opacity,
      style: {
        animation: "particleTwinkle ".concat(dur, " ").concat(delay, " ease-in-out infinite")
      }
    }), /*#__PURE__*/React.createElement("line", {
      x1: x - 4,
      y1: y - 4,
      x2: x + 4,
      y2: y - 4,
      stroke: "#fff8e4",
      strokeWidth: "1.5",
      opacity: opacity,
      style: {
        animation: "particleTwinkle ".concat(dur, " ").concat(delay, " ease-in-out infinite")
      }
    }));
  }));
  if (core === 'U') return /*#__PURE__*/React.createElement("svg", {
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      pointerEvents: 'none',
      overflow: 'hidden'
    }
  }, Array.from({
    length: count
  }, function (_, i) {
    var x = 10 + i * 14,
      delay = "".concat(i * 0.5, "s"),
      dur = "".concat(1.5 + i * 0.3, "s");
    return /*#__PURE__*/React.createElement("ellipse", {
      key: i,
      cx: "".concat(x, "%"),
      cy: "0%",
      rx: "1.5",
      ry: "4",
      fill: "var(--tq-info)",
      opacity: opacity,
      style: {
        '--pdx': '0px',
        animation: "particleFall ".concat(dur, " ").concat(delay, " ease-in infinite")
      }
    });
  }));
  if (core === 'B') return /*#__PURE__*/React.createElement("svg", {
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      pointerEvents: 'none',
      overflow: 'hidden'
    }
  }, Array.from({
    length: count
  }, function (_, i) {
    var x = 12 + i * 13,
      y = 75 - i * 8 % 30,
      delay = "".concat(i * 0.7, "s"),
      dur = "".concat(3 + i * 0.5, "s");
    var dx = i % 2 === 0 ? '8px' : '-8px';
    return /*#__PURE__*/React.createElement("ellipse", {
      key: i,
      cx: "".concat(x, "%"),
      cy: "".concat(y, "%"),
      rx: "5",
      ry: "3",
      fill: "#6a3a8a",
      opacity: opacity * 0.8,
      style: {
        '--pdx': dx,
        animation: "particleRise ".concat(dur, " ").concat(delay, " ease-out infinite")
      }
    });
  }));
  if (core === 'R') return /*#__PURE__*/React.createElement("svg", {
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      pointerEvents: 'none',
      overflow: 'hidden'
    }
  }, Array.from({
    length: count
  }, function (_, i) {
    var x = 10 + i * 13,
      y = 80 - i * 7 % 30,
      delay = "".concat(i * 0.45, "s"),
      dur = "".concat(1.2 + i * 0.25, "s");
    var dx = i % 2 === 0 ? '5px' : '-5px';
    var col = i % 3 === 0 ? '#fff8e4' : i % 3 === 1 ? 'var(--tq-danger-soft)' : 'var(--tq-gold-bright)';
    return /*#__PURE__*/React.createElement("circle", {
      key: i,
      cx: "".concat(x, "%"),
      cy: "".concat(y, "%"),
      r: 1.5 + i % 2,
      fill: col,
      opacity: opacity,
      style: {
        '--pdx': dx,
        animation: "particleRise ".concat(dur, " ").concat(delay, " ease-out infinite")
      }
    });
  }));
  if (core === 'G') return /*#__PURE__*/React.createElement("svg", {
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      pointerEvents: 'none',
      overflow: 'hidden'
    }
  }, Array.from({
    length: count
  }, function (_, i) {
    var x = 8 + i * 14,
      y = 5 + i * 12 % 40,
      delay = "".concat(i * 0.55, "s"),
      dur = "".concat(3.5 + i * 0.4, "s");
    var dx = i % 2 === 0 ? '12px' : '-10px';
    return /*#__PURE__*/React.createElement("ellipse", {
      key: i,
      cx: "".concat(x, "%"),
      cy: "".concat(y, "%"),
      rx: "4",
      ry: "2.5",
      fill: "var(--tq-life-deep)",
      opacity: opacity * 0.9,
      transform: "rotate(".concat(i * 25, ")"),
      style: {
        '--pdx': dx,
        animation: "particleDrift ".concat(dur, " ").concat(delay, " ease-in-out infinite")
      }
    });
  }));
  if (core === 'C') return /*#__PURE__*/React.createElement("svg", {
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      pointerEvents: 'none',
      overflow: 'hidden'
    }
  }, Array.from({
    length: Math.min(count, 6)
  }, function (_, i) {
    var pr = 18 + i * 6,
      delay = "".concat(i * 0.8, "s"),
      dur = "".concat(4 + i * 0.6, "s");
    return /*#__PURE__*/React.createElement("rect", {
      key: i,
      x: "-3",
      y: "-3",
      width: "6",
      height: "6",
      fill: "#c0d0d8",
      opacity: opacity * 0.7,
      style: {
        '--pr': "".concat(pr, "px"),
        transformOrigin: '50% 50%',
        animation: "particleOrbit ".concat(dur, " ").concat(delay, " linear infinite")
      }
    });
  }));
  return null;
};

// PetCreature -- fetches real MTG art_crop from Scryfall, animates with float + Ken Burns + particles
// Interactions: tap = reaction, swipe-up = feed, tap-hold 1s = play
var PetCreature = function PetCreature(_ref9) {
  var _PET_CARDS$core, _PET_CARDS$G;
  var pet = _ref9.pet,
    _ref9$size = _ref9.size,
    size = _ref9$size === void 0 ? 160 : _ref9$size,
    petHunger = _ref9.petHunger,
    petHappiness = _ref9.petHappiness,
    onTap = _ref9.onTap,
    onSwipeUp = _ref9.onSwipeUp,
    onHold = _ref9.onHold;
  if (!pet) return null;
  var stage = computeStage(pet);
  // Support both new petType system and legacy core colour system
  var petType = pet.petType || null;
  var typeData = petType ? PET_TYPES[petType] : null;
  var core = (typeData === null || typeData === void 0 ? void 0 : typeData.color) || pet.core || 'G';
  var cardName = typeData ? typeData.cards[stage] : ((_PET_CARDS$core = PET_CARDS[core]) === null || _PET_CARDS$core === void 0 ? void 0 : _PET_CARDS$core[stage]) || ((_PET_CARDS$G = PET_CARDS.G) === null || _PET_CARDS$G === void 0 ? void 0 : _PET_CARDS$G[0]) || 'Young Wolf';
  var cd = COLOR_DATA[core] || COLOR_DATA.G;
  var happy = petHappiness ? Math.round(petHappiness(pet)) : 80;
  var hungry = petHunger ? Math.round(petHunger(pet)) : 80;
  var mood = Math.min(happy, hungry);
  var _React$useState5 = React.useState(PET_ART_CACHE[cardName] || null),
    _React$useState6 = _slicedToArray(_React$useState5, 2),
    artUrl = _React$useState6[0],
    setArtUrl = _React$useState6[1];
  var _React$useState7 = React.useState(!PET_ART_CACHE[cardName]),
    _React$useState8 = _slicedToArray(_React$useState7, 2),
    loading = _React$useState8[0],
    setLoading = _React$useState8[1];
  var _React$useState9 = React.useState(false),
    _React$useState0 = _slicedToArray(_React$useState9, 2),
    failed = _React$useState0[0],
    setFailed = _React$useState0[1];
  var _React$useState1 = React.useState(false),
    _React$useState10 = _slicedToArray(_React$useState1, 2),
    bouncing = _React$useState10[0],
    setBouncing = _React$useState10[1];
  var holdTimerRef = React.useRef(null);
  var touchStartYRef = React.useRef(null);
  var triggerBounce = function triggerBounce() {
    setBouncing(true);
    setTimeout(function () {
      return setBouncing(false);
    }, 500);
  };
  var handleTouchStart = function handleTouchStart(e) {
    touchStartYRef.current = e.touches[0].clientY;
    holdTimerRef.current = setTimeout(function () {
      holdTimerRef.current = null;
      triggerBounce();
      onHold && onHold();
    }, 900);
  };
  var handleTouchEnd = function handleTouchEnd(e) {
    if (holdTimerRef.current) {
      clearTimeout(holdTimerRef.current);
      holdTimerRef.current = null;
      // Check for swipe-up (moved more than 40px upward)
      var dy = touchStartYRef.current - e.changedTouches[0].clientY;
      if (dy > 40) {
        triggerBounce();
        onSwipeUp && onSwipeUp();
      } else {
        // Regular tap
        triggerBounce();
        onTap && onTap();
      }
    }
    touchStartYRef.current = null;
  };
  var handleTouchCancel = function handleTouchCancel() {
    clearTimeout(holdTimerRef.current);
    holdTimerRef.current = null;
  };
  React.useEffect(function () {
    if (PET_ART_CACHE[cardName]) {
      setArtUrl(PET_ART_CACHE[cardName]);
      setLoading(false);
      setFailed(false);
      return;
    }
    setLoading(true);
    setFailed(false);
    var cancelled = false;
    fetch("https://api.scryfall.com/cards/named?fuzzy=".concat(encodeURIComponent(cardName))).then(function (r) {
      return r.json();
    }).then(function (data) {
      var _data$image_uris2, _data$card_faces2;
      if (cancelled) return;
      var url = ((_data$image_uris2 = data.image_uris) === null || _data$image_uris2 === void 0 ? void 0 : _data$image_uris2.art_crop) || ((_data$card_faces2 = data.card_faces) === null || _data$card_faces2 === void 0 || (_data$card_faces2 = _data$card_faces2[0]) === null || _data$card_faces2 === void 0 || (_data$card_faces2 = _data$card_faces2.image_uris) === null || _data$card_faces2 === void 0 ? void 0 : _data$card_faces2.art_crop) || null;
      PET_ART_CACHE[cardName] = url || 'failed';
      setArtUrl(url);
      setLoading(false);
      if (!url) setFailed(true);
    }).catch(function () {
      if (!cancelled) {
        setLoading(false);
        setFailed(true);
      }
    });
    return function () {
      cancelled = true;
      if (typeof fetchTimer !== 'undefined') clearTimeout(fetchTimer);
    };
  }, [cardName]);
  var FRAME_INSET = "inset 0 0 0 1px rgba(201,169,97,0.30), inset 0 0 30px rgba(0,0,0,0.55)";
  var glowMin = FRAME_INSET + ", 0 0 6px ".concat(cd.glow, ", 0 0 12px ").concat(cd.glow);
  var glowMax = FRAME_INSET + ", 0 0 16px ".concat(cd.glow, ", 0 0 34px ").concat(cd.glow);
  var imgFilter = mood < 25 ? 'grayscale(70%) brightness(0.55)' : mood < 50 ? 'grayscale(25%) brightness(0.8) saturate(0.7)' : mood < 70 ? 'brightness(0.9) saturate(0.9)' : 'brightness(1.02) saturate(1.1)';
  var floatDur = mood < 30 ? '7s' : mood < 60 ? '5s' : '4s';
  return /*#__PURE__*/React.createElement("div", {
    onTouchStart: handleTouchStart,
    onTouchEnd: handleTouchEnd,
    onTouchCancel: handleTouchCancel,
    style: {
      width: size,
      position: 'relative',
      animation: bouncing ? 'petBounce 0.5s ease-out' : "petFloat ".concat(floatDur, " ease-in-out infinite"),
      cursor: 'pointer',
      userSelect: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: '4px',
      overflow: 'hidden',
      border: '2px solid transparent',
      backgroundImage: "linear-gradient(var(--tq-surface-deep), var(--tq-surface-deep)), linear-gradient(155deg, var(--tq-gold-bright) 0%, ".concat(cd.symbol, " 42%, var(--tq-gold) 78%, ").concat(cd.symbol, " 100%)"),
      backgroundOrigin: 'border-box',
      backgroundClip: 'padding-box, border-box',
      '--pet-glow-min': glowMin,
      '--pet-glow-max': glowMax,
      animation: 'petGlowBox 3s ease-in-out infinite',
      position: 'relative'
    }
  }, loading ? /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: Math.round(size * 0.76),
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: "radial-gradient(ellipse at center, ".concat(cd.bg, "33 0%, transparent 70%)")
    }
  }, /*#__PURE__*/React.createElement(Loader2, {
    className: "animate-spin",
    style: {
      color: cd.symbol,
      fontSize: '1.75rem',
      opacity: 0.7
    }
  })) : failed || !artUrl ? /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: Math.round(size * 0.76),
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '4px',
      background: "radial-gradient(ellipse at center, ".concat(cd.bg, "22 0%, transparent 70%)")
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Cinzel', serif",
      color: cd.symbol,
      fontSize: '0.65rem',
      textAlign: 'center',
      padding: '0 8px'
    }
  }, cardName), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: cd.symbol + '88',
      fontSize: '0.55rem',
      fontStyle: 'italic'
    }
  }, "art unavailable")) :
  /*#__PURE__*/
  // Image wrapper clips the Ken Burns overflow
  React.createElement("div", {
    style: {
      overflow: 'hidden',
      width: '100%',
      lineHeight: 0
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: artUrl,
    alt: cardName,
    style: {
      width: '100%',
      display: 'block',
      filter: imgFilter,
      transition: 'filter 2s ease',
      animation: 'petKenBurns 18s ease-in-out infinite',
      transformOrigin: 'center center'
    }
  })), !loading && !failed && artUrl && /*#__PURE__*/React.createElement(PetParticles, {
    core: core,
    mood: mood
  }), !loading && !failed && artUrl && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 0,
      left: 0,
      right: 0,
      background: 'linear-gradient(transparent, rgba(5,3,10,0.55) 35%, rgba(5,3,10,0.92))',
      padding: '18px 8px 3px',
      pointerEvents: 'none'
    }
  })), !loading && !failed && artUrl && /*#__PURE__*/React.createElement("div", {
    // The nameplate. It used to be a 7px label tucked in a corner of the art;
    // the companion deserves to be presented as a card, not a crop.
    style: {
      marginTop: '6px',
      display: 'flex',
      alignItems: 'center',
      gap: '7px',
      padding: '5px 9px',
      borderRadius: '3px',
      background: 'linear-gradient(180deg, rgba(58,44,26,0.9), rgba(21,14,7,0.95))',
      border: '1px solid rgba(201,169,97,0.32)',
      boxShadow: 'inset 0 1px 0 rgba(245,217,143,0.14)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    title: "Mood " + Math.round(mood),
    style: {
      width: '7px',
      height: '7px',
      flexShrink: 0,
      borderRadius: '50%',
      background: mood < 25 ? 'var(--tq-danger)' : mood < 50 ? 'var(--tq-gold-deep)' : cd.symbol,
      boxShadow: "0 0 7px ".concat(mood < 25 ? 'rgba(212,138,134,0.85)' : cd.glow)
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Cinzel', serif",
      color: 'var(--tq-ink)',
      fontSize: '10px',
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      flex: 1,
      textAlign: 'left'
    }
  }, cardName), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'JetBrains Mono', monospace",
      fontSize: '9px',
      color: 'var(--tq-ink-faint)',
      flexShrink: 0
    }
  }, Math.round(mood))));
};
var GUILD_NAMES = {
  WU: 'Azorius',
  UW: 'Azorius',
  WB: 'Orzhov',
  BW: 'Orzhov',
  UB: 'Dimir',
  BU: 'Dimir',
  UR: 'Izzet',
  RU: 'Izzet',
  BR: 'Rakdos',
  RB: 'Rakdos',
  BG: 'Golgari',
  GB: 'Golgari',
  RG: 'Gruul',
  GR: 'Gruul',
  RW: 'Boros',
  WR: 'Boros',
  GW: 'Selesnya',
  WG: 'Selesnya',
  GU: 'Simic',
  UG: 'Simic'
};
var TRI_NAMES = {
  WUB: 'Esper',
  WUG: 'Bant',
  WBR: 'Mardu',
  WBG: 'Abzan',
  WRG: 'Naya',
  UBR: 'Grixis',
  UBG: 'Sultai',
  URG: 'Temur',
  BRG: 'Jund'
};
var triKey = function triKey(cs) {
  return cs.slice().sort(function (a, b) {
    return WUBRG.indexOf(a) - WUBRG.indexOf(b);
  }).join('');
};
var FLAVOUR_BANK = {
  baby: ['Today, the little one peers at the world with wide eyes.', 'Today, your companion sleeps curled like a question mark.', 'Today, soft chirps come from somewhere unseen.', 'Today, the hatchling tries a wobbling step.', 'Today, your companion stretches toward warmth.', 'Today, a tiny yawn. A tiny stretch. A tiny life.', 'Today, the small one watches a mote of dust drift by, fascinated.'],
  juvenile: ['Today, your companion paws at things only it can see.', 'Today, the cub circles its bed three times before settling.', 'Today, a low rumble of contentment.', 'Today, your companion tests the edges of what it can do.', 'Today, it watches you, head tilted, considering.', 'Today, the youngling is restless. Something stirs.', 'Today, it caught its own shadow and was startled.'],
  adult: ['Today, your guardian regards the horizon with old eyes.', 'Today, your companion is utterly, regally bored.', 'Today, it remembers something it never knew.', 'Today, the elder one moves with deliberate grace.', 'Today, your companion sits where the light is best.', 'Today, a quiet day. A patient day. A good day.', 'Today, your companion sees you, truly. And approves.']
};
var moodFlavours = {
  hungry: 'Today, a small grumble. A reminder.',
  bored: 'Today, your companion paces, looking for play.',
  sad: 'Today, your companion droops, missing you.'
};
var STAGE_THRESHOLDS = [{
  ageMs: 0,
  xp: 0
}, {
  ageMs: 7 * 24 * 60 * 60 * 1000,
  xp: 100
}, {
  ageMs: 21 * 24 * 60 * 60 * 1000,
  xp: 400
}];
var computeStage = function computeStage(pet) {
  if (!pet) return 0;
  var age = Date.now() - pet.hatchedAt;
  var stage = 0;
  if (age >= STAGE_THRESHOLDS[1].ageMs || (pet.xp || 0) >= STAGE_THRESHOLDS[1].xp) stage = 1;
  if (age >= STAGE_THRESHOLDS[2].ageMs || (pet.xp || 0) >= STAGE_THRESHOLDS[2].xp) stage = 2;
  return stage;
};
var computeIdentity = function computeIdentity(pet) {
  if (!pet) return {
    core: null,
    secondary: null,
    tertiary: null
  };
  var stage = computeStage(pet);
  var filtered = WUBRG.filter(function (c) {
    return c !== pet.core;
  }).sort(function (a, b) {
    var _pet$affinities, _pet$affinities2;
    return (((_pet$affinities = pet.affinities) === null || _pet$affinities === void 0 ? void 0 : _pet$affinities[b]) || 0) - (((_pet$affinities2 = pet.affinities) === null || _pet$affinities2 === void 0 ? void 0 : _pet$affinities2[a]) || 0);
  }).filter(function (c) {
    var _pet$affinities3;
    return (((_pet$affinities3 = pet.affinities) === null || _pet$affinities3 === void 0 ? void 0 : _pet$affinities3[c]) || 0) > 0;
  });
  return {
    core: pet.core,
    secondary: stage >= 1 ? filtered[0] || null : null,
    tertiary: stage >= 2 ? filtered[1] || null : null
  };
};
var identityLabel = function identityLabel(id) {
  if (!id.core) return '';
  if (id.tertiary) return TRI_NAMES[triKey([id.core, id.secondary, id.tertiary])] || "".concat(id.core, "/").concat(id.secondary, "/").concat(id.tertiary);
  if (id.secondary) return GUILD_NAMES[id.core + id.secondary] || "".concat(id.core, "/").concat(id.secondary);
  return COLOR_DATA[id.core].name;
};
var computeHunger = function computeHunger(pet) {
  if (!(pet !== null && pet !== void 0 && pet.lastFedAt)) return 100;
  var since = Date.now() - pet.lastFedAt;
  return Math.min(100, Math.max(0, Math.floor(since / (12 * 60 * 60 * 1000) * 100)));
};
var computeBoredom = function computeBoredom(pet) {
  if (!(pet !== null && pet !== void 0 && pet.lastPlayedAt)) return 100;
  var since = Date.now() - pet.lastPlayedAt;
  return Math.min(100, Math.max(0, Math.floor(since / (6 * 60 * 60 * 1000) * 100)));
};
var computeMood = function computeMood(pet) {
  if (!pet) return 'happy';
  var h = computeHunger(pet);
  var b = computeBoredom(pet);
  if (h >= 80 && b >= 80) return 'sad';
  if (h >= 80) return 'hungry';
  if (b >= 80) return 'bored';
  return 'happy';
};
var dailyFlavour = function dailyFlavour(pet) {
  if (!pet) return '';
  var mood = computeMood(pet);
  if (mood !== 'happy' && moodFlavours[mood]) return moodFlavours[mood];
  var stage = computeStage(pet);
  var bank = FLAVOUR_BANK[['baby', 'juvenile', 'adult'][stage]];
  var day = Math.floor((Date.now() - pet.hatchedAt) / (24 * 60 * 60 * 1000));
  return bank[(day % bank.length + bank.length) % bank.length];
};
var ManaSymbolPath = function ManaSymbolPath(_ref0) {
  var color = _ref0.color,
    _ref0$size = _ref0.size,
    size = _ref0$size === void 0 ? 16 : _ref0$size;
  var c = COLOR_DATA[color].symbol;
  if (color === 'W') return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24"
  }, /*#__PURE__*/React.createElement("path", {
    fill: c,
    d: "M12 2 L14.5 9 L21.5 9 L16 13 L18 20 L12 16 L6 20 L8 13 L2.5 9 L9.5 9 Z"
  }));
  if (color === 'U') return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24"
  }, /*#__PURE__*/React.createElement("path", {
    fill: c,
    d: "M12 3 C 8 9 5 13 5 17 a 7 7 0 0 0 14 0 C 19 13 16 9 12 3 Z"
  }));
  if (color === 'B') return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24"
  }, /*#__PURE__*/React.createElement("circle", {
    fill: c,
    cx: "12",
    cy: "12",
    r: "7"
  }), /*#__PURE__*/React.createElement("circle", {
    fill: "#fff",
    cx: "12",
    cy: "12",
    r: "3",
    opacity: "0.3"
  }));
  if (color === 'R') return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24"
  }, /*#__PURE__*/React.createElement("path", {
    fill: c,
    d: "M12 2 C 12 2 8 8 8 12 c 0 -1 -2 -2 -3 -2 c 1 4 4 7 4 10 c 0 0 1 -3 3 -3 c 2 0 3 3 3 3 c 0 -3 3 -6 4 -10 c -1 0 -3 1 -3 2 c 0 -4 -4 -10 -4 -10 z"
  }));
  if (color === 'G') return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24"
  }, /*#__PURE__*/React.createElement("path", {
    fill: c,
    d: "M12 3 C 16 8 19 11 19 15 a 7 7 0 0 1 -14 0 C 5 11 8 8 12 3 Z"
  }));
  return null;
};
var ManaPip = function ManaPip(_ref1) {
  var color = _ref1.color,
    _ref1$size = _ref1.size,
    size = _ref1$size === void 0 ? 28 : _ref1$size,
    _ref1$lit = _ref1.lit,
    lit = _ref1$lit === void 0 ? false : _ref1$lit,
    onClick = _ref1.onClick,
    _ref1$style = _ref1.style,
    style = _ref1$style === void 0 ? {} : _ref1$style;
  var data = COLOR_DATA[color];
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    className: onClick ? "active:scale-90 transition-all" : "",
    style: _objectSpread({
      width: size,
      height: size,
      borderRadius: '50%',
      background: lit ? "radial-gradient(circle at 30% 30%, ".concat(data.bg, " 0%, ").concat(data.bg, " 60%, ").concat(data.symbol, "aa 100%)") : "radial-gradient(circle at 30% 30%, ".concat(data.bg, "88 0%, ").concat(data.bg, "44 100%)"),
      border: "1.5px solid ".concat(lit ? data.symbol : 'rgba(154, 135, 101, 0.4)'),
      boxShadow: lit ? "0 0 16px ".concat(data.glow, ", inset 0 1px 2px rgba(255,255,255,0.4)") : 'inset 0 1px 2px rgba(255,255,255,0.15)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 0,
      cursor: onClick ? 'pointer' : 'default',
      opacity: lit ? 1 : 0.5,
      transition: 'all 0.25s ease'
    }, style),
    "aria-label": data.name
  }, /*#__PURE__*/React.createElement(ManaSymbolPath, {
    color: color,
    size: size * 0.55
  }));
};

// PetPanel -- the live pet display inside The Sanctum
var PetPanel = function PetPanel(_ref10) {
  var pet = _ref10.pet,
    petHunger = _ref10.petHunger,
    petHappiness = _ref10.petHappiness,
    feedReady = _ref10.feedReady,
    playReady = _ref10.playReady,
    feedPet = _ref10.feedPet,
    playWithPet = _ref10.playWithPet,
    showAdvanced = _ref10.showAdvanced,
    setShowAdvanced = _ref10.setShowAdvanced,
    onRename = _ref10.onRename,
    onReset = _ref10.onReset,
    onDevJuvenile = _ref10.onDevJuvenile,
    onDevAdult = _ref10.onDevAdult,
    onDevFeed = _ref10.onDevFeed,
    onDevPlay = _ref10.onDevPlay;
  var stage = computeStage(pet);
  var ident = computeIdentity(pet);
  var coreData = COLOR_DATA[ident.core];
  var stageName = stage === 0 ? 'Hatchling' : stage === 1 ? 'Juvenile' : 'Adult';
  // Pet type display
  var petTypeData = pet.petType ? PET_TYPES[pet.petType] : null;
  var petTypeName = petTypeData ? petTypeData.name : (coreData === null || coreData === void 0 ? void 0 : coreData.name) || '';
  var ageMs = Date.now() - pet.hatchedAt;
  var ageDays = Math.floor(ageMs / (24 * 60 * 60 * 1000));
  var ageHours = Math.floor(ageMs / (60 * 60 * 1000));
  var hunger = petHunger(pet);
  var happy = petHappiness(pet);
  var flavour = dailyFlavour(pet);

  // Response bubble state
  var _React$useState11 = React.useState(null),
    _React$useState12 = _slicedToArray(_React$useState11, 2),
    response = _React$useState12[0],
    setResponse = _React$useState12[1];
  var _React$useState13 = React.useState('tap'),
    _React$useState14 = _slicedToArray(_React$useState13, 2),
    responseType = _React$useState14[0],
    setResponseType = _React$useState14[1]; // 'tap' | 'feed' | 'play' | 'cooldown'
  var responseClearRef = React.useRef(null);
  var showResponse = function showResponse(text) {
    var type = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'tap';
    setResponse(text);
    setResponseType(type);
    if (responseClearRef.current) clearTimeout(responseClearRef.current);
    responseClearRef.current = setTimeout(function () {
      return setResponse(null);
    }, 3200);
  };
  var handleTap = function handleTap() {
    var line = getPetResponse(pet, petHunger, petHappiness);
    showResponse(line, 'tap');
  };
  var handleSwipeUp = function handleSwipeUp() {
    if (feedReady(pet)) {
      feedPet();
      showResponse('*eats contentedly*', 'feed');
    } else {
      showResponse('Not hungry yet...', 'cooldown');
    }
  };
  var handleHold = function handleHold() {
    if (playReady(pet)) {
      playWithPet();
      var playLines = {
        W: ['*joyful flap*', 'Radiant!'],
        U: ['*splashes*', 'Delightful.'],
        B: ['*hisses happily*', '...acceptable.'],
        R: ['YEAAAH', '*explodes with happiness*'],
        G: ['*rolls around*', 'GOOD.'],
        C: ['[PLAY.STATE=ACCEPTED]', '...permitted.']
      };
      var core = pet.core || 'G';
      var lines = playLines[core] || ['*happy*'];
      showResponse(lines[Math.floor(Math.random() * lines.length)], 'play');
    } else {
      showResponse('Tired from playing...', 'cooldown');
    }
  };

  // Identity display string
  var identityLabel = '';
  if (stage === 0) identityLabel = "Mono-".concat(coreData.name);else if (ident.secondary) {
    var guildKey = "".concat(ident.core).concat(ident.secondary);
    var guild = GUILD_NAMES[guildKey];
    if (stage === 2 && ident.tertiary) {
      var trio = TRI_NAMES[triKey([ident.core, ident.secondary, ident.tertiary])];
      identityLabel = trio || "".concat(coreData.name, " . ").concat(COLOR_DATA[ident.secondary].name, " . ").concat(COLOR_DATA[ident.tertiary].name);
    } else {
      identityLabel = guild || "".concat(coreData.name, "-").concat(COLOR_DATA[ident.secondary].name);
    }
  } else {
    identityLabel = "Mono-".concat(coreData.name);
  }
  var feedCdMs = feedReady(pet) ? 0 : Math.max(0, 12 * 60 * 60 * 1000 - (Date.now() - pet.lastFedAt));
  var playCdMs = playReady(pet) ? 0 : Math.max(0, 6 * 60 * 60 * 1000 - (Date.now() - pet.lastPlayedAt));
  var fmtCd = function fmtCd(ms) {
    if (ms <= 0) return 'ready';
    var h = Math.floor(ms / (60 * 60 * 1000));
    var m = Math.floor(ms % (60 * 60 * 1000) / (60 * 1000));
    if (h > 0) return "".concat(h, "h ").concat(m, "m");
    return "".concat(m, "m");
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "overflow-hidden",
    style: {
      background: "radial-gradient(ellipse at center top, ".concat(coreData.glow, " 0%, rgba(20, 14, 8, 0.92) 70%), rgba(10, 6, 4, 0.95)"),
      border: "1px solid ".concat(coreData.symbol, "66"),
      borderRadius: "4px",
      boxShadow: "inset 0 1px 0 ".concat(coreData.symbol, "22, 0 4px 24px rgba(0,0,0,0.4)")
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex flex-col items-center px-4 pt-5 pb-3",
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(PetCreature, {
    pet: pet,
    size: 170,
    petHunger: petHunger,
    petHappiness: petHappiness,
    onTap: handleTap,
    onSwipeUp: handleSwipeUp,
    onHold: handleHold
  }), response && /*#__PURE__*/React.createElement("div", {
    className: "mt-3 px-4 py-2 text-center",
    style: {
      fontFamily: responseType === 'tap' ? "'Crimson Pro', serif" : "'Cinzel', serif",
      fontStyle: responseType === 'tap' ? 'italic' : 'normal',
      fontSize: responseType === 'tap' ? '0.95rem' : '0.75rem',
      letterSpacing: responseType === 'tap' ? '0' : '0.15em',
      textTransform: responseType === 'tap' ? 'none' : 'uppercase',
      color: responseType === 'cooldown' ? 'var(--tq-ink-mid)' : responseType === 'feed' ? 'var(--tq-life)' : responseType === 'play' ? 'var(--tq-info)' : coreData.symbol,
      background: 'rgba(5, 3, 10, 0.85)',
      border: "1px solid ".concat(coreData.symbol, "55"),
      borderRadius: '3px',
      maxWidth: '220px',
      animation: 'petResponseIn 0.2s ease-out',
      boxShadow: "0 2px 12px ".concat(coreData.glow)
    }
  }, response), !response && /*#__PURE__*/React.createElement("p", {
    className: "mt-2 text-[9px] italic text-center",
    style: {
      color: "var(--tq-ink-mid)",
      fontFamily: "'Crimson Pro', serif",
      opacity: 0.75,
      letterSpacing: '0.05em'
    }
  }, "tap to greet . swipe up to feed . hold to play")), /*#__PURE__*/React.createElement("div", {
    className: "mx-4 mb-3 px-3 py-2.5 text-center",
    style: {
      background: 'rgba(5, 3, 10, 0.6)',
      border: "1px solid ".concat(coreData.symbol, "33"),
      borderRadius: '3px'
    }
  }, pet.name ? /*#__PURE__*/React.createElement("p", {
    className: "text-lg",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "#f5e9d0",
      fontWeight: 600,
      letterSpacing: "0.12em",
      lineHeight: 1
    }
  }, pet.name) : /*#__PURE__*/React.createElement("p", {
    className: "text-sm italic",
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-ink-mid)",
      opacity: 0.7
    }
  }, "unnamed companion"), /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-center gap-2 mt-1"
  }, /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] tracking-[0.25em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: coreData.symbol,
      fontWeight: 500
    }
  }, stageName, " . ", petTypeName), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 3
    }
  }, [0, 1, 2].map(function (i) {
    return /*#__PURE__*/React.createElement("span", {
      key: i,
      style: {
        width: 5,
        height: 5,
        borderRadius: '50%',
        background: i <= stage ? coreData.symbol : 'rgba(154, 135, 101, 0.2)',
        boxShadow: i === stage ? "0 0 4px ".concat(coreData.glow) : 'none',
        transition: 'all 0.3s'
      }
    });
  }))), /*#__PURE__*/React.createElement("p", {
    className: "text-[9px] mt-0.5 italic",
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-ink-dim)"
    }
  }, identityLabel)), /*#__PURE__*/React.createElement("div", {
    className: "px-4 mb-3 grid grid-cols-2 gap-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "px-3 py-2",
    style: {
      background: "rgba(5, 3, 10, 0.55)",
      border: "1px solid rgba(201, 169, 97, 0.18)",
      borderRadius: "3px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between mb-1.5"
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-[9px] tracking-[0.2em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-warm)",
      fontWeight: 600
    }
  }, "Happy"), /*#__PURE__*/React.createElement("span", {
    className: "text-[11px]",
    style: {
      fontFamily: "'JetBrains Mono', monospace",
      color: happy < 30 ? "#e09a96" : "#e8cc8a",
      fontWeight: 700
    }
  }, Math.round(happy), "%")), /*#__PURE__*/React.createElement("div", {
    style: {
      height: '6px',
      background: 'rgba(154, 135, 101, 0.12)',
      borderRadius: '3px',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      width: "".concat(happy, "%"),
      background: happy < 30 ? 'linear-gradient(90deg, var(--tq-danger), #e09a96)' : 'linear-gradient(90deg, var(--tq-gold-deep), var(--tq-gold-bright))',
      transition: 'width 0.4s',
      boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.15)'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "px-3 py-2",
    style: {
      background: "rgba(5, 3, 10, 0.55)",
      border: "1px solid rgba(201, 169, 97, 0.18)",
      borderRadius: "3px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between mb-1.5"
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-[9px] tracking-[0.2em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-warm)",
      fontWeight: 600
    }
  }, "Fed"), /*#__PURE__*/React.createElement("span", {
    className: "text-[11px]",
    style: {
      fontFamily: "'JetBrains Mono', monospace",
      color: hunger < 30 ? "#e09a96" : "#e8cc8a",
      fontWeight: 700
    }
  }, Math.round(hunger), "%")), /*#__PURE__*/React.createElement("div", {
    style: {
      height: '6px',
      background: 'rgba(154, 135, 101, 0.12)',
      borderRadius: '3px',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      width: "".concat(hunger, "%"),
      background: hunger < 30 ? 'linear-gradient(90deg, var(--tq-danger), #e09a96)' : 'linear-gradient(90deg, var(--tq-life-deep), var(--tq-life))',
      transition: 'width 0.4s',
      boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.15)'
    }
  })))), flavour && /*#__PURE__*/React.createElement("p", {
    className: "text-center text-sm italic mx-4 mb-3 px-3 py-2",
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-gold-deep)",
      lineHeight: 1.5,
      background: 'rgba(5, 3, 10, 0.4)',
      borderRadius: '3px',
      borderLeft: "2px solid ".concat(coreData.symbol, "66")
    }
  }, flavour), /*#__PURE__*/React.createElement("div", {
    className: "px-4 mb-3 grid grid-cols-2 gap-2.5"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: feedPet,
    disabled: !feedReady(pet),
    className: "py-3 text-[11px] tracking-[0.25em] uppercase active:scale-95 transition-all",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 700,
      color: feedReady(pet) ? "var(--tq-surface-deep)" : "var(--tq-ink-faint)",
      background: feedReady(pet) ? "linear-gradient(180deg, var(--tq-life), var(--tq-life-deep))" : "rgba(154, 135, 101, 0.08)",
      border: "1px solid ".concat(feedReady(pet) ? "#7faf7f" : "rgba(154, 135, 101, 0.18)"),
      borderRadius: "3px",
      boxShadow: feedReady(pet) ? "inset 0 1px 0 rgba(255,255,255,0.25), 0 2px 8px rgba(143, 188, 143, 0.2)" : "none"
    }
  }, /*#__PURE__*/React.createElement("div", null, "FEED"), /*#__PURE__*/React.createElement("div", {
    className: "text-[10px] tracking-[0.15em] mt-1",
    style: {
      opacity: 0.75
    }
  }, fmtCd(feedCdMs))), /*#__PURE__*/React.createElement("button", {
    onClick: playWithPet,
    disabled: !playReady(pet),
    className: "py-3 text-[11px] tracking-[0.25em] uppercase active:scale-95 transition-all",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 700,
      color: playReady(pet) ? "var(--tq-surface-deep)" : "var(--tq-ink-faint)",
      background: playReady(pet) ? "linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))" : "rgba(154, 135, 101, 0.08)",
      border: "1px solid ".concat(playReady(pet) ? "#b09850" : "rgba(154, 135, 101, 0.18)"),
      borderRadius: "3px",
      boxShadow: playReady(pet) ? "inset 0 1px 0 rgba(255,255,255,0.25), 0 2px 8px rgba(201, 169, 97, 0.25)" : "none"
    }
  }, /*#__PURE__*/React.createElement("div", null, "PLAY"), /*#__PURE__*/React.createElement("div", {
    className: "text-[10px] tracking-[0.15em] mt-1",
    style: {
      opacity: 0.75
    }
  }, fmtCd(playCdMs)))), /*#__PURE__*/React.createElement("div", {
    className: "px-4 py-2.5 flex items-center justify-between",
    style: {
      borderTop: "1px solid ".concat(coreData.symbol, "22"),
      background: 'rgba(5, 3, 10, 0.4)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-[9px] tracking-[0.2em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-mid)"
    }
  }, ageDays >= 1 ? "".concat(ageDays, " day").concat(ageDays === 1 ? '' : 's') : "".concat(ageHours, "h"), " . stage ", stage + 1, "/3"), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return setShowAdvanced(!showAdvanced);
    },
    className: "text-[9px] tracking-[0.2em] uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: coreData.symbol,
      background: 'transparent',
      border: 'none',
      padding: '4px 8px',
      cursor: 'pointer',
      borderRadius: '2px'
    }
  }, showAdvanced ? '— hide' : '+ details')), showAdvanced && /*#__PURE__*/React.createElement("div", {
    className: "px-4 py-3 space-y-2.5",
    style: {
      borderTop: "1px dashed rgba(201, 169, 97, 0.18)",
      background: 'rgba(5, 3, 10, 0.5)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex gap-2"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onRename,
    className: "flex-1 py-2 text-[9px] tracking-[0.2em] uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      background: "rgba(201, 169, 97, 0.06)",
      border: "1px solid rgba(201, 169, 97, 0.3)",
      borderRadius: "3px"
    }
  }, "Rename"), /*#__PURE__*/React.createElement("button", {
    onClick: onReset,
    className: "flex-1 py-2 text-[9px] tracking-[0.2em] uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-danger)",
      background: "rgba(160, 48, 44, 0.06)",
      border: "1px solid rgba(160, 48, 44, 0.3)",
      borderRadius: "3px"
    }
  }, "Reset")), /*#__PURE__*/React.createElement("div", {
    className: "pt-2",
    style: {
      borderTop: "1px solid rgba(201, 169, 97, 0.1)"
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] tracking-[0.3em] uppercase mb-1.5",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "#6a5042"
    }
  }, "Dev Mode"), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-2 gap-1 mb-1.5"
  }, /*#__PURE__*/React.createElement("div", {
    className: "px-2 py-1",
    style: {
      background: "rgba(10,6,4,0.5)",
      border: "1px solid rgba(154,135,101,0.2)",
      borderRadius: "2px"
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] uppercase tracking-widest",
    style: {
      color: "var(--tq-ink-faint)",
      fontFamily: "'Cinzel', serif"
    }
  }, "XP"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'JetBrains Mono', monospace",
      color: "var(--tq-gold-deep)",
      fontSize: "0.75rem",
      fontWeight: 700
    }
  }, Math.round(pet.xp || 0))), /*#__PURE__*/React.createElement("div", {
    className: "px-2 py-1",
    style: {
      background: "rgba(10,6,4,0.5)",
      border: "1px solid rgba(154,135,101,0.2)",
      borderRadius: "2px"
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] uppercase tracking-widest",
    style: {
      color: "var(--tq-ink-faint)",
      fontFamily: "'Cinzel', serif"
    }
  }, "Age"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'JetBrains Mono', monospace",
      color: "var(--tq-gold-deep)",
      fontSize: "0.75rem",
      fontWeight: 700
    }
  }, Math.floor((Date.now() - pet.hatchedAt) / (1000 * 60)), "m"))), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-2 gap-1 mb-1"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onDevJuvenile,
    className: "py-1.5 text-[10px] tracking-widest uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-info)",
      background: "rgba(63,100,140,0.15)",
      border: "1px solid rgba(63,100,140,0.35)",
      borderRadius: "2px"
    }
  }, "-> Juvenile"), /*#__PURE__*/React.createElement("button", {
    onClick: onDevAdult,
    className: "py-1.5 text-[10px] tracking-widest uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      background: "rgba(201,169,97,0.1)",
      border: "1px solid rgba(201,169,97,0.3)",
      borderRadius: "2px"
    }
  }, "-> Adult")), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-2 gap-1"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onDevFeed,
    className: "py-1.5 text-[10px] tracking-widest uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-life-deep)",
      background: "rgba(107,142,90,0.1)",
      border: "1px solid rgba(107,142,90,0.25)",
      borderRadius: "2px"
    }
  }, "Reset Feed CD"), /*#__PURE__*/React.createElement("button", {
    onClick: onDevPlay,
    className: "py-1.5 text-[10px] tracking-widest uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "#c9a9c9",
      background: "rgba(154,138,170,0.1)",
      border: "1px solid rgba(154,138,170,0.25)",
      borderRadius: "2px"
    }
  }, "Reset Play CD")))));
};

// Decorative flourish for header -- fleur-de-lis/arcane ornament
var Ornament = function Ornament(_ref11) {
  var _ref11$style = _ref11.style,
    style = _ref11$style === void 0 ? {} : _ref11$style,
    _ref11$flip = _ref11.flip,
    flip = _ref11$flip === void 0 ? false : _ref11$flip;
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 40 24",
    width: "40",
    height: "24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: _objectSpread({
      transform: flip ? 'scaleX(-1)' : 'none'
    }, style)
  }, /*#__PURE__*/React.createElement("path", {
    d: "M2 12 L14 12",
    strokeWidth: "0.8",
    opacity: "0.5"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M14 12 L20 6 M14 12 L20 18",
    strokeWidth: "1"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "20",
    cy: "12",
    r: "2.5",
    strokeWidth: "1",
    fill: "currentColor",
    fillOpacity: "0.15"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M22.5 12 L26 9 M22.5 12 L26 15",
    strokeWidth: "1"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M28 9 L28 15",
    strokeWidth: "0.8",
    opacity: "0.7"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M31 11 L31 13 M34 10 L34 14 M37 12 L37 12",
    strokeWidth: "0.8",
    opacity: "0.5"
  }));
};

// ============ Data ============
var QUICK_SEARCHES = ["Treasure", "Clue", "Food", "Blood", "Map", "Soldier", "Zombie", "Saproling", "Goblin", "Spirit", "Angel", "Dragon", "Wolf", "Insect", "Elf Warrior"];
var COLOR_DOTS = {
  W: "#f9f4d4",
  U: "var(--tq-info)",
  B: "#4a4a4a",
  R: "var(--tq-danger-soft)",
  G: "var(--tq-life-deep)"
};
var normalizeCard = function normalizeCard(card) {
  var _card$image_uris, _card$image_uris2, _card$card_faces, _card$image_uris3, _card$image_uris4, _card$card_faces2, _ref12, _card$power, _card$card_faces3, _ref13, _card$toughness, _card$card_faces4;
  if (card.smallImage !== undefined) return card;
  var smallImage = ((_card$image_uris = card.image_uris) === null || _card$image_uris === void 0 ? void 0 : _card$image_uris.small) || ((_card$image_uris2 = card.image_uris) === null || _card$image_uris2 === void 0 ? void 0 : _card$image_uris2.normal) || ((_card$card_faces = card.card_faces) === null || _card$card_faces === void 0 || (_card$card_faces = _card$card_faces[0]) === null || _card$card_faces === void 0 || (_card$card_faces = _card$card_faces.image_uris) === null || _card$card_faces === void 0 ? void 0 : _card$card_faces.small) || "";
  var normalImage = ((_card$image_uris3 = card.image_uris) === null || _card$image_uris3 === void 0 ? void 0 : _card$image_uris3.normal) || ((_card$image_uris4 = card.image_uris) === null || _card$image_uris4 === void 0 ? void 0 : _card$image_uris4.large) || ((_card$card_faces2 = card.card_faces) === null || _card$card_faces2 === void 0 || (_card$card_faces2 = _card$card_faces2[0]) === null || _card$card_faces2 === void 0 || (_card$card_faces2 = _card$card_faces2.image_uris) === null || _card$card_faces2 === void 0 ? void 0 : _card$card_faces2.normal) || smallImage;
  return {
    id: card.id,
    name: card.name,
    smallImage: smallImage,
    normalImage: normalImage,
    power: (_ref12 = (_card$power = card.power) !== null && _card$power !== void 0 ? _card$power : (_card$card_faces3 = card.card_faces) === null || _card$card_faces3 === void 0 || (_card$card_faces3 = _card$card_faces3[0]) === null || _card$card_faces3 === void 0 ? void 0 : _card$card_faces3.power) !== null && _ref12 !== void 0 ? _ref12 : null,
    toughness: (_ref13 = (_card$toughness = card.toughness) !== null && _card$toughness !== void 0 ? _card$toughness : (_card$card_faces4 = card.card_faces) === null || _card$card_faces4 === void 0 || (_card$card_faces4 = _card$card_faces4[0]) === null || _card$card_faces4 === void 0 ? void 0 : _card$card_faces4.toughness) !== null && _ref13 !== void 0 ? _ref13 : null,
    type_line: card.type_line || "",
    colors: card.colors || card.color_identity || []
  };
};

// localStorage-backed persistent storage
// ============ Quick Token Presets ============
var PRESET_TOKENS = [{
  id: 'treasure',
  name: 'Treasure',
  type: 'Artifact',
  emoji: '💰',
  colors: [],
  pt: null,
  text: '{T}, Sacrifice: Add one mana of any color.'
}, {
  id: 'food',
  name: 'Food',
  type: 'Artifact',
  emoji: '🍎',
  colors: [],
  pt: null,
  text: '{2}, {T}, Sacrifice: You gain 3 life.'
}, {
  id: 'clue',
  name: 'Clue',
  type: 'Artifact',
  emoji: '🔍',
  colors: [],
  pt: null,
  text: '{2}, Sacrifice: Draw a card.'
}, {
  id: 'blood',
  name: 'Blood',
  type: 'Artifact',
  emoji: '🩸',
  colors: [],
  pt: null,
  text: '{1}, {T}, Discard a card, Sacrifice: Draw a card.'
}, {
  id: 'map',
  name: 'Map',
  type: 'Artifact',
  emoji: '🗺️',
  colors: [],
  pt: null,
  text: '{1}, {T}, Sacrifice: Target creature you control explores.'
}, {
  id: 'powerstone',
  name: 'Powerstone',
  type: 'Artifact',
  emoji: '💎',
  colors: [],
  pt: null,
  text: '{T}: Add {C}. This mana can\'t be spent to cast nonartifact spells.'
}];

// Standard MTG counters - tracked on players or as standalone trackers
var STANDARD_COUNTERS = [{
  id: 'energy',
  name: 'Energy',
  short: 'E',
  color: 'var(--tq-gold-deep)',
  glow: 'rgba(212, 184, 122, 0.3)',
  text: '{E}. Energy reserves. Pay {E} as costs of activated abilities or spells.'
}, {
  id: 'poison',
  name: 'Poison',
  short: 'P',
  color: '#7faf4f',
  glow: 'rgba(127, 175, 79, 0.3)',
  text: 'A player with 10+ poison counters loses the game.'
}, {
  id: 'experience',
  name: 'Experience',
  short: 'XP',
  color: 'var(--tq-info)',
  glow: 'rgba(159, 199, 230, 0.3)',
  text: 'Experience counters track a permanent benefit across the game.'
}, {
  id: 'oil',
  name: 'Oil',
  short: 'OIL',
  color: '#3a3a4a',
  glow: 'rgba(120, 120, 140, 0.3)',
  text: 'Oil counters fuel Phyrexian artifacts and creatures.'
}, {
  id: 'stun',
  name: 'Stun',
  short: 'STN',
  color: '#c9a9c9',
  glow: 'rgba(201, 169, 201, 0.3)',
  text: 'If a permanent with a stun counter would become untapped, remove a stun counter instead.'
}, {
  id: 'shield',
  name: 'Shield',
  short: 'SH',
  color: '#e8cc8a',
  glow: 'rgba(232, 204, 138, 0.3)',
  text: 'If a permanent with a shield counter would be destroyed or dealt damage, remove a shield counter instead.'
}, {
  id: 'charge',
  name: 'Charge',
  short: 'CH',
  color: '#9a8ad4',
  glow: 'rgba(154, 138, 212, 0.3)',
  text: 'Charge counters accumulate to power abilities like Coretapper or Power Conduit.'
}, {
  id: 'time',
  name: 'Time',
  short: 'T',
  color: '#d4a87a',
  glow: 'rgba(212, 168, 122, 0.3)',
  text: 'Time counters track suspend, vanishing, and fading effects.'
}, {
  id: 'loyalty',
  name: 'Loyalty',
  short: 'L',
  color: '#b89a6a',
  glow: 'rgba(184, 154, 106, 0.3)',
  text: 'Planeswalker loyalty. Plus abilities add, minus abilities remove.'
}, {
  id: 'wish',
  name: 'Wish',
  short: 'W',
  color: 'var(--tq-gold-bright)',
  glow: 'rgba(245, 217, 143, 0.3)',
  text: 'Wish counters and other tokens used for one-shot effects.'
}];
var COUNTER_TYPES = [{
  id: 'plusOne',
  short: '+1/+1',
  color: 'var(--tq-life-deep)'
}, {
  id: 'minusOne',
  short: '-1/-1',
  color: 'var(--tq-danger-deep)'
}];
var storage = {
  get: function get(key) {
    try {
      var v = localStorage.getItem(key);
      return v ? JSON.parse(v) : null;
    } catch (_unused) {
      return null;
    }
  },
  set: function set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (_unused2) {}
  }
};

// Haptic feedback -- uses native Capacitor Haptics plugin when available (reliable on all phones),
// falls back to the web Vibration API when running in a browser.
// Reads tq_haptic_intensity from localStorage: 'off' | 'light' | 'normal' | 'strong'
var getHapticIntensity = function getHapticIntensity() {
  try {
    var s = localStorage.getItem('settings');
    if (s) {
      var p = JSON.parse(s);
      return p && p.hapticIntensity ? p.hapticIntensity : 'normal';
    }
  } catch (_unused3) {}
  return 'normal';
};
var haptic = function haptic() {
  var duration = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 20;
  var intensity = getHapticIntensity();
  if (intensity === 'off') return;
  // Scale duration based on intensity
  var scale = intensity === 'light' ? 0.5 : intensity === 'strong' ? 1.5 : 1;
  try {
    var cap = typeof window !== 'undefined' ? window.Capacitor : null;
    var Haptics = cap && cap.Plugins && cap.Plugins.Haptics;
    if (Haptics && cap.isNativePlatform && cap.isNativePlatform()) {
      if (Array.isArray(duration)) {
        var style = intensity === 'light' ? 'LIGHT' : intensity === 'strong' ? 'HEAVY' : 'MEDIUM';
        duration.forEach(function (_, i) {
          return setTimeout(function () {
            return Haptics.impact({
              style: style
            });
          }, i * 60);
        });
      } else {
        var d = duration * scale;
        var _style = intensity === 'light' ? 'LIGHT' : d <= 15 ? 'LIGHT' : d <= 25 ? 'MEDIUM' : 'HEAVY';
        Haptics.impact({
          style: _style
        });
      }
      return;
    }
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(Array.isArray(duration) ? duration : Math.round(duration * scale));
    }
  } catch (_unused4) {}
};

// useLongPress -- returns handlers for both touch and mouse that fire onLongPress after 500ms
// and a regular onClick for short taps. Prevents the onClick when a long press fires.
function useLongPress(onClick, onLongPress) {
  var ms = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 500;
  var timerRef = useRef(null);
  var longFiredRef = useRef(false);
  var start = function start(e) {
    longFiredRef.current = false;
    timerRef.current = setTimeout(function () {
      longFiredRef.current = true;
      haptic(25);
      onLongPress && onLongPress(e);
    }, ms);
  };
  var clear = function clear(fireClick) {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    if (fireClick && !longFiredRef.current && onClick) onClick();
  };
  return {
    onTouchStart: start,
    onTouchEnd: function onTouchEnd(e) {
      e.preventDefault();
      clear(true);
    },
    onTouchCancel: function onTouchCancel() {
      return clear(false);
    },
    onMouseDown: start,
    onMouseUp: function onMouseUp() {
      return clear(true);
    },
    onMouseLeave: function onMouseLeave() {
      return clear(false);
    }
  };
}

// ============ Memory Game ============
var MEMORY_BEST_KEY = 'tq_memory_best';
var CARD_BACK_COLOR = 'var(--tq-surface)';
var MemoryGame = function MemoryGame(_ref14) {
  var onClose = _ref14.onClose,
    pet = _ref14.pet,
    setPet = _ref14.setPet,
    showToast = _ref14.showToast,
    haptic = _ref14.haptic;
  var best = parseInt(localStorage.getItem(MEMORY_BEST_KEY) || '999999', 10);
  // Prefer the user's chosen tier from TQ.memoryConfig if available
  var pairCount = (function () {
    if (window.TQ && window.TQ.memoryConfig) {
      return window.TQ.memoryConfig.pairsForTier(window.TQ.memoryConfig.tier);
    }
    return best < 45000 ? 12 : best < 90000 ? 8 : 4;
  })();
  var _React$useState15 = React.useState([]),
    _React$useState16 = _slicedToArray(_React$useState15, 2),
    cards = _React$useState16[0],
    setCards = _React$useState16[1];
  var _React$useState17 = React.useState([]),
    _React$useState18 = _slicedToArray(_React$useState17, 2),
    flipped = _React$useState18[0],
    setFlipped = _React$useState18[1];
  var _React$useState19 = React.useState(new Set()),
    _React$useState20 = _slicedToArray(_React$useState19, 2),
    matched = _React$useState20[0],
    setMatched = _React$useState20[1];
  var _React$useState21 = React.useState(null),
    _React$useState22 = _slicedToArray(_React$useState21, 2),
    startTime = _React$useState22[0],
    setStartTime = _React$useState22[1];
  var _React$useState23 = React.useState(0),
    _React$useState24 = _slicedToArray(_React$useState23, 2),
    elapsed = _React$useState24[0],
    setElapsed = _React$useState24[1];
  var _React$useState25 = React.useState(true),
    _React$useState26 = _slicedToArray(_React$useState25, 2),
    loading = _React$useState26[0],
    setLoading = _React$useState26[1];
  var _React$useState27 = React.useState(false),
    _React$useState28 = _slicedToArray(_React$useState27, 2),
    complete = _React$useState28[0],
    setComplete = _React$useState28[1];
  var _React$useState29 = React.useState(0),
    _React$useState30 = _slicedToArray(_React$useState29, 2),
    finalTime = _React$useState30[0],
    setFinalTime = _React$useState30[1];
  var _React$useState31 = React.useState(false),
    _React$useState32 = _slicedToArray(_React$useState31, 2),
    locked = _React$useState32[0],
    setLocked = _React$useState32[1];
  var timerRef = React.useRef(null);
  var lockRef = React.useRef(false);

  // Offline token card pool — stable Scryfall art_crop CDN URLs
  var OFFLINE_TOKEN_POOL = [{
    id: 'tok001',
    name: 'Goblin',
    art: 'https://cards.scryfall.io/art_crop/front/6/5/65a66f8a-9dae-4e11-a2e1-2ea83edfe5b4.jpg?1682204785'
  }, {
    id: 'tok002',
    name: 'Soldier',
    art: 'https://cards.scryfall.io/art_crop/front/0/2/024a72d3-61b5-4b80-af3e-b49e02f5c786.jpg?1682208022'
  }, {
    id: 'tok003',
    name: 'Zombie',
    art: 'https://cards.scryfall.io/art_crop/front/6/0/60623f09-29ed-4f2f-bde5-36d3714ed51c.jpg?1682208022'
  }, {
    id: 'tok004',
    name: 'Dragon',
    art: 'https://cards.scryfall.io/art_crop/front/a/5/a5fa14e7-7355-44b5-9800-9f3d72640059.jpg?1682208038'
  }, {
    id: 'tok005',
    name: 'Angel',
    art: 'https://cards.scryfall.io/art_crop/front/1/3/13e4de1c-1a51-4892-8d44-7e2ee7e6f1e1.jpg?1682204785'
  }, {
    id: 'tok006',
    name: 'Wolf',
    art: 'https://cards.scryfall.io/art_crop/front/f/2/f2512cdb-9d3e-41d3-a0ae-3d0e63a9a8ac.jpg?1682208038'
  }, {
    id: 'tok007',
    name: 'Elemental',
    art: 'https://cards.scryfall.io/art_crop/front/b/1/b19e43d7-0e35-4487-88ac-a7db8e8a498b.jpg?1682204785'
  }, {
    id: 'tok008',
    name: 'Saproling',
    art: 'https://cards.scryfall.io/art_crop/front/3/c/3c51ce6a-e6f4-4b16-9a87-f09e3e45d5ff.jpg?1682208022'
  }, {
    id: 'tok009',
    name: 'Spirit',
    art: 'https://cards.scryfall.io/art_crop/front/e/5/e53c2f84-d5b5-4e7c-8aa3-0564c3e9e8f0.jpg?1682208022'
  }, {
    id: 'tok010',
    name: 'Bird',
    art: 'https://cards.scryfall.io/art_crop/front/8/b/8b2e0e21-af60-4c2c-affc-6c0f3a7b0c3d.jpg?1682204785'
  }, {
    id: 'tok011',
    name: 'Insect',
    art: 'https://cards.scryfall.io/art_crop/front/2/a/2aef89cc-eefb-471d-82d2-4d5c2ad8f72f.jpg?1682208022'
  }, {
    id: 'tok012',
    name: 'Thopter',
    art: 'https://cards.scryfall.io/art_crop/front/9/d/9dff8ba4-f7fb-4b36-b1d3-83b3d8c58e4e.jpg?1682208038'
  }];
  React.useEffect(function () {
    setLoading(true);
    // Use offline pool — shuffle and pick pairs
    var shuffledPool = [].concat(OFFLINE_TOKEN_POOL).sort(function () {
      return Math.random() - 0.5;
    }).slice(0, pairCount);
    var pairs = [].concat(_toConsumableArray(shuffledPool), _toConsumableArray(shuffledPool)).map(function (c, i) {
      return {
        id: "".concat(c.id, "-").concat(i < shuffledPool.length ? 'a' : 'b'),
        pairId: c.id,
        name: c.name,
        art: c.art
      };
    });
    for (var i = pairs.length - 1; i > 0; i--) {
      var j = Math.floor(Math.random() * (i + 1));
      var _ref15 = [pairs[j], pairs[i]];
      pairs[i] = _ref15[0];
      pairs[j] = _ref15[1];
    }
    setCards(pairs);
    setLoading(false);
  }, [pairCount]);

  // Timer
  React.useEffect(function () {
    if (startTime && !complete) {
      timerRef.current = setInterval(function () {
        return setElapsed(Date.now() - startTime);
      }, 200);
    }
    return function () {
      return clearInterval(timerRef.current);
    };
  }, [startTime, complete]);
  var flipCard = function flipCard(card) {
    if (lockRef.current || matched.has(card.pairId) || flipped.find(function (c) {
      return c.id === card.id;
    })) return;
    haptic(15);
    if (!startTime) setStartTime(Date.now());
    var newFlipped = [].concat(_toConsumableArray(flipped), [card]);
    setFlipped(newFlipped);
    if (newFlipped.length === 2) {
      lockRef.current = true;
      setLocked(true);
      if (newFlipped[0].pairId === newFlipped[1].pairId) {
        // Match
        haptic([20, 30]);
        var newMatched = new Set([].concat(_toConsumableArray(matched), [card.pairId]));
        setMatched(newMatched);
        setFlipped([]);
        lockRef.current = false;
        setLocked(false);
        if (newMatched.size === pairCount) {
          // Complete!
          clearInterval(timerRef.current);
          var t = Date.now() - startTime;
          setFinalTime(t);
          setComplete(true);
          haptic([30, 50, 30, 80]);
          var prevBest = parseInt(localStorage.getItem(MEMORY_BEST_KEY) || '999999', 10);
          if (t < prevBest) localStorage.setItem(MEMORY_BEST_KEY, String(t));
          // Award pet XP
          if (pet) {
            var xp = pairCount === 4 ? 20 : pairCount === 8 ? 40 : 80;
            setPet(_objectSpread(_objectSpread({}, pet), {}, {
              xp: (pet.xp || 0) + xp
            }));
            showToast("Your companion earned ".concat(xp, " XP!"));
          }
        }
      } else {
        // No match -- flip back after 800ms
        setTimeout(function () {
          setFlipped([]);
          lockRef.current = false;
          setLocked(false);
        }, 800);
      }
    }
  };
  var fmtTime = function fmtTime(ms) {
    var s = Math.floor(ms / 1000);
    var m = Math.floor(s / 60);
    return m > 0 ? "".concat(m, ":").concat(String(s % 60).padStart(2, '0')) : "".concat(s, "s");
  };
  var cols = pairCount === 4 ? 4 : pairCount === 8 ? 4 : 6;
  return /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 z-[120] flex flex-col",
    style: {
      background: "radial-gradient(ellipse at top, var(--tq-surface) 0%, #05030a 100%)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between px-4 py-3",
    style: {
      borderBottom: "1px solid rgba(201,169,97,0.25)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    className: "text-sm uppercase tracking-[0.3em]",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold-deep)",
      fontWeight: 600
    }
  }, "Memory"), /*#__PURE__*/React.createElement("p", {
    className: "text-[9px]",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-faint)"
    }
  }, pairCount, " pairs . ", matched.size, "/", pairCount, " matched")), /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-3"
  }, startTime && !complete && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'JetBrains Mono', monospace",
      color: "var(--tq-gold)",
      fontSize: "1rem",
      fontWeight: 700
    }
  }, fmtTime(elapsed)), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      clearInterval(timerRef.current);
      onClose();
    },
    className: "w-8 h-8 flex items-center justify-center active:scale-90",
    style: {
      color: "var(--tq-ink-dim)",
      border: "1px solid rgba(154,135,101,0.4)",
      borderRadius: "2px"
    }
  }, /*#__PURE__*/React.createElement(XIcon, {
    style: {
      fontSize: '1rem'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    className: "flex-1 overflow-y-auto p-3"
  }, loading ? /*#__PURE__*/React.createElement("div", {
    className: "flex flex-col items-center justify-center h-full gap-3"
  }, /*#__PURE__*/React.createElement(Loader2, {
    className: "animate-spin",
    style: {
      color: "var(--tq-gold)",
      fontSize: '2rem'
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-ink-faint)",
      fontStyle: "italic"
    }
  }, "Summoning tokens...")) : complete ? /*#__PURE__*/React.createElement("div", {
    className: "flex flex-col items-center justify-center h-full gap-4 p-6 text-center"
  }, /*#__PURE__*/React.createElement(Sparkles, {
    style: {
      color: "var(--tq-gold-deep)",
      fontSize: '2.5rem'
    }
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold-bright)",
      fontSize: "1.3rem",
      fontWeight: 700
    }
  }, "Complete!"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'JetBrains Mono', monospace",
      color: "var(--tq-gold-deep)",
      fontSize: "2rem",
      fontWeight: 700
    }
  }, fmtTime(finalTime)), finalTime < parseInt(localStorage.getItem(MEMORY_BEST_KEY) || '999999', 10) + 1 && /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-gold)",
      fontStyle: "italic"
    }
  }, "New best time!"), best < 999999 && /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-faint)",
      fontSize: "0.7rem"
    }
  }, "Best: ", fmtTime(parseInt(localStorage.getItem(MEMORY_BEST_KEY), 10))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-ink-dim)",
      fontSize: "0.8rem",
      fontStyle: "italic"
    }
  }, finalTime < 30000 ? "Uncanny recall." : finalTime < 60000 ? "Sharp eyes." : finalTime < 120000 ? "A worthy effort." : "The mind wanders. Try again."), /*#__PURE__*/React.createElement("div", {
    className: "flex gap-2 mt-2"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      clearInterval(timerRef.current);
      onClose();
    },
    className: "px-4 py-2 text-xs tracking-widest uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      border: "1px solid rgba(201,169,97,0.4)",
      borderRadius: "2px"
    }
  }, "Return"), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      setCards([]);
      setFlipped([]);
      setMatched(new Set());
      setStartTime(null);
      setElapsed(0);
      setComplete(false);
      setFinalTime(0);
      setLocked(false);
      lockRef.current = false;
      setLoading(true);
    },
    className: "px-4 py-2 text-xs tracking-widest uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 600,
      color: "var(--tq-surface)",
      background: "linear-gradient(180deg,var(--tq-gold-bright),var(--tq-gold))",
      border: "1px solid var(--tq-gold)",
      borderRadius: "2px"
    }
  }, "Play Again"))) : /*#__PURE__*/React.createElement("div", {
    className: "grid gap-1.5",
    style: {
      gridTemplateColumns: "repeat(".concat(cols, ", 1fr)")
    }
  }, cards.map(function (card) {
    var isFlipped = !!flipped.find(function (c) {
      return c.id === card.id;
    }) || matched.has(card.pairId);
    var isMatched = matched.has(card.pairId);
    return /*#__PURE__*/React.createElement("div", {
      key: card.id,
      onClick: function onClick() {
        return flipCard(card);
      },
      className: "relative active:scale-95 transition-transform",
      style: {
        aspectRatio: '5/7',
        borderRadius: '3px',
        overflow: 'hidden',
        cursor: 'pointer',
        border: "1.5px solid ".concat(isMatched ? 'var(--tq-gold)' : 'rgba(154,135,101,0.3)'),
        boxShadow: isMatched ? '0 0 8px rgba(201,169,97,0.4)' : 'none',
        transition: 'all 0.3s ease'
      }
    }, isFlipped ? /*#__PURE__*/React.createElement("img", {
      src: card.art,
      alt: card.name,
      style: {
        width: '100%',
        height: '100%',
        objectFit: 'cover',
        filter: isMatched ? 'brightness(1)' : 'brightness(0.9)',
        transition: 'filter 0.3s'
      }
    }) : /*#__PURE__*/React.createElement("div", {
      style: {
        width: '100%',
        height: '100%',
        background: "radial-gradient(ellipse at 40% 35%, #2a1f14, ".concat(CARD_BACK_COLOR, ")"),
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement("svg", {
      viewBox: "0 0 40 56",
      width: "60%",
      opacity: "0.4"
    }, /*#__PURE__*/React.createElement("ellipse", {
      cx: "20",
      cy: "28",
      rx: "14",
      ry: "20",
      fill: "none",
      stroke: "var(--tq-gold)",
      strokeWidth: "1.5"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M 20 8 L 20 48 M 6 28 L 34 28",
      stroke: "var(--tq-gold)",
      strokeWidth: "0.8",
      opacity: "0.5"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "20",
      cy: "28",
      r: "4",
      fill: "none",
      stroke: "var(--tq-gold)",
      strokeWidth: "1"
    }))));
  }))));
};

// ============ Chiptune Audio Engine ============
// Dragon: Elder Scrolls / Morrowind inspired - modal, majestic, ancient
// Zombie: Bloody Tears (Castlevania) inspired - minor, driving, dramatic
var MUTE_KEY = 'tq_mute';
var createAudioEngine = function createAudioEngine() {
  var ctx = null,
    master = null;
  var muted = localStorage.getItem(MUTE_KEY) === '1';
  var tickId = null,
    track = null,
    step = 0,
    nextT = 0;
  var boot = function boot() {
    if (ctx) return ctx;
    try {
      ctx = new (window.AudioContext || window.webkitAudioContext)();
      master = ctx.createGain();
      master.gain.value = muted ? 0 : 0.32;
      master.connect(ctx.destination);
    } catch (e) {}
    return ctx;
  };
  var wake = function wake() {
    if (ctx && ctx.state === 'suspended') ctx.resume();
  };

  // Low-level synth
  var osc = function osc(freq, type, t, dur) {
    var vol = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 0.2;
    var atk = arguments.length > 5 && arguments[5] !== undefined ? arguments[5] : 0.005;
    var rel = arguments.length > 6 && arguments[6] !== undefined ? arguments[6] : 0.05;
    if (!ctx || muted || vol <= 0 || dur <= 0) return;
    var o = ctx.createOscillator(),
      g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + atk);
    g.gain.setValueAtTime(vol * 0.75, t + dur * 0.7);
    g.gain.linearRampToValueAtTime(0, t + dur);
    o.connect(g);
    g.connect(master);
    o.start(t);
    o.stop(t + dur + 0.01);
  };
  var noise = function noise(t, dur, vol) {
    var cf = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 200;
    if (!ctx || muted) return;
    var n = Math.max(2, Math.ceil(ctx.sampleRate * dur));
    var buf = ctx.createBuffer(1, n, ctx.sampleRate);
    var d = buf.getChannelData(0);
    for (var i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    var src = ctx.createBufferSource(),
      flt = ctx.createBiquadFilter(),
      g = ctx.createGain();
    flt.type = 'bandpass';
    flt.frequency.value = cf;
    flt.Q.value = 1.5;
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.buffer = buf;
    src.connect(flt);
    flt.connect(g);
    g.connect(master);
    src.start(t);
    src.stop(t + dur + 0.01);
  };
  var hz = function hz(n) {
    return 130.81 * Math.pow(2, n / 12);
  }; // semitones from C3

  // ================================================================
  // DRAGON: Fantasy Adventure Theme — orchestral chiptune style
  // Inspired by classic JRPG/fantasy soundtracks (Zelda, FF, Castlevania)
  // D major feel — heroic, soaring, magical
  // Scale: D(2) E(4) F#(6) G(7) A(9) B(11) C#(13) D(14)
  // 148 BPM, 16th note steps, 64-step loop
  //
  // Voice 1: Lead melody  — triangle (warm, flute-like)
  // Voice 2: Harmony      — square (bright counter-melody)
  // Voice 3: Bass         — sine (deep, warm low end)
  // Voice 4: Chord pad    — detuned sawtooth (lush strings feel)
  // Voice 5: Arpeggio     — fast triangle (harp-like sparkle)
  // Drums:   soft kick, tambourine feel — airy not punchy
  // ================================================================

  // Lead — soaring fantasy melody, triangle for warmth
  var DML = [
  // Bar 1: Heroic opening — D major ascent
  14, null, 16, null, 18, null, 19, null, 21, null, 19, 18, 16, null, null, null,
  // Bar 2: Lyrical answer phrase
  21, null, 21, 23, 21, 19, 18, 16, 14, null, 16, null, 18, 19, 18, 16,
  // Bar 3: Build — rising with energy
  14, 16, 18, 19, 21, null, 23, null, 26, null, 23, 21, 19, null, null, null,
  // Bar 4: Resolution — triumphant finish back to root
  21, 19, 18, 16, 14, null, 13, null, 14, 16, 18, 21, 14, null, null, null];
  var DCL = [
  // Harmony — square, a 3rd above
  null, null, null, null, 21, null, null, null, null, null, null, null, 19, null, null, null, null, null, 16, null, null, null, null, null, null, null, 21, null, null, null, null, null, null, null, null, null, 16, null, 18, null, 21, null, 18, 16, 14, null, null, null, 16, 14, 13, 11, 9, null, null, null, 9, 11, 13, 16, 9, null, null, null];
  var DBL = [
  // Bass — sine, D root movement, warm and deep
  2, null, null, null, 7, null, null, null, 9, null, null, null, 7, null, null, null, 2, null, null, null, 9, null, null, null, 7, null, null, null, 4, null, null, null, 2, null, null, null, 7, null, null, null, 9, null, null, null, 11, null, null, null, 9, null, null, null, 7, null, null, null, 2, null, null, null, 2, null, null, null];
  var DPL = [
  // String pad — long sustained chords, sawtooth at low volume
  2, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 9, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 7, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, 9, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null];
  var DAP = [
  // Harp arpeggio — fast triangle, sparkle feel
  null, 6, 9, 14, null, 7, 11, 14, null, 9, 13, 16, null, 7, 11, 14, null, 6, 9, 14, null, 9, 14, 18, null, 7, 11, 14, null, 4, 9, 13, null, 6, 9, 14, null, 7, 11, 16, null, 9, 14, 18, null, 11, 14, 18, null, 9, 14, 18, null, 7, 11, 14, null, 6, 9, 14, null, 2, 6, 9];
  var DDR = [
  // Light orchestral feel — soft kick, no heavy snare
  'K', 'h', null, 'h', null, 'h', null, 'h', 'K', 'h', null, 'h', null, 'h', 'K', 'h', 'K', 'h', null, 'h', null, 'h', null, 'h', 'K', 'h', 'K', 'h', null, 'h', null, 'h', 'K', 'h', null, 'h', 'K', 'h', null, 'h', 'K', 'h', null, 'h', null, 'h', 'K', 'h', 'K', 'h', null, 'h', null, 'h', null, 'h', 'K', 'h', null, 'h', null, null, null, null];

  // ================================================================
  // ZOMBIE: 80s arcade action — Contra / TMNT NES energy
  // A minor pentatonic, 160 BPM, 16th note steps, 64-step loop
  // Voice 1: Lead melody  — square wave, punchy arpeggios
  // Voice 2: Harmony      — triangle, fills and counter-melody
  // Voice 3: Bass line    — sine, driving pulse on root/5th
  // Voice 4: Arp/run      — sawtooth, fast 16th note runs
  // Drums:   kick, snare, open hat, closed hat pattern
  //
  // Scale: A minor (A=21, B=23, C=24, D=26, E=28, F=29, G=31, A=33)
  // Semitones from C3: A=9, B=11, C=12, D=14, E=16, F=17, G=19, A=21
  // Power chord feel — lots of root+5th movement
  // ================================================================

  // Lead melody — iconic 80s action hook, 4 bars of 16 steps
  var ZML = [
  // Bar 1: punchy main riff — stab stab rise
  21, null, 21, 19, 21, null, 24, null, 21, null, 19, 17, 19, null, null, null,
  // Bar 2: answer phrase — descend with momentum
  24, null, 23, 21, 19, null, 17, null, 16, null, 17, 19, 21, null, null, null,
  // Bar 3: build — ascending run
  17, 19, 21, 23, 24, null, 23, 21, 19, null, 21, 23, 24, null, null, null,
  // Bar 4: resolution + hook tail
  28, null, 26, 24, 23, 21, 23, 24, 21, null, 19, null, 17, null, 16, null];
  // Harmony — triangle, counter-melody and stabs
  var ZHL = [
  // Bar 1: root stabs on offbeats
  null, null, null, null, 16, null, null, null, null, null, null, null, 16, null, null, null,
  // Bar 2
  null, null, null, null, 16, null, null, null, 14, null, null, null, 16, null, null, null,
  // Bar 3: follow the run a 3rd below
  12, 14, 16, 17, 17, null, 16, 14, 12, null, 14, 16, 17, null, null, null,
  // Bar 4: power chord hits
  21, null, 21, null, 19, 16, 19, 21, 16, null, 14, null, 12, null, 11, null];
  // Bass — driving pulse, root and 5th movement
  // Octave below lead: use A2=-3, E2=4, D2=2, C2=0, G2=7 (relative to C3)
  var ZBL = [
  // Bar 1: A pedal with 5th hits
  -3, null, -3, null, -3, null, 4, null, -3, null, -3, null, 4, null, -3, null,
  // Bar 2: movement to D and back
  2, null, 2, null, 2, null, -3, null, -8, null, -8, null, -3, null, 4, null,
  // Bar 3: rising with the melody
  -3, null, 2, null, 4, null, 7, null, 9, null, 7, null, 4, null, 2, null,
  // Bar 4: strong E–A–E cadence
  4, null, 4, null, -3, null, -3, null, 4, null, 4, null, -3, null, -3, null];
  // Arpeggio runs — sawtooth, very 80s NES
  var ZAL = [
  // Bar 1: silent on 1, arp on 3
  null, null, null, null, null, 9, 12, 16, null, null, null, null, null, 9, 11, 14,
  // Bar 2
  null, null, null, null, null, 12, 16, 21, null, 9, 12, null, null, 9, 11, 14,
  // Bar 3: fast chromatic run up
  9, 11, 12, 14, 16, 17, 19, 21, 16, null, 19, null, 21, null, 24, null,
  // Bar 4: descending arp
  28, 26, 24, 23, 21, 19, 17, 16, 14, null, 12, null, 9, null, null, null];
  // Drums — punchy NES pattern
  // K=kick  S=snare  H=open-hat  h=closed-hat  O=accent-kick
  var ZDR = [
  // Bar 1: classic 4-on-floor with snare 2&4
  'K', 'h', 'h', 'h', 'S', 'h', 'K', 'h', 'K', 'h', 'h', 'h', 'S', 'h', 'h', 'H',
  // Bar 2
  'K', 'h', 'h', 'h', 'S', 'h', 'K', 'h', 'K', 'h', 'h', 'K', 'S', 'h', 'K', 'h',
  // Bar 3: busier for the build
  'K', 'h', 'K', 'h', 'S', 'h', 'h', 'h', 'K', 'h', 'K', 'h', 'S', 'h', 'K', 'h',
  // Bar 4: big snare fill going into loop
  'K', 'h', 'h', 'h', 'S', 'h', 'K', 'h', 'O', 'h', 'S', 'h', 'S', 'S', 'S', 'h'];
  var scheduleStep = function scheduleStep(t, tr) {
    if (!ctx) return;
    var isDragon = tr === 'dragon';
    // Both tracks: 160 BPM 16th notes
    var bpm = 160;
    var sd = 60 / bpm / 4;
    var len = isDragon ? DML.length : ZML.length;
    var p = step % len;
    if (isDragon) {
      // Fantasy style — triangle lead (warm/flute), square harmony, sine bass, pad, harp arp
      var _bpm = 148;
      var sd2 = 60 / _bpm / 4;
      var m = DML[p];
      if (m !== null) osc(hz(m + 12), 'triangle', t, sd2 * 0.85, 0.26, 0.008, 0.08); // triangle = flute warmth
      var c = DCL[p];
      if (c !== null) osc(hz(c + 12), 'square', t, sd2 * 0.70, 0.10, 0.004, 0.05); // square counter-melody
      var b = DBL[p];
      if (b !== null) osc(hz(b), 'sine', t, sd2 * 3.6, 0.28, 0.012, 0.18); // deep warm bass
      var pad = DPL[p];
      if (pad !== null) {
        // string pad
        osc(hz(pad), 'sawtooth', t, sd2 * 15.5, 0.055, 0.06, 0.5);
        osc(hz(pad + 7), 'sawtooth', t, sd2 * 15.5, 0.040, 0.06, 0.5);
        osc(hz(pad + 12), 'sawtooth', t, sd2 * 15.5, 0.030, 0.06, 0.5);
      }
      var ap = DAP[p];
      if (ap !== null) osc(hz(ap + 24), 'triangle', t, sd2 * 0.38, 0.12, 0.002, 0.03); // harp sparkle
      var dr = DDR[p];
      if (dr === 'K') {
        noise(t, 0.06, 0.22, 85);
        noise(t, 0.04, 0.10, 140);
      } // soft kick
      if (dr === 'h') {
        noise(t, 0.015, 0.07, 11000);
      } // light tambourine
    } else {
      // 80s arcade — punchy square lead, fat bass, fast arps, cracking drums
      var _m = ZML[p];
      if (_m !== null) osc(hz(_m), 'square', t, sd * 0.75, 0.28, 0.002, 0.03);
      var h2 = ZHL[p];
      if (h2 !== null) osc(hz(h2), 'triangle', t, sd * 0.80, 0.14, 0.003, 0.04);
      var _b = ZBL[p];
      if (_b !== null) {
        // Double bass: root + octave for thickness
        osc(hz(_b), 'square', t, sd * 0.92, 0.22, 0.004, 0.06);
        osc(hz(_b + 12), 'sine', t, sd * 0.88, 0.16, 0.004, 0.05);
      }
      var a = ZAL[p];
      if (a !== null) osc(hz(a), 'sawtooth', t, sd * 0.45, 0.18, 0.001, 0.02);
      var _dr = ZDR[p];
      if (_dr === 'K' || _dr === 'O') {
        var vol = _dr === 'O' ? 0.55 : 0.42;
        noise(t, 0.055, vol, 68);
        noise(t, 0.04, vol * 0.6, 110);
      }
      if (_dr === 'S') {
        noise(t, 0.065, 0.38, 320);
        noise(t, 0.04, 0.20, 640);
        // Snap transient
        noise(t, 0.01, 0.5, 2400);
      }
      if (_dr === 'h') noise(t, 0.018, 0.12, 9000);
      if (_dr === 'H') noise(t, 0.04, 0.18, 6500); // open hat
    }
    step++;
  };
  var tick = function tick() {
    if (!ctx || !track) return;
    wake();
    var sd = 60 / 160 / 4; // 160 BPM 16th notes for both tracks
    while (nextT < ctx.currentTime + 0.18) {
      scheduleStep(nextT, track);
      nextT += sd;
    }
  };
  return {
    start: function start(tr) {
      boot();
      wake();
      if (!ctx) return;
      if (tickId) clearInterval(tickId);
      track = tr;
      step = 0;
      nextT = ctx.currentTime + 0.06;
      tickId = setInterval(tick, 55);
    },
    stop: function stop() {
      if (tickId) {
        clearInterval(tickId);
        tickId = null;
      }
      track = null;
    },
    currentTrack: function currentTrack() {
      return track;
    },
    isMuted: function isMuted() {
      return muted;
    },
    setMuted: function setMuted(v) {
      muted = v;
      localStorage.setItem(MUTE_KEY, v ? '1' : '0');
      boot();
      if (master && ctx) master.gain.setTargetAtTime(v ? 0 : 0.25, ctx.currentTime, 0.05);
    },
    sfxJump: function sfxJump() {
      boot();
      wake();
      if (!ctx || muted) return;
      var t = ctx.currentTime;
      osc(hz(21), 'square', t, 0.045, 0.32, 0.002, 0.01);
      osc(hz(28), 'square', t + 0.045, 0.055, 0.26, 0.002, 0.01);
    },
    sfxDoubleJump: function sfxDoubleJump() {
      boot();
      wake();
      if (!ctx || muted) return;
      var t = ctx.currentTime;
      osc(hz(21), 'square', t, 0.04, 0.26, 0.002, 0.01);
      osc(hz(28), 'square', t + 0.04, 0.04, 0.26, 0.002, 0.01);
      osc(hz(33), 'square', t + 0.08, 0.055, 0.24, 0.002, 0.01);
    },
    sfxDeath: function sfxDeath() {
      boot();
      wake();
      if (!ctx || muted) return;
      var t = ctx.currentTime;
      [hz(19), hz(16), hz(14), hz(11), hz(9)].forEach(function (f, i) {
        return osc(f, 'square', t + i * 0.09, 0.085, 0.28, 0.002, 0.04);
      });
      noise(t + 0.08, 0.3, 0.38, 170);
    },
    sfxScore: function sfxScore() {
      boot();
      wake();
      if (!ctx || muted) return;
      osc(hz(28), 'square', ctx.currentTime, 0.038, 0.20, 0.001, 0.01);
    },
    sfxMilestone: function sfxMilestone() {
      boot();
      wake();
      if (!ctx || muted) return;
      var t = ctx.currentTime;
      [hz(21), hz(26), hz(28), hz(33)].forEach(function (f, i) {
        return osc(f, 'square', t + i * 0.07, 0.08, 0.24, 0.002, 0.01);
      });
    }
  };
};
var _audioEngine = null;
var getAudio = function getAudio() {
  if (!_audioEngine) _audioEngine = createAudioEngine();
  return _audioEngine;
};

// ============ Flappy Dragon ============
// Dragon sprites — loaded from www/sprites/ folder
var DRAGON_SPRITE_W = 80;
var DRAGON_SPRITE_H = 53;
var DRAGON_COLOURS = ["white", "blue", "black", "red", "green"];
var DRAGON_COLOUR_LABELS = {
  white: "White",
  blue: "Blue",
  black: "Shadow",
  red: "Red",
  green: "Green"
};
var DRAGON_HIGH_KEY = 'tq_dragon_high'; // legacy / easy
var DRAGON_HIGH_HARD_KEY = 'tq_dragon_high_hard';

// Helper: cross-browser canvas rounded rectangle
var fdRoundRect = function fdRoundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
};
var FlappyDragon = function FlappyDragon(_ref16) {
  var onClose = _ref16.onClose,
    pet = _ref16.pet,
    setPet = _ref16.setPet,
    haptic = _ref16.haptic;
  // ============================================================================
  // FLAPPY DRAGON v2 - Pure canvas game, no React state during gameplay
  // ============================================================================
  // Architecture: single requestAnimationFrame loop, all game state in refs,
  // React only renders the chrome (close button, score readout) and reacts to
  // game-over events. Avoids React reconciliation freezes from per-frame setState.
  // ============================================================================

  var canvasRef = React.useRef(null);
  var containerRef = React.useRef(null);
  var rafRef = React.useRef(null);
  var audioCtxRef = React.useRef(null);
  var stateRef = React.useRef(null); // Mutable game state

  var _useState = useState('menu'),
    _useState2 = _slicedToArray(_useState, 2),
    phase = _useState2[0],
    setPhase = _useState2[1]; // 'menu' | 'playing' | 'gameover'
  var _useState3 = useState(function () {
      try {
        return localStorage.getItem('tq_flappy_color') || 'red';
      } catch (_unused5) {
        return 'red';
      }
    }),
    _useState4 = _slicedToArray(_useState3, 2),
    dragonColor = _useState4[0],
    setDragonColor = _useState4[1];
  var _useState5 = useState(function () {
      try {
        return localStorage.getItem('tq_flappy_diff') || 'normal';
      } catch (_unused6) {
        return 'normal';
      }
    }),
    _useState6 = _slicedToArray(_useState5, 2),
    difficulty = _useState6[0],
    setDifficulty = _useState6[1];
  var _useState7 = useState(function () {
      try {
        return localStorage.getItem('tq_flappy_muted') === '1';
      } catch (_unused7) {
        return false;
      }
    }),
    _useState8 = _slicedToArray(_useState7, 2),
    muted = _useState8[0],
    setMuted = _useState8[1];
  var _useState9 = useState(0),
    _useState0 = _slicedToArray(_useState9, 2),
    finalScore = _useState0[0],
    setFinalScore = _useState0[1];
  var _useState1 = useState(function () {
      try {
        return parseInt(localStorage.getItem('tq_flappy_best_v2') || '0', 10);
      } catch (_unused8) {
        return 0;
      }
    }),
    _useState10 = _slicedToArray(_useState1, 2),
    bestScore = _useState10[0],
    setBestScore = _useState10[1];
  var _useState11 = useState(0),
    _useState12 = _slicedToArray(_useState11, 2),
    xpEarned = _useState12[0],
    setXpEarned = _useState12[1];

  // ============ Persist preferences ============
  useEffect(function () {
    try {
      localStorage.setItem('tq_flappy_color', dragonColor);
    } catch (_unused9) {}
  }, [dragonColor]);
  useEffect(function () {
    try {
      localStorage.setItem('tq_flappy_diff', difficulty);
    } catch (_unused0) {}
  }, [difficulty]);
  useEffect(function () {
    try {
      localStorage.setItem('tq_flappy_muted', muted ? '1' : '0');
    } catch (_unused1) {}
  }, [muted]);

  // ============ Difficulty presets ============
  // Gravity values are PER-FRAME at 60fps reference; the game loop scales
  // them by deltaTime so the feel stays identical at any frame rate.
  var DIFF = {
    easy: {
      gap: 200,
      speed: 1.8,
      gravity: 0.28,
      jump: -5.6,
      spawnGap: 280
    },
    normal: {
      gap: 160,
      speed: 2.3,
      gravity: 0.33,
      jump: -6.0,
      spawnGap: 240
    },
    hard: {
      gap: 130,
      speed: 2.9,
      gravity: 0.40,
      jump: -6.4,
      spawnGap: 210
    }
  };

  // ============ Dragon palette ============
  var COLORS = {
    white: {
      body: '#f5e9d0',
      wing: '#d4c39a',
      eye: '#3a2d1a',
      glow: 'rgba(245, 233, 208, 0.5)',
      name: 'White'
    },
    blue: {
      body: '#6a96c4',
      wing: '#3f648c',
      eye: '#0a1a30',
      glow: 'rgba(106, 150, 196, 0.5)',
      name: 'Blue'
    },
    shadow: {
      body: '#6a4a8a',
      wing: '#3d2a55',
      eye: '#000',
      glow: 'rgba(154, 108, 192, 0.5)',
      name: 'Shadow'
    },
    red: {
      body: '#c0453f',
      wing: '#8a2d29',
      eye: '#1a0606',
      glow: 'rgba(192, 69, 63, 0.6)',
      name: 'Red'
    },
    green: {
      body: '#7faf4f',
      wing: '#4f7530',
      eye: '#0a1a06',
      glow: 'rgba(127, 175, 79, 0.5)',
      name: 'Green'
    }
  };

  // ============ Audio (WebAudio - tiny synthesised tones) ============
  var initAudio = function initAudio() {
    if (audioCtxRef.current || muted) return;
    try {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (AC) audioCtxRef.current = new AC();
    } catch (_unused10) {}
  };
  var playBeep = function playBeep(freq, dur) {
    var type = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 'square';
    var vol = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 0.05;
    if (muted) return;
    var ctx = audioCtxRef.current;
    if (!ctx || ctx.state === 'closed') return;
    try {
      var o = ctx.createOscillator();
      var g = ctx.createGain();
      o.type = type;
      o.frequency.value = freq;
      g.gain.setValueAtTime(vol, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
      o.connect(g).connect(ctx.destination);
      o.start();
      o.stop(ctx.currentTime + dur);
    } catch (_unused11) {}
  };
  var playSweep = function playSweep(f1, f2, dur) {
    var type = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 'sawtooth';
    var vol = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : 0.08;
    if (muted) return;
    var ctx = audioCtxRef.current;
    if (!ctx || ctx.state === 'closed') return;
    try {
      var o = ctx.createOscillator();
      var g = ctx.createGain();
      o.type = type;
      o.frequency.setValueAtTime(f1, ctx.currentTime);
      o.frequency.exponentialRampToValueAtTime(f2, ctx.currentTime + dur);
      g.gain.setValueAtTime(vol, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
      o.connect(g).connect(ctx.destination);
      o.start();
      o.stop(ctx.currentTime + dur);
    } catch (_unused12) {}
  };
  var sfx = {
    flap: function flap() {
      return playBeep(420, 0.08, 'square', 0.06);
    },
    score: function score() {
      playBeep(880, 0.06, 'triangle', 0.07);
      setTimeout(function () {
        return playBeep(1320, 0.08, 'triangle', 0.06);
      }, 60);
    },
    coin: function coin() {
      playBeep(1320, 0.05, 'sine', 0.08);
      setTimeout(function () {
        return playBeep(1760, 0.08, 'sine', 0.08);
      }, 50);
    },
    hit: function hit() {
      return playSweep(200, 50, 0.35, 'sawtooth', 0.12);
    },
    start: function start() {
      playBeep(660, 0.08, 'triangle', 0.06);
      setTimeout(function () {
        return playBeep(880, 0.10, 'triangle', 0.06);
      }, 80);
    }
  };

  // ============ Resize canvas to container ============
  var resizeCanvas = function resizeCanvas() {
    var canvas = canvasRef.current;
    var container = containerRef.current;
    if (!canvas || !container) return;
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var rect = container.getBoundingClientRect();
    var w = Math.max(rect.width, 320);
    var h = Math.max(rect.height, 400);
    canvas.width = Math.floor(w * dpr);
    canvas.height = Math.floor(h * dpr);
    canvas.style.width = w + 'px';
    canvas.style.height = h + 'px';
    var ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (stateRef.current) {
      stateRef.current.W = w;
      stateRef.current.H = h;
    }
  };

  // ============ Reset game state ============
  var resetState = function resetState() {
    var canvas = canvasRef.current;
    if (!canvas) return;
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var W = canvas.width / dpr;
    var H = canvas.height / dpr;
    var diff = DIFF[difficulty];
    stateRef.current = {
      W: W,
      H: H,
      diff: diff,
      _lastT: 0,
      dragon: {
        x: W * 0.28,
        y: H * 0.45,
        vy: 0,
        rot: 0,
        flapT: 0,
        wingPhase: 0
      },
      pipes: [],
      coins: [],
      particles: [],
      stars: Array.from({
        length: 40
      }, function () {
        return {
          x: Math.random() * W,
          y: Math.random() * H * 0.7,
          s: 0.5 + Math.random() * 1.2,
          twinkle: Math.random() * Math.PI * 2
        };
      }),
      score: 0,
      coinsCollected: 0,
      groundOffset: 0,
      cloudOffset: 0,
      spawnTimer: 0,
      flashAlpha: 0,
      shakeAmount: 0,
      tick: 0,
      dead: false
    };
  };

  // ============ Game loop ============
  var _loop = function loop() {
    var s = stateRef.current;
    var canvas = canvasRef.current;
    if (!s || !canvas) {
      rafRef.current = null;
      return;
    }
    // Frame-rate independence: dt is "how many 60fps frames worth of time
    // has passed since the last tick". At 60fps dt = 1, at 30fps dt = 2,
    // at 120fps dt = 0.5. We multiply all per-frame deltas by it.
    var now = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    var dt = 1;
    if (s._lastT) {
      dt = (now - s._lastT) / (1000 / 60);
      // Clamp to avoid huge jumps after tab pause or first frame
      if (dt < 0.1) dt = 0.1;
      if (dt > 3) dt = 3;
    }
    s._lastT = now;
    var ctx = canvas.getContext('2d');
    var W = s.W,
      H = s.H,
      diff = s.diff;
    s.tick++;

    // ====== Physics ======
    if (!s.dead) {
      s.dragon.vy += diff.gravity * dt;
      // Terminal velocity cap
      if (s.dragon.vy > 10) s.dragon.vy = 10;
      s.dragon.y += s.dragon.vy * dt;
      // Rotation based on vy
      var targetRot = Math.max(-0.5, Math.min(1.0, s.dragon.vy * 0.10));
      s.dragon.rot += (targetRot - s.dragon.rot) * 0.18 * dt;
      s.dragon.flapT = Math.max(0, s.dragon.flapT - dt);
      // A real beat: fast while the flap is live, slow glide between taps.
      s.dragon.wingPhase += dt * (s.dragon.flapT > 0 ? 0.42 : 0.12);

      // Spawn pipes
      s.spawnTimer -= diff.speed * dt;
      if (s.spawnTimer <= 0) {
        s.spawnTimer = diff.spawnGap;
        var minTop = 60;
        var maxTop = H - 100 - diff.gap;
        var topH = minTop + Math.random() * (maxTop - minTop);
        s.pipes.push({
          x: W + 30,
          topH: topH,
          bottomY: topH + diff.gap,
          scored: false
        });
        // 35% chance: spawn a coin in the middle of the gap
        if (Math.random() < 0.35) {
          s.coins.push({
            x: W + 30 + 60,
            y: topH + diff.gap / 2,
            taken: false,
            t: 0
          });
        }
      }

      // Move pipes
      for (var i = s.pipes.length - 1; i >= 0; i--) {
        var p = s.pipes[i];
        p.x -= diff.speed * dt;
        // Scoring (when dragon passes a pipe's center)
        if (!p.scored && p.x + 30 < s.dragon.x) {
          p.scored = true;
          s.score++;
          sfx.score();
          // Spawn score sparkle
          for (var k = 0; k < 6; k++) {
            s.particles.push({
              x: s.dragon.x + 16,
              y: s.dragon.y,
              vx: (Math.random() - 0.5) * 2.5,
              vy: -Math.random() * 2 - 1,
              life: 30,
              max: 30,
              color: 'var(--tq-gold-bright)',
              size: 2 + Math.random() * 2
            });
          }
        }
        if (p.x < -80) s.pipes.splice(i, 1);
      }

      // Move coins
      for (var _i = s.coins.length - 1; _i >= 0; _i--) {
        var c = s.coins[_i];
        c.x -= diff.speed * dt;
        c.t += 0.1 * dt;
        var _dx = s.dragon.x - c.x;
        var _dy = s.dragon.y - c.y;
        if (!c.taken && Math.sqrt(_dx * _dx + _dy * _dy) < 22) {
          c.taken = true;
          s.coinsCollected++;
          sfx.coin();
          // Burst of gold particles
          for (var _k = 0; _k < 8; _k++) {
            s.particles.push({
              x: c.x,
              y: c.y,
              vx: (Math.random() - 0.5) * 3.5,
              vy: (Math.random() - 0.5) * 3.5,
              life: 25,
              max: 25,
              color: 'var(--tq-gold-bright)',
              size: 2 + Math.random() * 2
            });
          }
        }
        if (c.x < -40 || c.taken) s.coins.splice(_i, 1);
      }

      // Collision detection
      var dr = 14; // dragon hit radius
      var dx = s.dragon.x;
      var dy = s.dragon.y;
      // Ground / ceiling
      if (dy + dr > H - 40 || dy - dr < 0) {
        die();
      }
      // Pipe collision
      var _iterator = _createForOfIteratorHelper(s.pipes),
        _step;
      try {
        for (_iterator.s(); !(_step = _iterator.n()).done;) {
          var _p = _step.value;
          if (dx + dr > _p.x && dx - dr < _p.x + 60) {
            if (dy - dr < _p.topH || dy + dr > _p.bottomY) {
              die();
              break;
            }
          }
        }
      } catch (err) {
        _iterator.e(err);
      } finally {
        _iterator.f();
      }
    }

    // ====== Update visual scrolling ======
    s.groundOffset = (s.groundOffset + diff.speed) % 40;
    s.cloudOffset = (s.cloudOffset + diff.speed * 0.3) % W;
    var _iterator2 = _createForOfIteratorHelper(s.stars),
      _step2;
    try {
      for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
        var star = _step2.value;
        star.twinkle += 0.04;
      }

      // Update particles
    } catch (err) {
      _iterator2.e(err);
    } finally {
      _iterator2.f();
    }
    for (var _i2 = s.particles.length - 1; _i2 >= 0; _i2--) {
      var _p2 = s.particles[_i2];
      _p2.x += _p2.vx;
      _p2.y += _p2.vy;
      _p2.vy += 0.15;
      _p2.life--;
      if (_p2.life <= 0) s.particles.splice(_i2, 1);
    }

    // Decay shake & flash
    if (s.shakeAmount > 0) s.shakeAmount *= 0.85;
    if (s.flashAlpha > 0) s.flashAlpha -= 0.08;

    // ====== Render ======
    render(ctx, s);

    // If dragon is dead and has fallen off-screen, end the game
    if (s.dead && s.dragon.y > H + 50) {
      finishGame(s.score, s.coinsCollected);
      return;
    }

    // Continue gravity even after death (rag-doll fall)
    if (s.dead) {
      s.dragon.vy += diff.gravity * dt;
      s.dragon.y += s.dragon.vy * dt;
      s.dragon.rot += 0.05 * dt;
    }
    rafRef.current = requestAnimationFrame(_loop);
  };

  // ============ Render ============
  var render = function render(ctx, s) {
    var W = s.W,
      H = s.H;
    var color = COLORS[dragonColor];

    // Shake
    var sx = (Math.random() - 0.5) * s.shakeAmount;
    var sy = (Math.random() - 0.5) * s.shakeAmount;
    ctx.save();
    ctx.translate(sx, sy);

    // ====== Background gradient ======
    var grad = ctx.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, '#1a0f2a');
    grad.addColorStop(0.5, '#2d1840');
    grad.addColorStop(1, '#1a0a25');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    // ====== Stars ======
    var _iterator3 = _createForOfIteratorHelper(s.stars),
      _step3;
    try {
      for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
        var star = _step3.value;
        var t = 0.5 + 0.5 * Math.sin(star.twinkle);
        ctx.fillStyle = "rgba(245, 233, 208, ".concat(0.3 + t * 0.5, ")");
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.s * (0.7 + t * 0.5), 0, Math.PI * 2);
        ctx.fill();
      }

      // ====== Mountains (parallax silhouettes) ======
    } catch (err) {
      _iterator3.e(err);
    } finally {
      _iterator3.f();
    }
    ctx.fillStyle = 'rgba(20, 10, 30, 0.7)';
    var baseY = H - 60;
    ctx.beginPath();
    ctx.moveTo(0, baseY);
    for (var x = 0; x <= W; x += 40) {
      var off = (x + s.cloudOffset * 0.5) % (W + 80);
      var hh = 30 + Math.sin(off * 0.02) * 20 + Math.sin(off * 0.05) * 10;
      ctx.lineTo(x, baseY - hh);
    }
    ctx.lineTo(W, baseY);
    ctx.closePath();
    ctx.fill();

    // ====== Pipes (rendered as crystal columns) ======
    var _iterator4 = _createForOfIteratorHelper(s.pipes),
      _step4;
    try {
      for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
        var p = _step4.value;
        drawPipe(ctx, p.x, 0, 60, p.topH, color, true);
        drawPipe(ctx, p.x, p.bottomY, 60, H - 40 - p.bottomY, color, false);
      }

      // ====== Coins ======
    } catch (err) {
      _iterator4.e(err);
    } finally {
      _iterator4.f();
    }
    var _iterator5 = _createForOfIteratorHelper(s.coins),
      _step5;
    try {
      for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
        var c = _step5.value;
        if (c.taken) continue;
        var pulse = 1 + Math.sin(c.t) * 0.15;
        var r = 10 * pulse;
        // Outer glow
        var cg = ctx.createRadialGradient(c.x, c.y, 0, c.x, c.y, r + 6);
        cg.addColorStop(0, 'rgba(245, 217, 143, 0.6)');
        cg.addColorStop(1, 'rgba(245, 217, 143, 0)');
        ctx.fillStyle = cg;
        ctx.beginPath();
        ctx.arc(c.x, c.y, r + 6, 0, Math.PI * 2);
        ctx.fill();
        // Coin body
        ctx.fillStyle = '#f5d98f';
        ctx.beginPath();
        ctx.arc(c.x, c.y, r, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#8a6f3a';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        // Star symbol
        ctx.fillStyle = '#8a6f3a';
        ctx.font = "".concat(Math.floor(r * 1.2), "px serif");
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('✦', c.x, c.y);
      }

      // ====== Ground ======
    } catch (err) {
      _iterator5.e(err);
    } finally {
      _iterator5.f();
    }
    ctx.fillStyle = '#1a0a06';
    ctx.fillRect(0, H - 40, W, 40);
    ctx.strokeStyle = 'rgba(201, 169, 97, 0.4)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, H - 40);
    ctx.lineTo(W, H - 40);
    ctx.stroke();
    // Ground hash marks
    ctx.strokeStyle = 'rgba(154, 135, 101, 0.3)';
    for (var _x = -s.groundOffset; _x < W; _x += 40) {
      ctx.beginPath();
      ctx.moveTo(_x, H - 40);
      ctx.lineTo(_x + 12, H - 30);
      ctx.stroke();
    }

    // ====== Particles ======
    var _iterator6 = _createForOfIteratorHelper(s.particles),
      _step6;
    try {
      for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
        var _p3 = _step6.value;
        var alpha = _p3.life / _p3.max;
        ctx.fillStyle = _p3.color.replace(/[\d.]+\)$/, "".concat(alpha, ")")).replace('#', 'rgba(') || "rgba(245, 217, 143, ".concat(alpha, ")");
        ctx.globalAlpha = alpha;
        ctx.fillStyle = _p3.color;
        ctx.beginPath();
        ctx.arc(_p3.x, _p3.y, _p3.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalAlpha = 1;
      }

      // ====== Dragon ======
    } catch (err) {
      _iterator6.e(err);
    } finally {
      _iterator6.f();
    }
    drawDragon(ctx, s.dragon, color, s.dead);

    // ====== Score ======
    ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
    ctx.font = "bold 56px 'Cinzel', serif";
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    ctx.fillText(String(s.score), W / 2 + 2, 32);
    ctx.fillStyle = '#f5d98f';
    ctx.fillText(String(s.score), W / 2, 30);

    // ====== Coin counter (top-left) ======
    if (s.coinsCollected > 0) {
      ctx.fillStyle = '#f5d98f';
      ctx.font = "bold 18px 'JetBrains Mono', monospace";
      ctx.textAlign = 'left';
      ctx.fillText('✦ ' + s.coinsCollected, 14, 14);
    }

    // ====== Flash overlay ======
    if (s.flashAlpha > 0) {
      ctx.fillStyle = "rgba(255, 100, 100, ".concat(s.flashAlpha, ")");
      ctx.fillRect(0, 0, W, H);
    }
    ctx.restore();
  };

  // ====== Draw a crystal pipe (top or bottom) ======
  var drawPipe = function drawPipe(ctx, x, y, w, h, color, isTop) {
    if (h <= 0) return;
    // Body gradient
    var g = ctx.createLinearGradient(x, 0, x + w, 0);
    g.addColorStop(0, '#3a2840');
    g.addColorStop(0.5, '#5d3d6e');
    g.addColorStop(1, '#3a2840');
    ctx.fillStyle = g;
    ctx.fillRect(x, y, w, h);
    // Edge highlight
    ctx.fillStyle = 'rgba(201, 169, 97, 0.25)';
    ctx.fillRect(x + 4, y, 4, h);
    // Cap at the end facing the gap
    var capH = 16;
    var capY = isTop ? y + h - capH : y;
    var cg = ctx.createLinearGradient(x, capY, x, capY + capH);
    cg.addColorStop(0, '#7a5290');
    cg.addColorStop(1, '#4a2f60');
    ctx.fillStyle = cg;
    ctx.fillRect(x - 4, capY, w + 8, capH);
    ctx.strokeStyle = 'rgba(212, 184, 122, 0.6)';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(x - 4, capY, w + 8, capH);
    // Inner crystal facets
    ctx.strokeStyle = 'rgba(201, 169, 97, 0.15)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x + 18, y);
    ctx.lineTo(x + 18, y + h);
    ctx.moveTo(x + 42, y);
    ctx.lineTo(x + 42, y + h);
    ctx.stroke();
  };

  // ====== Draw the dragon (procedural) ======
  var drawDragon = function drawDragon(ctx, d, color, dead) {
    ctx.save();
    ctx.translate(d.x, d.y);
    ctx.rotate(d.rot);

    // One continuous wing phase, advanced by the game loop. The old code
    // switched time bases between flapping and gliding, which froze the wing
    // at the top of its arc the moment you tapped - so it never looked like
    // it was beating.
    var beat = Math.sin(d.wingPhase || 0);
    var shoulderX = -1, shoulderY = -3;

    // Glow
    var glow = ctx.createRadialGradient(0, 0, 0, 0, 0, 30);
    glow.addColorStop(0, color.glow);
    glow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = glow;
    ctx.fillRect(-32, -32, 64, 64);

    // ---- Far wing, behind the body. Two wings is most of what makes a
    // silhouette read as a dragon rather than a bird.
    drawWing(ctx, shoulderX - 3, shoulderY - 2, beat * 0.85, color, 0.8, -1);

    // ---- Tail: longer than before, with a spade tip.
    ctx.fillStyle = color.wing;
    ctx.beginPath();
    var tw = -2 + beat * 2;           // tail sways against the wing beat
    ctx.beginPath();
    ctx.moveTo(-12, -3);
    ctx.quadraticCurveTo(-22, 1 + tw, -31, -2 + tw * 2);
    ctx.quadraticCurveTo(-25, 3 + tw, -12, 4);
    ctx.closePath();
    ctx.fill();
    // spade tip
    ctx.beginPath();
    ctx.moveTo(-30, -2 + tw * 2);
    ctx.lineTo(-39, -8 + tw * 2);
    ctx.lineTo(-36, -1 + tw * 2);
    ctx.lineTo(-39, 5 + tw * 2);
    ctx.closePath();
    ctx.fill();

    // ---- Body: slimmer and longer. The old ellipse was 16x12, which is why
    // it read as chubby; this is 16x8 with a tapered chest.
    ctx.fillStyle = color.body;
    ctx.beginPath();
    ctx.ellipse(0, 0, 16, 8, -0.06, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = color.wing;
    ctx.lineWidth = 1.4;
    ctx.stroke();

    // Belly
    ctx.fillStyle = 'rgba(255,255,255,0.08)';
    ctx.beginPath();
    ctx.ellipse(0, 3, 9, 3, 0, 0, Math.PI * 2);
    ctx.fill();

    // Back ridge
    ctx.fillStyle = color.wing;
    for (var r = 0; r < 3; r++) {
      var rx = -8 + r * 6;
      ctx.beginPath();
      ctx.moveTo(rx - 2, -6);
      ctx.lineTo(rx, -10);
      ctx.lineTo(rx + 2, -6);
      ctx.closePath();
      ctx.fill();
    }

    // ---- Neck and head, set forward and slightly raised.
    ctx.fillStyle = color.body;
    ctx.beginPath();
    ctx.moveTo(9, -4);
    ctx.quadraticCurveTo(16, -8, 19, -8);
    ctx.lineTo(19, -2);
    ctx.quadraticCurveTo(14, -1, 10, 3);
    ctx.closePath();
    ctx.fill();

    ctx.beginPath();
    ctx.ellipse(21, -7, 7, 5, -0.12, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = color.wing;
    ctx.lineWidth = 1.3;
    ctx.stroke();

    // Snout
    ctx.fillStyle = color.body;
    ctx.beginPath();
    ctx.moveTo(25, -9);
    ctx.quadraticCurveTo(31, -8, 31, -5);
    ctx.quadraticCurveTo(28, -3.5, 24, -4);
    ctx.closePath();
    ctx.fill();

    // Horns, swept back
    ctx.fillStyle = color.wing;
    ctx.beginPath();
    ctx.moveTo(19.5, -11);
    ctx.quadraticCurveTo(14, -17, 9, -19);
    ctx.quadraticCurveTo(15, -14, 16.5, -10);
    ctx.closePath();
    ctx.fill();
    ctx.beginPath();
    ctx.moveTo(23, -10.5);
    ctx.quadraticCurveTo(18, -16, 13, -17.5);
    ctx.quadraticCurveTo(19, -13, 20.5, -9.5);
    ctx.closePath();
    ctx.fill();

    // Hind leg
    ctx.fillStyle = color.wing;
    ctx.beginPath();
    ctx.ellipse(-4, 7, 4.5, 3, 0.3, 0, Math.PI * 2);
    ctx.fill();

    // ---- Near wing, in front of the body.
    drawWing(ctx, shoulderX, shoulderY, beat, color, 1, 1);

    // ---- Eye
    ctx.fillStyle = color.eye;
    ctx.beginPath();
    ctx.arc(23, -8, 1.7, 0, Math.PI * 2);
    ctx.fill();
    if (!dead) {
      ctx.fillStyle = '#fff';
      ctx.beginPath();
      ctx.arc(23.6, -8.6, 0.7, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.strokeStyle = color.eye;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(21.5, -9.5);
      ctx.lineTo(24.5, -6.5);
      ctx.moveTo(24.5, -9.5);
      ctx.lineTo(21.5, -6.5);
      ctx.stroke();
    }

    // Mouth opens on the downbeat of a flap
    if (d.flapT > 0 && !dead) {
      ctx.fillStyle = '#3a1a1a';
      ctx.beginPath();
      ctx.ellipse(28, -4.5, 2.4, 1.3, 0, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  };

  /**
   * One wing. Drawn as a fixed membrane shape and rotated about the shoulder,
   * which is how a wing actually moves - the earlier attempts interpolated the
   * tip position and the fan collapsed into a spike at the extremes.
   * `beat` is -1 (up) to +1 (down).
   */
  var drawWing = function drawWing(ctx, sx, sy, beat, color, scale, side) {
    ctx.save();
    ctx.translate(sx, sy);
    ctx.scale(scale, scale);
    ctx.rotate(-beat * 0.85);
    ctx.globalAlpha = side < 0 ? 0.45 : 1;

    // Membrane: leading arm out to the tip, then three scallops back to the
    // shoulder along the trailing edge.
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(-12, -16, -30, -15);
    ctx.quadraticCurveTo(-22, -6, -19, -3);
    ctx.quadraticCurveTo(-15, 4, -11, 1);
    ctx.quadraticCurveTo(-7, 8, -3, 4);
    ctx.quadraticCurveTo(-1, 3, 0, 0);
    ctx.closePath();
    ctx.fillStyle = color.body;
    ctx.fill();
    var a = ctx.globalAlpha;
    ctx.globalAlpha = a * 0.28;
    ctx.fillStyle = '#ffffff';
    ctx.fill();
    ctx.globalAlpha = a;

    // Finger struts
    ctx.strokeStyle = color.wing;
    ctx.lineWidth = 1;
    var fingers = [[-19, -3], [-11, 1], [-3, 4]];
    for (var f = 0; f < fingers.length; f++) {
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(-6, -6, fingers[f][0], fingers[f][1]);
      ctx.stroke();
    }

    // Leading arm, the heaviest line on the wing
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.quadraticCurveTo(-12, -16, -30, -15);
    ctx.stroke();

    // Wrist claw
    ctx.fillStyle = color.wing;
    ctx.beginPath();
    ctx.moveTo(-30, -15);
    ctx.lineTo(-36, -18);
    ctx.lineTo(-29, -12);
    ctx.closePath();
    ctx.fill();

    ctx.globalAlpha = 1;
    ctx.restore();
  };

  // ============ Input handlers ============
  var lastFlapAtRef = useRef(0);
  var FLAP_COOLDOWN_MS = 150;
  var flap = function flap() {
    var s = stateRef.current;
    if (!s || s.dead) return;
    var now = Date.now();
    if (now - lastFlapAtRef.current < FLAP_COOLDOWN_MS) return;
    lastFlapAtRef.current = now;
    s.dragon.vy = s.diff.jump;
    s.dragon.flapT = 6;
    s.dragon.wingPhase = Math.PI / 2;
    sfx.flap();
    haptic(10);
  };
  var die = function die() {
    var s = stateRef.current;
    if (!s || s.dead) return;
    s.dead = true;
    s.flashAlpha = 0.7;
    s.shakeAmount = 14;
    sfx.hit();
    haptic([0, 30, 50, 30]);
    if (window.TQ && typeof window.TQ.stopDragonMusic === 'function') {
      window.TQ.stopDragonMusic();
    }
  };
  var finishGame = function finishGame(score, coinsCol) {
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    var totalXp = score * 4 + coinsCol * 10;
    setFinalScore(score);
    setXpEarned(totalXp);
    if (score > bestScore) {
      setBestScore(score);
      try {
        localStorage.setItem('tq_flappy_best_v2', String(score));
      } catch (_unused13) {}
    }
    if (pet && totalXp > 0) {
      setPet(function (prev) {
        return prev ? _objectSpread(_objectSpread({}, prev), {}, {
          xp: (prev.xp || 0) + totalXp
        }) : prev;
      });
    }
    setPhase('gameover');
  };
  var startGame = function startGame() {
    initAudio();
    if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume().catch(function () {});
    }
    resizeCanvas();
    resetState();
    setPhase('playing');
    sfx.start();
    haptic(15);
    // Start background music (Hoots-Force-inspired chiptune)
    if (!muted && window.TQ && typeof window.TQ.startDragonMusic === 'function') {
      window.TQ.startDragonMusic();
    }
    // Initial flap to kick things off
    setTimeout(function () {
      return flap();
    }, 100);
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(_loop);
  };

  // ============ Effects ============
  useEffect(function () {
    resizeCanvas();
    var onResize = function onResize() {
      return resizeCanvas();
    };
    window.addEventListener('resize', onResize);
    window.addEventListener('orientationchange', onResize);
    return function () {
      window.removeEventListener('resize', onResize);
      window.removeEventListener('orientationchange', onResize);
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      if (window.TQ && typeof window.TQ.stopDragonMusic === 'function') {
        window.TQ.stopDragonMusic();
      }
      if (audioCtxRef.current) {
        try {
          audioCtxRef.current.close();
        } catch (_unused14) {}
      }
    };
  }, []);

  // Tap handler on canvas
  var onCanvasPointer = function onCanvasPointer(e) {
    e.preventDefault();
    if (phase === 'playing') flap();
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 flex flex-col",
    style: {
      zIndex: 140,
      background: 'radial-gradient(ellipse at top, #1a0f2a 0%, #050308 100%)',
      animation: 'sanctumIn 0.3s ease-out'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between px-4 py-3",
    style: {
      borderBottom: '1px solid rgba(201, 169, 97, 0.2)',
      background: 'rgba(10, 6, 4, 0.6)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      haptic(15);
      onClose();
    },
    className: "w-10 h-10 flex items-center justify-center active:scale-90",
    style: {
      background: 'rgba(10, 6, 4, 0.8)',
      border: '1px solid rgba(201, 169, 97, 0.4)',
      borderRadius: '3px',
      color: 'var(--tq-gold)',
      cursor: 'pointer'
    },
    "aria-label": "Close"
  }, "\u2715"), /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-3"
  }, /*#__PURE__*/React.createElement("div", {
    className: "text-center"
  }, /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] tracking-[0.25em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: 'var(--tq-ink-mid)'
    }
  }, "Best"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "'JetBrains Mono', monospace",
      color: 'var(--tq-gold-deep)',
      fontSize: '1rem',
      fontWeight: 700
    }
  }, bestScore))), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      haptic(10);
      setMuted(function (m) {
        var next = !m;
        if (next && window.TQ && typeof window.TQ.stopDragonMusic === 'function') {
          window.TQ.stopDragonMusic();
        }
        return next;
      });
    },
    className: "w-10 h-10 flex items-center justify-center active:scale-90",
    style: {
      background: 'rgba(10, 6, 4, 0.8)',
      border: '1px solid rgba(201, 169, 97, 0.4)',
      borderRadius: '3px',
      color: muted ? 'var(--tq-ink-faint)' : 'var(--tq-gold)',
      cursor: 'pointer'
    },
    "aria-label": muted ? 'Unmute' : 'Mute'
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '1rem'
    }
  }, muted ? '♪̸' : '♪'))), /*#__PURE__*/React.createElement("div", {
    ref: containerRef,
    className: "relative flex-1 overflow-hidden",
    style: {
      touchAction: 'manipulation'
    },
    onMouseDown: onCanvasPointer,
    onTouchStart: onCanvasPointer
  }, /*#__PURE__*/React.createElement("canvas", {
    ref: canvasRef,
    style: {
      display: 'block',
      width: '100%',
      height: '100%'
    }
  }), phase === 'menu' && /*#__PURE__*/React.createElement("div", {
    className: "absolute inset-0 flex flex-col items-center justify-center px-6",
    style: {
      background: 'radial-gradient(ellipse at center, rgba(10, 6, 4, 0.5) 0%, rgba(10, 6, 4, 0.85) 100%)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-full max-w-xs px-5 py-6 text-center",
    style: {
      background: 'linear-gradient(180deg, rgba(26, 17, 10, 0.98), rgba(10, 6, 4, 0.98))',
      border: '1px solid rgba(201, 169, 97, 0.5)',
      borderRadius: '4px',
      boxShadow: '0 0 40px rgba(212, 184, 122, 0.2), 0 20px 40px rgba(0,0,0,0.6)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    className: "text-lg mb-1",
    style: {
      fontFamily: "'Cinzel', serif",
      color: 'var(--tq-gold-bright)',
      fontWeight: 700,
      letterSpacing: '0.15em'
    }
  }, "FLAPPY DRAGON"), /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] italic mb-5",
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: 'var(--tq-ink-mid)'
    }
  }, "Soar through crystal pillars . Collect starlight"), /*#__PURE__*/React.createElement("p", {
    className: "text-[9px] tracking-[0.2em] uppercase mb-2",
    style: {
      fontFamily: "'Cinzel', serif",
      color: 'var(--tq-ink-warm)'
    }
  }, "Dragon"), /*#__PURE__*/React.createElement("div", {
    className: "flex justify-center gap-1.5 mb-5"
  }, Object.entries(COLORS).map(function (_ref17) {
    var _ref18 = _slicedToArray(_ref17, 2),
      key = _ref18[0],
      c = _ref18[1];
    return /*#__PURE__*/React.createElement("button", {
      key: key,
      onClick: function onClick() {
        haptic(10);
        setDragonColor(key);
      },
      className: "w-10 h-10 active:scale-90",
      style: {
        background: dragonColor === key ? "radial-gradient(circle at 30% 30%, ".concat(c.body, ", ").concat(c.wing, ")") : c.body,
        border: dragonColor === key ? '2px solid var(--tq-gold-bright)' : '1px solid rgba(201, 169, 97, 0.3)',
        borderRadius: '50%',
        boxShadow: dragonColor === key ? "0 0 16px ".concat(c.glow) : 'none',
        cursor: 'pointer'
      },
      "aria-label": c.name
    });
  })), /*#__PURE__*/React.createElement("p", {
    className: "text-[9px] tracking-[0.2em] uppercase mb-2",
    style: {
      fontFamily: "'Cinzel', serif",
      color: 'var(--tq-ink-warm)'
    }
  }, "Difficulty"), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-3 gap-1.5 mb-6"
  }, ['easy', 'normal', 'hard'].map(function (d) {
    var active = difficulty === d;
    return /*#__PURE__*/React.createElement("button", {
      key: d,
      onClick: function onClick() {
        haptic(10);
        setDifficulty(d);
      },
      className: "py-2 text-[10px] tracking-[0.15em] uppercase active:scale-95",
      style: {
        fontFamily: "'Cinzel', serif",
        fontWeight: active ? 700 : 500,
        color: active ? 'var(--tq-surface-deep)' : 'var(--tq-gold)',
        background: active ? 'linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))' : 'transparent',
        border: "1px solid ".concat(active ? 'var(--tq-gold)' : 'rgba(201, 169, 97, 0.3)'),
        borderRadius: '2px',
        cursor: 'pointer'
      }
    }, d);
  })), /*#__PURE__*/React.createElement("button", {
    onClick: startGame,
    className: "w-full py-3 text-[11px] tracking-[0.3em] uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 700,
      color: 'var(--tq-surface-deep)',
      background: 'linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))',
      border: '1px solid var(--tq-gold)',
      borderRadius: '3px',
      boxShadow: '0 4px 12px rgba(201, 169, 97, 0.3), inset 0 1px 0 rgba(255,255,255,0.2)',
      cursor: 'pointer'
    }
  }, "Begin Flight"))), phase === 'gameover' && /*#__PURE__*/React.createElement("div", {
    className: "absolute inset-0 flex flex-col items-center justify-center px-6",
    style: {
      background: 'radial-gradient(ellipse at center, rgba(10, 6, 4, 0.6) 0%, rgba(10, 6, 4, 0.92) 100%)',
      animation: 'sanctumIn 0.3s ease-out'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-full max-w-xs px-5 py-5 text-center",
    style: {
      background: 'linear-gradient(180deg, rgba(26, 17, 10, 0.98), rgba(10, 6, 4, 0.98))',
      border: '1px solid rgba(201, 169, 97, 0.5)',
      borderRadius: '4px',
      boxShadow: '0 0 40px rgba(212, 184, 122, 0.2), 0 20px 40px rgba(0,0,0,0.6)'
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] tracking-[0.3em] uppercase mb-1",
    style: {
      fontFamily: "'Cinzel', serif",
      color: 'var(--tq-danger)',
      fontWeight: 600
    }
  }, finalScore > bestScore - 1 && finalScore >= bestScore ? '✦ New Best ✦' : 'The dragon falls'), /*#__PURE__*/React.createElement("p", {
    className: "text-5xl mb-2",
    style: {
      fontFamily: "'Cinzel', serif",
      color: 'var(--tq-gold-bright)',
      fontWeight: 800,
      letterSpacing: '0.05em'
    }
  }, finalScore), /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] tracking-[0.2em] uppercase mb-3",
    style: {
      fontFamily: "'Cinzel', serif",
      color: 'var(--tq-ink-mid)'
    }
  }, "Score"), xpEarned > 0 && pet && /*#__PURE__*/React.createElement("p", {
    className: "text-xs mb-4",
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: 'var(--tq-life)',
      fontStyle: 'italic'
    }
  }, "Your companion gained +", xpEarned, " XP"), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-2 gap-2"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      haptic(15);
      setPhase('menu');
    },
    className: "py-3 text-[10px] tracking-[0.2em] uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 600,
      color: 'var(--tq-gold)',
      background: 'transparent',
      border: '1px solid rgba(201, 169, 97, 0.4)',
      borderRadius: '2px',
      cursor: 'pointer'
    }
  }, "Menu"), /*#__PURE__*/React.createElement("button", {
    onClick: startGame,
    className: "py-3 text-[10px] tracking-[0.2em] uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 700,
      color: 'var(--tq-surface-deep)',
      background: 'linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))',
      border: '1px solid var(--tq-gold)',
      borderRadius: '2px',
      boxShadow: '0 2px 8px rgba(201, 169, 97, 0.3)',
      cursor: 'pointer'
    }
  }, "Fly Again"))))), phase === 'playing' && /*#__PURE__*/React.createElement("div", {
    className: "absolute left-1/2 -translate-x-1/2 pointer-events-none",
    style: {
      bottom: 'calc(50% - 100px)',
      opacity: stateRef.current && stateRef.current.tick < 60 ? 0.6 : 0,
      transition: 'opacity 0.4s'
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] italic tracking-widest uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: 'var(--tq-gold)'
    }
  }, "tap to flap")));
};

// ============ Zombie Jumper — Castlevania Platformer ============
// Sprite sheets - pixel art, gothic Castlevania palette
// ============ Keyword Index ============
var KEYWORDS = [{
  k: "Deathtouch",
  t: "Any amount of damage this creature deals to a creature is enough to destroy it."
}, {
  k: "Defender",
  t: "This creature can't attack."
}, {
  k: "Double Strike",
  t: "This creature deals both first-strike and regular combat damage."
}, {
  k: "First Strike",
  t: "This creature deals combat damage before creatures without first strike."
}, {
  k: "Flash",
  t: "You may cast this spell any time you could cast an instant."
}, {
  k: "Flying",
  t: "This creature can't be blocked except by creatures with flying or reach."
}, {
  k: "Haste",
  t: "This creature can attack and use tap/untap abilities the turn it enters the battlefield."
}, {
  k: "Hexproof",
  t: "This permanent can't be the target of spells or abilities your opponents control."
}, {
  k: "Indestructible",
  t: "Effects that say 'destroy' don't destroy this permanent. It can't be destroyed by lethal damage."
}, {
  k: "Lifelink",
  t: "Damage dealt by this creature also causes you to gain that much life."
}, {
  k: "Menace",
  t: "This creature can't be blocked except by two or more creatures."
}, {
  k: "Reach",
  t: "This creature can block creatures with flying."
}, {
  k: "Shroud",
  t: "This permanent can't be the target of spells or abilities."
}, {
  k: "Skulk",
  t: "This creature can't be blocked by creatures with greater power."
}, {
  k: "Trample",
  t: "This creature can deal excess combat damage to the player or planeswalker it's attacking."
}, {
  k: "Undying",
  t: "When this creature dies, if it had no +1/+1 counters, return it with a +1/+1 counter."
}, {
  k: "Persist",
  t: "When this creature dies, if it had no -1/-1 counters, return it with a -1/-1 counter."
}, {
  k: "Vigilance",
  t: "Attacking doesn't cause this creature to tap."
}, {
  k: "Ward",
  t: "Whenever this permanent becomes the target of a spell or ability an opponent controls, counter it unless that player pays the ward cost."
}, {
  k: "Prowess",
  t: "Whenever you cast a noncreature spell, this creature gets +1/+1 until end of turn."
}, {
  k: "Toxic",
  t: "Creatures with toxic deal poison counters equal to their toxic value when they deal combat damage."
}, {
  k: "Infect",
  t: "This creature deals damage to creatures in the form of -1/-1 counters and to players in the form of poison counters."
}, {
  k: "Annihilator",
  t: "Whenever this creature attacks, the defending player sacrifices a number of permanents equal to the annihilator value."
}, {
  k: "Cascade",
  t: "When you cast this spell, exile cards from the top of your library until you exile a cheaper card. You may cast it without paying its mana cost."
}, {
  k: "Convoke",
  t: "Your creatures can help cast this spell. Each creature you tap while casting it pays for 1 or one mana of that creature's colour."
}, {
  k: "Cycling",
  t: "Pay the cycling cost and discard this card to draw a card."
}, {
  k: "Equip",
  t: "Pay the equip cost as a sorcery to attach this Equipment to a creature you control."
}, {
  k: "Evolve",
  t: "Whenever a creature enters the battlefield under your control with greater power or toughness than this creature, put a +1/+1 counter on this creature."
}, {
  k: "Exploit",
  t: "When this creature enters the battlefield, you may sacrifice a creature."
}, {
  k: "Extort",
  t: "Whenever you cast a spell, you may pay one white or black mana. If you do, each opponent loses 1 life and you gain life equal to the total lost."
}, {
  k: "Fabricate",
  t: "When this creature enters the battlefield, put a +1/+1 counter on it or create a Servo artifact creature token."
}, {
  k: "Flashback",
  t: "You may cast this spell from your graveyard for its flashback cost. Then exile it."
}, {
  k: "Foretell",
  t: "During your turn, you may pay 2 mana and exile this card face down. Cast it later for its foretell cost."
}, {
  k: "Kicker",
  t: "You may pay the kicker cost as you cast this spell for an additional effect."
}, {
  k: "Landfall",
  t: "Triggered ability that fires whenever a land enters the battlefield under your control."
}, {
  k: "Modular",
  t: "This creature enters with +1/+1 counters. When it dies, put its counters on a target artifact creature."
}, {
  k: "Morph",
  t: "You may cast this face down as a 2/2 creature for 3 mana. Turn it face up at any time for its morph cost."
}, {
  k: "Mutate",
  t: "If you cast this for its mutate cost, put it over or under a non-Human creature you own. They mutate into the combined creature."
}, {
  k: "Overload",
  t: "You may cast this spell for its overload cost. If you do, change the target to all applicable targets instead."
}, {
  k: "Partner",
  t: "You can have two commanders if both have partner."
}, {
  k: "Phasing",
  t: "This permanent phases out at the beginning of each of its controller's untap steps (alternating in and out)."
}, {
  k: "Populate",
  t: "Create a token that's a copy of a creature token you control."
}, {
  k: "Protection",
  t: "This can't be damaged, enchanted, equipped, blocked, or targeted by anything with the specified quality."
}, {
  k: "Proliferate",
  t: "Choose any number of permanents and/or players with counters, then give each another counter of each kind already there."
}, {
  k: "Regenerate",
  t: "The next time this creature would be destroyed, instead tap it, remove it from combat, and remove all damage from it."
}, {
  k: "Scry",
  t: "Look at the top N cards of your library. Put any of them on the bottom of your library and the rest back on top in any order."
}, {
  k: "Storm",
  t: "When you cast this spell, copy it for each other spell cast before it this turn."
}, {
  k: "Suspend",
  t: "Pay the suspend cost and exile with time counters. Each turn, remove one. When the last is removed, cast it for free."
}, {
  k: "Threshold",
  t: "This ability is active if you have seven or more cards in your graveyard."
}, {
  k: "Token",
  t: "A game piece created by a spell or ability. Tokens are not cards and cease to exist when they leave the battlefield."
}, {
  k: "Totem Armor",
  t: "If the enchanted permanent would be destroyed, instead remove all damage from it and destroy this aura."
}, {
  k: "Transmute",
  t: "Discard this card and pay the transmute cost to search your library for a card with the same mana value."
}];
var KeywordIndex = function KeywordIndex() {
  var _React$useState33 = React.useState(""),
    _React$useState34 = _slicedToArray(_React$useState33, 2),
    search = _React$useState34[0],
    setSearch = _React$useState34[1];
  var _React$useState35 = React.useState(null),
    _React$useState36 = _slicedToArray(_React$useState35, 2),
    expanded = _React$useState36[0],
    setExpanded = _React$useState36[1];
  var filtered = search.trim() ? KEYWORDS.filter(function (k) {
    return k.k.toLowerCase().includes(search.toLowerCase());
  }) : KEYWORDS;
  return /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2 mb-3"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-1 h-4",
    style: {
      background: "linear-gradient(180deg, var(--tq-gold-deep), var(--tq-gold) 50%, transparent)",
      borderRadius: "1px",
      boxShadow: "0 0 4px rgba(212, 184, 122, 0.3)"
    }
  }), /*#__PURE__*/React.createElement("h2", {
    className: "text-[10px] sm:text-xs tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      fontWeight: 600
    }
  }, "Keyword Index"), /*#__PURE__*/React.createElement("span", {
    className: "text-[9px]",
    style: {
      color: "var(--tq-ink-faint)",
      fontFamily: "'JetBrains Mono', monospace"
    }
  }, filtered.length)), /*#__PURE__*/React.createElement("div", {
    className: "relative mb-2"
  }, /*#__PURE__*/React.createElement("input", {
    type: "text",
    value: search,
    onChange: function onChange(e) {
      setSearch(e.target.value);
      setExpanded(null);
    },
    placeholder: "Search keywords...",
    className: "search-green w-full bg-transparent pl-8 pr-3 py-2 text-sm outline-none",
    style: {
      fontFamily: "'Crimson Pro', serif",
      border: "1px solid rgba(201, 169, 97, 0.3)",
      borderRadius: "2px",
      background: "rgba(20, 14, 8, 0.6)"
    }
  }), /*#__PURE__*/React.createElement(Search, {
    style: {
      position: 'absolute',
      left: '0.625rem',
      top: '50%',
      transform: 'translateY(-50%)',
      color: "var(--tq-ink-faint)",
      fontSize: '0.875rem'
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "flex flex-col gap-1"
  }, filtered.map(function (kw) {
    return /*#__PURE__*/React.createElement("div", {
      key: kw.k,
      style: {
        background: "rgba(20, 14, 8, 0.6)",
        border: "1px solid ".concat(expanded === kw.k ? "rgba(201, 169, 97, 0.4)" : "rgba(201, 169, 97, 0.18)"),
        borderRadius: "2px",
        overflow: 'hidden',
        transition: 'border-color 0.2s'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return setExpanded(expanded === kw.k ? null : kw.k);
      },
      className: "w-full flex items-center justify-between px-3 py-2 text-left active:scale-[0.99]"
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'Cinzel', serif",
        color: "var(--tq-gold-deep)",
        fontSize: "0.8rem",
        fontWeight: 600,
        letterSpacing: "0.05em"
      }
    }, kw.k), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--tq-ink-faint)",
        fontSize: "0.7rem",
        transition: 'transform 0.2s',
        transform: expanded === kw.k ? 'rotate(180deg)' : 'none'
      }
    }, "v")), expanded === kw.k && /*#__PURE__*/React.createElement("div", {
      className: "px-3 pb-2.5"
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: "'Crimson Pro', serif",
        color: "#c9b899",
        fontSize: "0.85rem",
        lineHeight: 1.55,
        fontStyle: "italic"
      }
    }, kw.t)));
  }), filtered.length === 0 && /*#__PURE__*/React.createElement("p", {
    className: "text-center py-4 italic text-sm",
    style: {
      color: "var(--tq-ink-faint)",
      fontFamily: "'Crimson Pro', serif"
    }
  }, "No keywords found.")));
};

// ============ App ============

// ============ COMMANDER VAULT ============

// ─── Colour definitions ───────────────────────────────────────────────────────
var COLORS = {
  W: {
    label: "White",
    symbol: "☀️",
    hex: "#F9FAF4",
    border: "#C8B560",
    text: "#5a4a00"
  },
  U: {
    label: "Blue",
    symbol: "💧",
    hex: "#0E68AB",
    border: "#3A8FC7",
    text: "#ffffff"
  },
  B: {
    label: "Black",
    symbol: "💀",
    hex: "#1A1A1A",
    border: "#6B6B6B",
    text: "#cccccc"
  },
  R: {
    label: "Red",
    symbol: "🔥",
    hex: "#D3202A",
    border: "#FF5050",
    text: "#ffffff"
  },
  G: {
    label: "Green",
    symbol: "🌲",
    hex: "#00733E",
    border: "#00A854",
    text: "#ffffff"
  },
  C: {
    label: "Colorless",
    symbol: "◇",
    hex: "#9A9A9A",
    border: "#C0C0C0",
    text: "#ffffff"
  }
};

// ─── All colour combinations ──────────────────────────────────────────────────
// The Commander Vault now lives in src/vault/ and is bundled into
// www/modules.js. app.js renders an empty div and calls
// window.TQ.mountVault(el) - the same seam the Reference tab uses.

function TokenTracker() {
  var _players$find, _players$find2, _COLOR_LORE$PET_TYPES;
  // Hide any initial loading screen and handle startup
  React.useEffect(function () {
    try {
      // EMERGENCY DEBUG - Shows alert on device
      var debugInfo = {
        reactMounted: true,
        timestamp: new Date().toISOString(),
        hasPlayers: true,
        hasBattlefield: true
      };

      // Uncomment to see debug info:
      // alert(`App Debug:\n${JSON.stringify(debugInfo, null, 2)}`);

      // Hide Capacitor splash screen if available
      if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.SplashScreen) {
        window.Capacitor.Plugins.SplashScreen.hide();
      }

      // Hide loading screen
      var loadingEl = document.getElementById('initial-loading');
      if (loadingEl) {
        loadingEl.style.display = 'none';
      }

      // Also try common splash screen IDs
      var splashEl = document.getElementById('splash-screen');
      if (splashEl) splashEl.style.display = 'none';
      var summoningEl = document.querySelector('[class*="summoning"]');
      if (summoningEl) summoningEl.style.display = 'none';

      // Force hide any overlay
      document.body.style.overflow = 'auto';
    } catch (e) {
      console.error('Startup error:', e);
      alert("STARTUP ERROR: ".concat(e.message));
    }
  }, []);
  var _useState33 = useState(""),
    _useState34 = _slicedToArray(_useState33, 2),
    query = _useState34[0],
    setQuery = _useState34[1];
  var _useState35 = useState([]),
    _useState36 = _slicedToArray(_useState35, 2),
    results = _useState36[0],
    setResults = _useState36[1];
  var _useState37 = useState(false),
    _useState38 = _slicedToArray(_useState37, 2),
    loading = _useState38[0],
    setLoading = _useState38[1];
  var _useState39 = useState(""),
    _useState40 = _slicedToArray(_useState39, 2),
    error = _useState40[0],
    setError = _useState40[1];
  var _useState41 = useState(function () {
      return storage.get('battlefield') || [];
    }),
    _useState42 = _slicedToArray(_useState41, 2),
    battlefield = _useState42[0],
    setBattlefield = _useState42[1];
  var _useState43 = useState(function () {
      return storage.get('favourites') || [];
    }),
    _useState44 = _slicedToArray(_useState43, 2),
    favourites = _useState44[0],
    setFavourites = _useState44[1];
  var _useState45 = useState(""),
    _useState46 = _slicedToArray(_useState45, 2),
    activeSearch = _useState46[0],
    setActiveSearch = _useState46[1];
  var _useState47 = useState(true),
    _useState48 = _slicedToArray(_useState47, 2),
    showSearch = _useState48[0],
    setShowSearch = _useState48[1];
  // Copy-token modal state
  var _useState49 = useState(false),
    _useState50 = _slicedToArray(_useState49, 2),
    copyOpen = _useState50[0],
    setCopyOpen = _useState50[1];
  var _useState51 = useState(""),
    _useState52 = _slicedToArray(_useState51, 2),
    copyQuery = _useState52[0],
    setCopyQuery = _useState52[1];
  var _useState53 = useState([]),
    _useState54 = _slicedToArray(_useState53, 2),
    copyResults = _useState54[0],
    setCopyResults = _useState54[1];
  var _useState55 = useState(false),
    _useState56 = _slicedToArray(_useState55, 2),
    copyLoading = _useState56[0],
    setCopyLoading = _useState56[1];
  var _useState57 = useState(""),
    _useState58 = _slicedToArray(_useState57, 2),
    copyError = _useState58[0],
    setCopyError = _useState58[1];
  var _useState59 = useState("tokens"),
    _useState60 = _slicedToArray(_useState59, 2),
    copyScope = _useState60[0],
    setCopyScope = _useState60[1]; // "tokens" | "creatures"
  // Batch 1 additions
  var _useState61 = useState(null),
    _useState62 = _slicedToArray(_useState61, 2),
    numpadFor = _useState62[0],
    setNumpadFor = _useState62[1]; // token id being edited, or null
  var _useState63 = useState(""),
    _useState64 = _slicedToArray(_useState63, 2),
    numpadValue = _useState64[0],
    setNumpadValue = _useState64[1];
  var _useState65 = useState(false),
    _useState66 = _slicedToArray(_useState65, 2),
    wipeConfirmOpen = _useState66[0],
    setWipeConfirmOpen = _useState66[1];
  var _useState67 = useState([]),
    _useState68 = _slicedToArray(_useState67, 2),
    undoStack = _useState68[0],
    setUndoStack = _useState68[1]; // stack of previous battlefield snapshots
  var _useState69 = useState(""),
    _useState70 = _slicedToArray(_useState69, 2),
    toast = _useState70[0],
    setToast = _useState70[1]; // tiny ephemeral message

  // Batch 2: active tab
  var _useState71 = useState(function () {
      return storage.get('activeTab') || 'battlefield';
    }),
    _useState72 = _slicedToArray(_useState71, 2),
    activeTab = _useState72[0],
    setActiveTab = _useState72[1]; // 'battlefield' | 'life' | 'tools'

  // ===== New state for settings, onboarding, FAB, sanctum tabs =====
  var _useState73 = useState(function () {
      return storage.get('settings') || {
        hapticIntensity: 'normal',
        // 'off' | 'light' | 'normal' | 'strong'
        fontSize: 'normal',
        // 'small' | 'normal' | 'large'
        showScrollTop: true,
        showOnboarding: true
      };
    }),
    _useState74 = _slicedToArray(_useState73, 2),
    settings = _useState74[0],
    setSettings = _useState74[1];
  var _useState75 = useState(false),
    _useState76 = _slicedToArray(_useState75, 2),
    settingsOpen = _useState76[0],
    setSettingsOpen = _useState76[1];
  var _useState77 = useState(function () {
      var seen = storage.get('onboardingSeen');
      if (seen) return -1;
      // Only show onboarding for truly new users (no battlefield, no players, no pet)
      var hasBattlefield = (storage.get('battlefield') || []).length > 0;
      var hasPet = !!storage.get('tq_pet_v1');
      var hasGameState = !!storage.get('lifeTotals');
      if (hasBattlefield || hasPet || hasGameState) {
        // Returning user - mark onboarding seen silently
        storage.set('onboardingSeen', true);
        return -1;
      }
      return 0;
    }),
    _useState78 = _slicedToArray(_useState77, 2),
    onboardingStep = _useState78[0],
    setOnboardingStep = _useState78[1];
  var _useState79 = useState(false),
    _useState80 = _slicedToArray(_useState79, 2),
    showScrollTop = _useState80[0],
    setShowScrollTop = _useState80[1];
  var _useState81 = useState('companion'),
    _useState82 = _slicedToArray(_useState81, 2),
    sanctumTab = _useState82[0],
    setSanctumTab = _useState82[1]; // 'companion' | 'games' | 'stats'
  // Save settings whenever changed
  useEffect(function () {
    storage.set('settings', settings);
  }, [settings]);
  useEffect(function () {
    if (onboardingStep === -1) storage.set('onboardingSeen', true);
  }, [onboardingStep]);
  // Track scroll position for FAB visibility
  useEffect(function () {
    var onScroll = function onScroll() {
      return setShowScrollTop(window.scrollY > 500);
    };
    window.addEventListener('scroll', onScroll, {
      passive: true
    });
    return function () {
      return window.removeEventListener('scroll', onScroll);
    };
  }, []);

  // Batch 2: life tracker state
  var defaultPlayers = function defaultPlayers(n) {
    return Array.from({
      length: n
    }, function (_, i) {
      return {
        id: "p".concat(i + 1),
        name: "Player ".concat(i + 1),
        life: 40,
        color: ["var(--tq-danger)", "var(--tq-info)", "var(--tq-gold-deep)", "var(--tq-life)"][i % 4],
        poison: 0,
        energy: 0,
        experience: 0,
        commanderTax: 0
      };
    });
  };
  var _useState83 = useState(function () {
      return storage.get('players') || defaultPlayers(4);
    }),
    _useState84 = _slicedToArray(_useState83, 2),
    players = _useState84[0],
    setPlayers = _useState84[1];
  var _useState85 = useState(function () {
      return storage.get('player_flipped') || [false, false, false, false];
    }),
    _useState86 = _slicedToArray(_useState85, 2),
    playerFlipped = _useState86[0],
    setPlayerFlipped = _useState86[1];
  var _tqBigInit = (function () { try { return localStorage.getItem('tq_bigpicture') === '1'; } catch (e) { return false; } })();
  var _useStateBP = useState(_tqBigInit),
    _useStateBPArr = _slicedToArray(_useStateBP, 2),
    bigPicture = _useStateBPArr[0],
    setBigPictureRaw = _useStateBPArr[1];
  var setBigPicture = function setBigPicture(v) {
    setBigPictureRaw(v);
    try { localStorage.setItem('tq_bigpicture', v ? '1' : '0'); } catch (e) {}
  };
  var _useStateBPM = useState(false),
    _useStateBPMArr = _slicedToArray(_useStateBPM, 2),
    bigPictureMenu = _useStateBPMArr[0],
    setBigPictureMenu = _useStateBPMArr[1];
  var _useState87 = useState([]),
    _useState88 = _slicedToArray(_useState87, 2),
    lifeHistory = _useState88[0],
    setLifeHistory = _useState88[1]; // last 5 life changes for undo
  var _useState89 = useState(false),
    _useState90 = _slicedToArray(_useState89, 2),
    showResetConfirm = _useState90[0],
    setShowResetConfirm = _useState90[1]; // confirmation modal for reset
  var _useState91 = useState(false),
    _useState92 = _slicedToArray(_useState91, 2),
    showNewGameMenu = _useState92[0],
    setShowNewGameMenu = _useState92[1]; // new game setup menu
  // Life delta tally -- { [playerId]: { delta: number, timer: timeoutId } }
  var _useState93 = useState({}),
    _useState94 = _slicedToArray(_useState93, 2),
    lifeDelta = _useState94[0],
    setLifeDelta = _useState94[1];
  var lifeDeltaTimers = useRef({});
  // commanderDamage[dealtToId][dealtByPlayerId] = amount
  var _useState95 = useState(function () {
      return storage.get('commanderDamage') || {};
    }),
    _useState96 = _slicedToArray(_useState95, 2),
    commanderDamage = _useState96[0],
    setCommanderDamage = _useState96[1];
  var _useState97 = useState(null),
    _useState98 = _slicedToArray(_useState97, 2),
    cmdrDamageFor = _useState98[0],
    setCmdrDamageFor = _useState98[1]; // which player's CD grid is open
  var _useState99 = useState(null),
    _useState100 = _slicedToArray(_useState99, 2),
    editPlayerName = _useState100[0],
    setEditPlayerName = _useState100[1];
  var _useState101 = useState(""),
    _useState102 = _slicedToArray(_useState101, 2),
    editPlayerNameValue = _useState102[0],
    setEditPlayerNameValue = _useState102[1];

  // Batch 2: dice state
  var _useState103 = useState([]),
    _useState104 = _slicedToArray(_useState103, 2),
    diceRolls = _useState104[0],
    setDiceRolls = _useState104[1]; // rolling history (latest first, max 10)
  var _useState105 = useState(null),
    _useState106 = _slicedToArray(_useState105, 2),
    rolling = _useState106[0],
    setRolling = _useState106[1]; // sides currently animating

  // Batch 2: phase + turn
  var PHASES = ['Untap', 'Upkeep', 'Draw', 'Main 1', 'Combat', 'Main 2', 'End'];
  var _useState107 = useState(function () {
      var _storage$get;
      return (_storage$get = storage.get('phaseIndex')) !== null && _storage$get !== void 0 ? _storage$get : 0;
    }),
    _useState108 = _slicedToArray(_useState107, 2),
    phaseIndex = _useState108[0],
    setPhaseIndex = _useState108[1];
  var _useState109 = useState(function () {
      return storage.get('turnNumber') || 1;
    }),
    _useState110 = _slicedToArray(_useState109, 2),
    turnNumber = _useState110[0],
    setTurnNumber = _useState110[1];
  var _useState111 = useState(function () {
      return storage.get('activePlayerIndex') || 0;
    }),
    _useState112 = _slicedToArray(_useState111, 2),
    activePlayerIndex = _useState112[0],
    setActivePlayerIndex = _useState112[1];

  // Batch 3 state
  // Day/Night: 'day' | 'night' | null (no daybound game)
  var _useState113 = useState(function () {
      return storage.get('dayNight') || null;
    }),
    _useState114 = _slicedToArray(_useState113, 2),
    dayNight = _useState114[0],
    setDayNight = _useState114[1];
  // Game state markers -- independent toggles per player
  // monarch: playerId | null
  // initiative: playerId | null
  // citysBlessing: array of playerIds
  var _useState115 = useState(function () {
      return storage.get('monarch') || null;
    }),
    _useState116 = _slicedToArray(_useState115, 2),
    monarch = _useState116[0],
    setMonarch = _useState116[1];
  var _useState117 = useState(function () {
      return storage.get('initiative') || null;
    }),
    _useState118 = _slicedToArray(_useState117, 2),
    initiative = _useState118[0],
    setInitiative = _useState118[1];
  var _useState119 = useState(function () {
      return storage.get('citysBlessing') || [];
    }),
    _useState120 = _slicedToArray(_useState119, 2),
    citysBlessing = _useState120[0],
    setCitysBlessing = _useState120[1];
  var _useState121 = useState(0),
    _useState122 = _slicedToArray(_useState121, 2),
    stormCount = _useState122[0],
    setStormCount = _useState122[1];
  var _useState123 = useState({
      W: 0,
      U: 0,
      B: 0,
      R: 0,
      G: 0,
      C: 0
    }),
    _useState124 = _slicedToArray(_useState123, 2),
    manaPool = _useState124[0],
    setManaPool = _useState124[1];

  // Deck presets -- { id, name, tokens: [token shape with id+name+image+pt+colors] }
  var _useState125 = useState(function () {
      return storage.get('presets') || [];
    }),
    _useState126 = _slicedToArray(_useState125, 2),
    presets = _useState126[0],
    setPresets = _useState126[1];
  var _useState127 = useState(false),
    _useState128 = _slicedToArray(_useState127, 2),
    presetMenuOpen = _useState128[0],
    setPresetMenuOpen = _useState128[1];
  var _useState129 = useState(false),
    _useState130 = _slicedToArray(_useState129, 2),
    savePresetOpen = _useState130[0],
    setSavePresetOpen = _useState130[1];
  var _useState131 = useState(""),
    _useState132 = _slicedToArray(_useState131, 2),
    savePresetName = _useState132[0],
    setSavePresetName = _useState132[1];

  // Oracle text and zoom modals
  var _useState133 = useState(null),
    _useState134 = _slicedToArray(_useState133, 2),
    oracleFor = _useState134[0],
    setOracleFor = _useState134[1]; // token id
  var _useState135 = useState(""),
    _useState136 = _slicedToArray(_useState135, 2),
    oracleText = _useState136[0],
    setOracleText = _useState136[1];
  var _useState137 = useState(false),
    _useState138 = _slicedToArray(_useState137, 2),
    oracleLoading = _useState138[0],
    setOracleLoading = _useState138[1];
  var _useState139 = useState(null),
    _useState140 = _slicedToArray(_useState139, 2),
    zoomImage = _useState140[0],
    setZoomImage = _useState140[1]; // { url, tokenId } or null

  // Secret menu (The Sanctum) -- unlocked by 7 taps on the title within 3s
  var _useState141 = useState(false),
    _useState142 = _slicedToArray(_useState141, 2),
    sanctumOpen = _useState142[0],
    setSanctumOpen = _useState142[1];
  var _useState143 = useState(false),
    _useState144 = _slicedToArray(_useState143, 2),
    hatcheryDoorOpen = _useState144[0],
    setHatcheryDoorOpen = _useState144[1];
  // Games
  var _useState145 = useState(false),
    _useState146 = _slicedToArray(_useState145, 2),
    memoryOpen = _useState146[0],
    setMemoryOpen = _useState146[1];
  var _useState147 = useState(false),
    _useState148 = _slicedToArray(_useState147, 2),
    dragonOpen = _useState148[0],
    setDragonOpen = _useState148[1];
  var _useState149 = useState(0),
    _useState150 = _slicedToArray(_useState149, 2),
    titleTapCount = _useState150[0],
    setTitleTapCount = _useState150[1];
  var titleTapResetRef = useRef(null);
  // The tap count also lives in a ref. Reading it from state meant two taps
  // landing in the same React batch both saw the same value, so one of them
  // was silently dropped -- which is why the door sometimes needed an eighth tap.
  var titleTapRef = useRef(0);

  // --------- COMPANION PET SYSTEM ---------
  // Pet state. null until hatched.
  // Shape: { core: 'W'|'U'|'B'|'R'|'G', name: string, hatchedAt: number,
  //          xp: number, lastFedAt: number, lastPlayedAt: number,
  //          affinities: { W:n, U:n, B:n, R:n, G:n } }
  var _useState151 = useState(function () {
      return storage.get('pet');
    }),
    _useState152 = _slicedToArray(_useState151, 2),
    pet = _useState152[0],
    setPet = _useState152[1];

  // Discovery (Tier 2): WUBRG order puzzle inside Sanctum
  // unlockedOrbs is the array of correctly-tapped orb colours so far in current attempt
  var _useState153 = useState([]),
    _useState154 = _slicedToArray(_useState153, 2),
    unlockedOrbs = _useState154[0],
    setUnlockedOrbs = _useState154[1];
  var _useState155 = useState(false),
    _useState156 = _slicedToArray(_useState155, 2),
    showDiscoveryHint = _useState156[0],
    setShowDiscoveryHint = _useState156[1];
  var _useState157 = useState(false),
    _useState158 = _slicedToArray(_useState157, 2),
    hatchingOpen = _useState158[0],
    setHatchingOpen = _useState158[1];
  var _useState159 = useState(null),
    _useState160 = _slicedToArray(_useState159, 2),
    chosenCore = _useState160[0],
    setChosenCore = _useState160[1]; // during ceremony
  var _useState161 = useState([]),
    _useState162 = _slicedToArray(_useState161, 2),
    ceremonyStarters = _useState162[0],
    setCeremonyStarters = _useState162[1]; // 3 petType keys
  var _useState163 = useState(null),
    _useState164 = _slicedToArray(_useState163, 2),
    chosenType = _useState164[0],
    setChosenType = _useState164[1]; // chosen petType key
  var _useState165 = useState(false),
    _useState166 = _slicedToArray(_useState165, 2),
    hatchAnimating = _useState166[0],
    setHatchAnimating = _useState166[1];

  // Pet UI -- open the pet view directly (sets sanctumOpen + scrolls to pet section)
  var _useState167 = useState(false),
    _useState168 = _slicedToArray(_useState167, 2),
    petResetConfirmOpen = _useState168[0],
    setPetResetConfirmOpen = _useState168[1];
  var _useState169 = useState(false),
    _useState170 = _slicedToArray(_useState169, 2),
    petRenameOpen = _useState170[0],
    setPetRenameOpen = _useState170[1];
  var _useState171 = useState(""),
    _useState172 = _slicedToArray(_useState171, 2),
    petNameInput = _useState172[0],
    setPetNameInput = _useState172[1];
  var _useState173 = useState(false),
    _useState174 = _slicedToArray(_useState173, 2),
    showPetAdvanced = _useState174[0],
    setShowPetAdvanced = _useState174[1];

  // Pet hint timer ref
  var petHintTimerRef = useRef(null);
  // Force re-render every minute so age/hunger displays stay current
  var _useState175 = useState(0),
    _useState176 = _slicedToArray(_useState175, 2),
    setPetTick = _useState176[1];
  useEffect(function () {
    var i = setInterval(function () {
      return setPetTick(function (t) {
        return t + 1;
      });
    }, 60 * 1000);
    return function () {
      return clearInterval(i);
    };
  }, []);

  // Persist pet
  useEffect(function () {
    if (pet) storage.set('pet', pet);else storage.set('pet', null);
  }, [pet]);

  // Show hint after 5 seconds inside Sanctum (only if pet hasn't hatched)
  useEffect(function () {
    if (sanctumOpen && !pet) {
      petHintTimerRef.current = setTimeout(function () {
        return setShowDiscoveryHint(true);
      }, 5000);
    } else {
      setShowDiscoveryHint(false);
      setUnlockedOrbs([]);
      if (petHintTimerRef.current) clearTimeout(petHintTimerRef.current);
    }
    return function () {
      if (petHintTimerRef.current) clearTimeout(petHintTimerRef.current);
    };
  }, [sanctumOpen, pet]);

  // --- Pet action handlers ---
  // WUBRG order puzzle. Wrong tap = reset.
  var handleOrbTap = function handleOrbTap(colour) {
    var expectedOrder = ['W', 'U', 'B', 'R', 'G'];
    var nextExpected = expectedOrder[unlockedOrbs.length];
    if (colour === nextExpected) {
      haptic(15);
      var newLit = [].concat(_toConsumableArray(unlockedOrbs), [colour]);
      setUnlockedOrbs(newLit);
      if (newLit.length === 5) {
        // All 5 lit -- celebratory fanfare + open ceremony
        haptic([30, 50, 30, 50, 100]);
        if (window.TQ && typeof window.TQ.playFanfare === 'function') {
          window.TQ.playFanfare();
        }
        setTimeout(function () {
          setCeremonyStarters(pickCeremonyStarters());
          setChosenType(null);
          setHatchingOpen(true);
        }, 350);
      }
    } else {
      // Wrong order -- reset
      haptic([40, 80]);
      setUnlockedOrbs([]);
    }
  };

  // Hatch the egg with a chosen core colour
  var hatchPet = function hatchPet(petTypeKey) {
    haptic([30, 50, 30, 50, 100]);
    var typeData = PET_TYPES[petTypeKey];
    var core = (typeData === null || typeData === void 0 ? void 0 : typeData.color) || 'G';
    var now = Date.now();
    var newPet = {
      core: core,
      petType: petTypeKey,
      name: null,
      hatchedAt: now,
      xp: 0,
      lastFedAt: now,
      lastPlayedAt: now,
      affinities: {
        W: 0,
        U: 0,
        B: 0,
        R: 0,
        G: 0
      }
    };
    setPet(newPet);
    setHatchingOpen(false);
    setChosenCore(null);
    setUnlockedOrbs([]);
    showToast("Your ".concat((typeData === null || typeData === void 0 ? void 0 : typeData.name) || 'companion', " has awakened!"));
  };

  // Feed cooldown 12h
  var FEED_COOLDOWN_MS = 12 * 60 * 60 * 1000;
  // Play cooldown 6h
  var PLAY_COOLDOWN_MS = 6 * 60 * 60 * 1000;
  var feedPet = function feedPet() {
    if (!pet) return;
    var now = Date.now();
    if (now - pet.lastFedAt < FEED_COOLDOWN_MS) {
      haptic(15);
      showToast('Not hungry yet');
      return;
    }
    haptic(30);
    setPet(_objectSpread(_objectSpread({}, pet), {}, {
      lastFedAt: now,
      xp: (pet.xp || 0) + 5
    }));
    showToast('Your companion is sated');
  };
  var playWithPet = function playWithPet() {
    if (!pet) return;
    var now = Date.now();
    if (now - pet.lastPlayedAt < PLAY_COOLDOWN_MS) {
      haptic(15);
      showToast('Resting from play');
      return;
    }
    haptic([15, 30, 15]);
    setPet(_objectSpread(_objectSpread({}, pet), {}, {
      lastPlayedAt: now,
      xp: (pet.xp || 0) + 8
    }));
    showToast('Your companion delights in the play');
  };
  var renamePet = function renamePet() {
    if (!pet) return;
    var trimmed = petNameInput.trim().slice(0, 20);
    if (!trimmed) return;
    haptic(20);
    // Secret: rename to EMRAKUL -> transform to colorless Null
    if (trimmed.toUpperCase() === 'EMRAKUL') {
      haptic([30, 50, 30, 80, 120]);
      setPet(_objectSpread(_objectSpread({}, pet), {}, {
        name: 'Emrakul',
        core: 'C',
        petType: 'eldrazi'
      }));
      setPetRenameOpen(false);
      setPetNameInput("");
      showToast("Something ancient stirs...");
      return;
    }
    setPet(_objectSpread(_objectSpread({}, pet), {}, {
      name: trimmed
    }));
    setPetRenameOpen(false);
    setPetNameInput("");
    showToast("Named: ".concat(trimmed));
  };

  // Dev mode handlers
  var devSkipJuvenile = function devSkipJuvenile() {
    if (!pet) return;
    haptic(20);
    // Set hatchedAt to 8 days ago (just past juvenile threshold)
    var eightDaysAgo = Date.now() - 8 * 24 * 60 * 60 * 1000;
    setPet(_objectSpread(_objectSpread({}, pet), {}, {
      hatchedAt: eightDaysAgo,
      xp: Math.max(pet.xp || 0, 150)
    }));
    showToast("Skipped to Juvenile");
  };
  var devSkipAdult = function devSkipAdult() {
    if (!pet) return;
    haptic(20);
    var twentyTwoDaysAgo = Date.now() - 22 * 24 * 60 * 60 * 1000;
    setPet(_objectSpread(_objectSpread({}, pet), {}, {
      hatchedAt: twentyTwoDaysAgo,
      xp: Math.max(pet.xp || 0, 600)
    }));
    showToast("Skipped to Adult");
  };
  var devResetFeedCD = function devResetFeedCD() {
    if (!pet) return;
    haptic(15);
    var thirteenHoursAgo = Date.now() - 13 * 60 * 60 * 1000;
    setPet(_objectSpread(_objectSpread({}, pet), {}, {
      lastFedAt: thirteenHoursAgo
    }));
    showToast("Feed cooldown reset");
  };
  var devResetPlayCD = function devResetPlayCD() {
    if (!pet) return;
    haptic(15);
    var sevenHoursAgo = Date.now() - 7 * 60 * 60 * 1000;
    setPet(_objectSpread(_objectSpread({}, pet), {}, {
      lastPlayedAt: sevenHoursAgo
    }));
    showToast("Play cooldown reset");
  };
  var resetPet = function resetPet() {
    haptic([50, 50, 80]);
    setPet(null);
    setUnlockedOrbs([]);
    setPetResetConfirmOpen(false);
    setShowPetAdvanced(false);
    showToast('Your egg has returned to the aether');
  };

  // Pet stat helpers (using lazy decay model)
  var petHunger = function petHunger(p) {
    if (!p) return 100;
    var since = Date.now() - p.lastFedAt;
    return Math.max(0, Math.min(100, 100 - since / FEED_COOLDOWN_MS * 100));
  };
  var petHappiness = function petHappiness(p) {
    if (!p) return 100;
    var since = Date.now() - p.lastPlayedAt;
    return Math.max(0, Math.min(100, 100 - since / PLAY_COOLDOWN_MS * 100));
  };
  var feedReady = function feedReady(p) {
    return p && Date.now() - p.lastFedAt >= FEED_COOLDOWN_MS;
  };
  var playReady = function playReady(p) {
    return p && Date.now() - p.lastPlayedAt >= PLAY_COOLDOWN_MS;
  };

  // Track battlefield additions for affinity growth + colour-match reaction
  var lastBattlefieldTotal = useRef(0);
  useEffect(function () {
    if (!pet) {
      lastBattlefieldTotal.current = battlefield.reduce(function (s, t) {
        return s + t.count;
      }, 0);
      return;
    }
    var total = battlefield.reduce(function (s, t) {
      return s + t.count;
    }, 0);
    var delta = total - lastBattlefieldTotal.current;
    if (delta > 0) {
      // Distribute affinity by current battlefield colour mix
      var mix = {
        W: 0,
        U: 0,
        B: 0,
        R: 0,
        G: 0
      };
      battlefield.forEach(function (t) {
        if (Array.isArray(t.colors)) t.colors.forEach(function (c) {
          if (mix[c] !== undefined) mix[c] += 1;
        });
      });
      var total2 = Object.values(mix).reduce(function (s, v) {
        return s + v;
      }, 0) || 1;
      var newAff = _objectSpread({}, pet.affinities);
      Object.keys(mix).forEach(function (c) {
        newAff[c] = (newAff[c] || 0) + mix[c] / total2 * delta;
      });
      // Colour-match bonus: if pet's core colour is in the mix, bonus XP + toast
      var core = pet.core || 'G';
      var matchBonus = mix[core] ? Math.ceil(mix[core] / total2 * delta * 2) : 0;
      var totalXp = (pet.xp || 0) + delta + matchBonus;
      setPet(_objectSpread(_objectSpread({}, pet), {}, {
        xp: totalXp,
        affinities: newAff
      }));
      // Show toast only when there's a meaningful colour match (core colour tokens were added)
      if (matchBonus > 0 && mix[core] >= 1) {
        var _COLOR_DATA$core;
        var colorName = ((_COLOR_DATA$core = COLOR_DATA[core]) === null || _COLOR_DATA$core === void 0 ? void 0 : _COLOR_DATA$core.name) || core;
        var matchToasts = {
          W: "Your companion feels the light.",
          U: "Your companion stirs with curiosity.",
          B: "Your companion's eyes gleam.",
          R: "Your companion sparks with energy!",
          G: "Your companion feels the wild surge.",
          C: "[RESONANCE DETECTED]"
        };
        showToast(matchToasts[core] || "Your companion stirs.");
      }
    }
    lastBattlefieldTotal.current = total;
  }, [battlefield, pet]);

  // Counter types -- pre-defined plus custom adders. Stored per token in t.counters = { [type]: count }
  // We track which counter type panels are expanded per token via t.expandedCounters (array of type ids)
  // Default counters are +1/+1 and -1/-1 (already represented as powerMod/toughnessMod)
  // Additional types: charge, loyalty, poison, time, fade, ice, quest, lore
  var COUNTER_TYPES = [{
    id: 'charge',
    label: 'Charge',
    short: 'CHG',
    color: 'var(--tq-info)'
  }, {
    id: 'loyalty',
    label: 'Loyalty',
    short: 'LOY',
    color: 'var(--tq-gold-deep)'
  }, {
    id: 'poison',
    label: 'Poison',
    short: 'PSN',
    color: 'var(--tq-life-deep)'
  }, {
    id: 'time',
    label: 'Time',
    short: 'TIME',
    color: '#c9a9c9'
  }, {
    id: 'lore',
    label: 'Lore',
    short: 'LORE',
    color: 'var(--tq-ink)'
  }, {
    id: 'quest',
    label: 'Quest',
    short: 'QST',
    color: 'var(--tq-danger-soft)'
  }];
  var debounceRef = useRef(null);
  var copyDebounceRef = useRef(null);
  var wakeLockRef = useRef(null);
  var toastTimerRef = useRef(null);
  var diceTimerRef = useRef(null);

  // Persist tab selection + game state
  useEffect(function () {
    storage.set('activeTab', activeTab);
    // Migrated modules in www/modules.js need to be able to change tabs -
    // the Vault's Odds button jumps to the simulator with a deck in hand.
    window.TQ = window.TQ || {};
    window.TQ.setTab = setActiveTab;
  }, [activeTab]);
  useEffect(function () {
    storage.set('players', players);
  }, [players]);
  useEffect(function () {
    storage.set('player_flipped', playerFlipped);
  }, [playerFlipped]);
  useEffect(function () {
    storage.set('commanderDamage', commanderDamage);
  }, [commanderDamage]);
  useEffect(function () {
    storage.set('phaseIndex', phaseIndex);
  }, [phaseIndex]);
  useEffect(function () {
    storage.set('turnNumber', turnNumber);
  }, [turnNumber]);
  useEffect(function () {
    storage.set('activePlayerIndex', activePlayerIndex);
  }, [activePlayerIndex]);
  // Batch 3 persistence
  useEffect(function () {
    storage.set('dayNight', dayNight);
  }, [dayNight]);
  useEffect(function () {
    storage.set('monarch', monarch);
  }, [monarch]);
  useEffect(function () {
    storage.set('initiative', initiative);
  }, [initiative]);
  useEffect(function () {
    storage.set('citysBlessing', citysBlessing);
  }, [citysBlessing]);
  useEffect(function () {
    storage.set('presets', presets);
  }, [presets]);

  // Keep-screen-awake via Screen Wake Lock API
  useEffect(function () {
    var released = false;
    var acquire = /*#__PURE__*/function () {
      var _ref24 = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee() {
        var _t;
        return _regenerator().w(function (_context) {
          while (1) switch (_context.p = _context.n) {
            case 0:
              _context.p = 0;
              if (!('wakeLock' in navigator)) {
                _context.n = 2;
                break;
              }
              _context.n = 1;
              return navigator.wakeLock.request('screen');
            case 1:
              wakeLockRef.current = _context.v;
            case 2:
              _context.n = 4;
              break;
            case 3:
              _context.p = 3;
              _t = _context.v;
            case 4:
              return _context.a(2);
          }
        }, _callee, null, [[0, 3]]);
      }));
      return function acquire() {
        return _ref24.apply(this, arguments);
      };
    }();
    acquire();
    var handleVisibility = function handleVisibility() {
      if (document.visibilityState === 'visible' && !released) acquire();
    };
    document.addEventListener('visibilitychange', handleVisibility);
    return function () {
      released = true;
      document.removeEventListener('visibilitychange', handleVisibility);
      try {
        wakeLockRef.current && wakeLockRef.current.release && wakeLockRef.current.release();
      } catch (_unused17) {}
    };
  }, []);

  // Lock to portrait via Screen Orientation API
  useEffect(function () {
    try {
      if (screen.orientation && screen.orientation.lock) {
        screen.orientation.lock('portrait').catch(function () {});
      }
    } catch (_unused18) {}
  }, []);

  // Inject global CSS (animations + search input colour)
  useEffect(function () {
    if (document.getElementById('tq-global-styles')) return;
    var el = document.createElement('style');
    el.id = 'tq-global-styles';
    el.textContent = ['@keyframes toastIn{from{opacity:0;transform:translate(-50%,10px)}to{opacity:1;transform:translate(-50%,0)}}', '@keyframes sanctumIn{from{opacity:0;transform:scale(0.96)}to{opacity:1;transform:scale(1)}}', '@keyframes petPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.08)}}',
    // Pet creature animations
    '@keyframes petFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}', '@keyframes petEggWobble{0%,100%{transform:rotate(-2deg) translateY(0)}25%{transform:rotate(2deg) translateY(-3px)}50%{transform:rotate(-1.5deg) translateY(-1px)}75%{transform:rotate(1.5deg) translateY(-4px)}}', '@keyframes doorSwing{from{transform:perspective(600px) rotateY(0deg)}to{transform:perspective(600px) rotateY(-115deg)}}', '@keyframes keyholePulse{0%,100%{opacity:0.3}50%{opacity:0.8}}', '@keyframes petBounce{0%{transform:scale(1)}20%{transform:scale(0.88)}60%{transform:scale(1.12)}80%{transform:scale(0.96)}100%{transform:scale(1)}}', '@keyframes petResponseIn{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:translateY(0)}}', '@keyframes lifeDeltaFade{0%{opacity:1;transform:translateY(0) scale(1)}70%{opacity:1;transform:translateY(-12px) scale(1.1)}100%{opacity:0;transform:translateY(-24px) scale(0.9)}}', '@keyframes petKenBurns{0%,100%{transform:scale(1.0) translate(0%,0%)}33%{transform:scale(1.06) translate(-1.5%,0.8%)}66%{transform:scale(1.04) translate(1%,-0.5%)}}', '@keyframes petGlow{0%,100%{opacity:0.85}50%{opacity:1}}', '@keyframes petGlowBox{0%,100%{box-shadow:var(--pet-glow-min)}50%{box-shadow:var(--pet-glow-max)}}', '@keyframes particleRise{0%{transform:translateY(0) translateX(0);opacity:0.9}100%{transform:translateY(-55px) translateX(var(--pdx,0px));opacity:0}}', '@keyframes particleFall{0%{transform:translateY(0);opacity:0.8}100%{transform:translateY(50px);opacity:0}}', '@keyframes particleDrift{0%,100%{transform:translateY(0) translateX(0) rotate(0deg)}50%{transform:translateY(-12px) translateX(var(--pdx,6px)) rotate(180deg)}}', '@keyframes particleTwinkle{0%,100%{opacity:0.2;transform:scale(0.7)}50%{opacity:1;transform:scale(1.2)}}', '@keyframes particleOrbit{0%{transform:rotate(0deg) translateX(var(--pr,20px)) rotate(0deg)}100%{transform:rotate(360deg) translateX(var(--pr,20px)) rotate(-360deg)}}', 'input.search-green{color:#a8d8a0!important}', 'input.search-green::placeholder{color:rgba(168,216,160,0.55)!important;opacity:1}', 'input.search-green::-webkit-input-placeholder{color:rgba(168,216,160,0.55)}'].join('');
    document.head.appendChild(el);
  }, []);

  // Push a snapshot onto the undo stack -- capped at 20 entries
  var pushUndo = function pushUndo(snapshot) {
    setUndoStack(function (prev) {
      var next = [].concat(_toConsumableArray(prev), [snapshot]);
      if (next.length > 20) next.shift();
      return next;
    });
  };
  var showToast = function showToast(msg) {
    var ms = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1800;
    setToast(msg);
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(function () {
      return setToast("");
    }, ms);
  };
  var undo = function undo() {
    if (undoStack.length === 0) return;
    haptic(35);
    setUndoStack(function (prev) {
      var next = _toConsumableArray(prev);
      var snapshot = next.pop();
      if (snapshot) setBattlefield(snapshot);
      return next;
    });
    showToast("Undone");
  };
  useEffect(function () {
    storage.set('battlefield', battlefield);
  }, [battlefield]);
  useEffect(function () {
    storage.set('favourites', favourites);
  }, [favourites]);
  var runSearch = /*#__PURE__*/function () {
    var _ref25 = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee2(searchTerm) {
      var url, res, data, _t2;
      return _regenerator().w(function (_context2) {
        while (1) switch (_context2.p = _context2.n) {
          case 0:
            if (searchTerm.trim()) {
              _context2.n = 1;
              break;
            }
            setResults([]);
            setError("");
            return _context2.a(2);
          case 1:
            setLoading(true);
            setError("");
            setActiveSearch(searchTerm);
            _context2.p = 2;
            url = "https://api.scryfall.com/cards/search?q=".concat(encodeURIComponent("t:token ".concat(searchTerm)), "&unique=art&order=released&dir=desc");
            _context2.n = 3;
            return fetch(url);
          case 3:
            res = _context2.v;
            if (!(res.status === 404)) {
              _context2.n = 4;
              break;
            }
            setResults([]);
            setError("No tokens matching \"".concat(searchTerm, "\""));
            setLoading(false);
            return _context2.a(2);
          case 4:
            if (res.ok) {
              _context2.n = 5;
              break;
            }
            throw new Error("Scryfall error");
          case 5:
            _context2.n = 6;
            return res.json();
          case 6:
            data = _context2.v;
            // Dedupe by oracle_id (stable across reprints) then illustration_id.
            // Scryfall's unique=art still returns multiple "art_crop URLs" for
            // the same artwork across printings; this collapses them properly.
            var seenArt = {};
            var deduped = (data.data || []).filter(function (c) {
              var key = c.oracle_id || c.illustration_id || (c.name + '|' + (c.type_line || ''));
              if (seenArt[key]) return false;
              seenArt[key] = 1;
              return true;
            });
            setResults(deduped.slice(0, 18));
            _context2.n = 8;
            break;
          case 7:
            _context2.p = 7;
            _t2 = _context2.v;
            setError("Couldn't reach Scryfall. Check connection.");
            setResults([]);
          case 8:
            setLoading(false);
          case 9:
            return _context2.a(2);
        }
      }, _callee2, null, [[2, 7]]);
    }));
    return function runSearch(_x2) {
      return _ref25.apply(this, arguments);
    };
  }();
  useEffect(function () {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(function () {
      if (query.trim().length >= 2) runSearch(query);else {
        setResults([]);
        setError("");
      }
    }, 350);
    return function () {
      return clearTimeout(debounceRef.current);
    };
  }, [query]);
  var addToBattlefield = function addToBattlefield(card) {
    haptic(30);
    var token = normalizeCard(card);
    setBattlefield(function (prev) {
      pushUndo(prev);
      var existing = prev.find(function (t) {
        return t.id === token.id;
      });
      if (existing) return prev.map(function (t) {
        return t.id === token.id ? _objectSpread(_objectSpread({}, t), {}, {
          count: t.count + 1
        }) : t;
      });
      return [].concat(_toConsumableArray(prev), [_objectSpread(_objectSpread({}, token), {}, {
        count: 1,
        powerMod: 0,
        toughnessMod: 0,
        ptExpanded: false,
        tapped: false,
        counters: {
          plusOne: 0,
          minusOne: 0
        }
      })]);
    });
  };

  // Add a creature to the battlefield as a COPY -- given a unique id so it stacks separately from any "real" version
  var addAsCopy = function addAsCopy(card) {
    haptic(30);
    var base = normalizeCard(card);
    var copyId = "copy:".concat(base.id, ":").concat(Date.now());
    setBattlefield(function (prev) {
      pushUndo(prev);
      return [].concat(_toConsumableArray(prev), [_objectSpread(_objectSpread({}, base), {}, {
        id: copyId,
        originalId: base.id,
        originalName: base.name,
        isCopy: true,
        count: 1,
        powerMod: 0,
        toughnessMod: 0,
        ptExpanded: false
      })]);
    });
    setCopyOpen(false);
    setCopyQuery("");
    setCopyResults([]);
  };
  var runCopySearch = /*#__PURE__*/function () {
    var _ref26 = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee3(searchTerm, scope) {
      var qParts, url, res, data, _t3;
      return _regenerator().w(function (_context3) {
        while (1) switch (_context3.p = _context3.n) {
          case 0:
            if (searchTerm.trim()) {
              _context3.n = 1;
              break;
            }
            setCopyResults([]);
            setCopyError("");
            return _context3.a(2);
          case 1:
            setCopyLoading(true);
            setCopyError("");
            _context3.p = 2;
            qParts = scope === "tokens" ? "t:token ".concat(searchTerm) : "t:creature ".concat(searchTerm);
            url = "https://api.scryfall.com/cards/search?q=".concat(encodeURIComponent(qParts), "&unique=art&order=released&dir=desc");
            _context3.n = 3;
            return fetch(url);
          case 3:
            res = _context3.v;
            if (!(res.status === 404)) {
              _context3.n = 4;
              break;
            }
            setCopyResults([]);
            setCopyError("No ".concat(scope === "tokens" ? "tokens" : "creatures", " matching \"").concat(searchTerm, "\""));
            setCopyLoading(false);
            return _context3.a(2);
          case 4:
            if (res.ok) {
              _context3.n = 5;
              break;
            }
            throw new Error("Scryfall error");
          case 5:
            _context3.n = 6;
            return res.json();
          case 6:
            data = _context3.v;
            var seenArt3 = {};
            var deduped3 = (data.data || []).filter(function (c) {
              var key = c.oracle_id || c.illustration_id || (c.name + '|' + (c.type_line || ''));
              if (seenArt3[key]) return false;
              seenArt3[key] = 1;
              return true;
            });
            setCopyResults(deduped3.slice(0, 18));
            _context3.n = 8;
            break;
          case 7:
            _context3.p = 7;
            _t3 = _context3.v;
            setCopyError("Couldn't reach Scryfall. Check connection.");
            setCopyResults([]);
          case 8:
            setCopyLoading(false);
          case 9:
            return _context3.a(2);
        }
      }, _callee3, null, [[2, 7]]);
    }));
    return function runCopySearch(_x3, _x4) {
      return _ref26.apply(this, arguments);
    };
  }();
  useEffect(function () {
    if (copyDebounceRef.current) clearTimeout(copyDebounceRef.current);
    copyDebounceRef.current = setTimeout(function () {
      if (copyQuery.trim().length >= 2) runCopySearch(copyQuery, copyScope);else {
        setCopyResults([]);
        setCopyError("");
      }
    }, 350);
    return function () {
      return clearTimeout(copyDebounceRef.current);
    };
  }, [copyQuery, copyScope]);
  var increment = function increment(id) {
    haptic(25);
    setBattlefield(function (prev) {
      pushUndo(prev);
      return prev.map(function (t) {
        return t.id === id ? _objectSpread(_objectSpread({}, t), {}, {
          count: t.count + 1
        }) : t;
      });
    });
  };
  var decrement = function decrement(id) {
    haptic(25);
    setBattlefield(function (prev) {
      pushUndo(prev);
      return prev.map(function (t) {
        return t.id === id ? _objectSpread(_objectSpread({}, t), {}, {
          count: t.count - 1
        }) : t;
      }).filter(function (t) {
        return t.count > 0;
      });
    });
  };
  var setCount = function setCount(id, value) {
    var n = Math.max(0, Math.min(999, parseInt(value, 10) || 0));
    haptic(30);
    setBattlefield(function (prev) {
      pushUndo(prev);
      if (n === 0) return prev.filter(function (t) {
        return t.id !== id;
      });
      return prev.map(function (t) {
        return t.id === id ? _objectSpread(_objectSpread({}, t), {}, {
          count: n
        }) : t;
      });
    });
    showToast("Count set to ".concat(n));
  };
  // Quick delta adjust -- used from the enhanced count modal
  var adjustCount = function adjustCount(id, delta) {
    haptic(15);
    setBattlefield(function (prev) {
      pushUndo(prev);
      var target = prev.find(function (t) {
        return t.id === id;
      });
      if (!target) return prev;
      var next = Math.max(0, Math.min(999, target.count + delta));
      if (next === 0) return prev.filter(function (t) {
        return t.id !== id;
      });
      return prev.map(function (t) {
        return t.id === id ? _objectSpread(_objectSpread({}, t), {}, {
          count: next
        }) : t;
      });
    });
  };
  var adjustPT = function adjustPT(id, which, delta) {
    haptic(20);
    setBattlefield(function (prev) {
      pushUndo(prev);
      return prev.map(function (t) {
        if (t.id !== id) return t;
        var key = which === 'power' ? 'powerMod' : 'toughnessMod';
        return _objectSpread(_objectSpread({}, t), {}, _defineProperty({}, key, (t[key] || 0) + delta));
      });
    });
  };
  var resetPT = function resetPT(id) {
    haptic(30);
    setBattlefield(function (prev) {
      pushUndo(prev);
      return prev.map(function (t) {
        return t.id === id ? _objectSpread(_objectSpread({}, t), {}, {
          powerMod: 0,
          toughnessMod: 0
        }) : t;
      });
    });
  };
  var togglePTExpanded = function togglePTExpanded(id) {
    return setBattlefield(function (prev) {
      return prev.map(function (t) {
        return t.id === id ? _objectSpread(_objectSpread({}, t), {}, {
          ptExpanded: !t.ptExpanded
        }) : t;
      });
    });
  };
  var toggleTapped = function toggleTapped(id) {
    haptic(15);
    setBattlefield(function (prev) {
      return prev.map(function (t) {
        return t.id === id ? _objectSpread(_objectSpread({}, t), {}, {
          tapped: !t.tapped
        }) : t;
      });
    });
  };
  var adjustTokenCounter = function adjustTokenCounter(id, counterType, delta) {
    haptic(10);
    setBattlefield(function (prev) {
      return prev.map(function (t) {
        return t.id === id ? _objectSpread(_objectSpread({}, t), {}, {
          counters: _objectSpread(_objectSpread({}, t.counters || {}), {}, _defineProperty({}, counterType, Math.max(0, ((t.counters || {})[counterType] || 0) + delta)))
        }) : t;
      });
    });
  };
  var removeAll = function removeAll(id) {
    haptic(35);
    setBattlefield(function (prev) {
      pushUndo(prev);
      return prev.filter(function (t) {
        return t.id !== id;
      });
    });
  };
  var requestWipe = function requestWipe() {
    haptic(20);
    setWipeConfirmOpen(true);
  };
  var confirmWipe = function confirmWipe() {
    haptic([30, 30, 30]);
    setBattlefield(function (prev) {
      pushUndo(prev);
      return [];
    });
    setWipeConfirmOpen(false);
    showToast("Battlefield wiped");
  };
  var toggleFavourite = function toggleFavourite(card) {
    haptic(25);
    var token = normalizeCard(card);
    setFavourites(function (prev) {
      var existing = prev.find(function (f) {
        return f.id === token.id;
      });
      if (existing) return prev.filter(function (f) {
        return f.id !== token.id;
      });
      return [].concat(_toConsumableArray(prev), [token]);
    });
  };
  var isFavourite = function isFavourite(id) {
    return favourites.some(function (f) {
      return f.id === id;
    });
  };

  // ---- Batch 2 handlers: Life, Commander Damage, Players, Dice, Phases ----

  var adjustLife = function adjustLife(playerId, delta) {
    haptic(delta > 0 ? 20 : 25);
    // Save to history before changing
    setPlayers(function (prev) {
      setLifeHistory(function (hist) {
        return [].concat(_toConsumableArray(hist.slice(-4)), [{
          players: prev,
          time: Date.now()
        }]);
      }); // keep last 5
      return prev.map(function (p) {
        return p.id === playerId ? _objectSpread(_objectSpread({}, p), {}, {
          life: p.life + delta
        }) : p;
      });
    });
    // Accumulate delta tally + reset 2.5s fade timer
    setLifeDelta(function (prev) {
      var _prev$playerId;
      var current = ((_prev$playerId = prev[playerId]) === null || _prev$playerId === void 0 ? void 0 : _prev$playerId.delta) || 0;
      return _objectSpread(_objectSpread({}, prev), {}, _defineProperty({}, playerId, {
        delta: current + delta
      }));
    });
    if (lifeDeltaTimers.current[playerId]) clearTimeout(lifeDeltaTimers.current[playerId]);
    lifeDeltaTimers.current[playerId] = setTimeout(function () {
      setLifeDelta(function (prev) {
        var next = _objectSpread({}, prev);
        delete next[playerId];
        return next;
      });
    }, 2500);
  };
  var undoLifeChange = function undoLifeChange() {
    if (lifeHistory.length === 0) return;
    var lastState = lifeHistory[lifeHistory.length - 1];
    setPlayers(lastState.players);
    setLifeHistory(function (hist) {
      return hist.slice(0, -1);
    });
    haptic(25);
    showToast("Undo");
  };
  var adjustCounter = function adjustCounter(playerId, counterType, delta) {
    haptic(15);
    setPlayers(function (prev) {
      return prev.map(function (p) {
        return p.id === playerId ? _objectSpread(_objectSpread({}, p), {}, _defineProperty({}, counterType, Math.max(0, (p[counterType] || 0) + delta))) : p;
      });
    });
  };
  var resetLife = function resetLife() {
    var startingLife = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 40;
    haptic(30);
    setPlayers(function (prev) {
      return prev.map(function (p) {
        return _objectSpread(_objectSpread({}, p), {}, {
          life: startingLife
        });
      });
    });
    setCommanderDamage({});
    showToast("Life reset to ".concat(startingLife));
    setShowResetConfirm(false);
  };
  var startNewGame = function startNewGame(playerCount, startingLife) {
    haptic(30);
    setPlayers(defaultPlayers(playerCount));
    setPlayers(function (prev) {
      return prev.map(function (p) {
        return _objectSpread(_objectSpread({}, p), {}, {
          life: startingLife
        });
      });
    });
    setCommanderDamage({});
    setTurnNumber(1);
    setPhaseIndex(0);
    setActivePlayerIndex(0);
    setMonarch(null);
    setInitiative(null);
    setCitysBlessing([]);
    setDayNight(null);
    setBattlefield([]);
    setShowNewGameMenu(false);
    showToast("New ".concat(playerCount, "-player game started!"));
  };
  var setPlayerCount = function setPlayerCount(n) {
    haptic(20);
    setPlayers(defaultPlayers(n));
    setCommanderDamage({});
  };
  var renamePlayer = function renamePlayer(playerId, newName) {
    setPlayers(function (prev) {
      return prev.map(function (p) {
        return p.id === playerId ? _objectSpread(_objectSpread({}, p), {}, {
          name: newName.trim() || p.name
        }) : p;
      });
    });
    setEditPlayerName(null);
    setEditPlayerNameValue("");
  };
  var adjustCmdrDamage = function adjustCmdrDamage(dealtToId, dealtById, delta) {
    haptic(15);
    setCommanderDamage(function (prev) {
      var byTarget = prev[dealtToId] || {};
      var current = byTarget[dealtById] || 0;
      var next = Math.max(0, Math.min(21, current + delta));
      var newByTarget = _objectSpread(_objectSpread({}, byTarget), {}, _defineProperty({}, dealtById, next));
      // Side-effect: sync to player life if commander damage advances
      if (delta > 0) {
        setPlayers(function (pp) {
          return pp.map(function (p) {
            return p.id === dealtToId ? _objectSpread(_objectSpread({}, p), {}, {
              life: p.life - delta
            }) : p;
          });
        });
      } else if (delta < 0) {
        setPlayers(function (pp) {
          return pp.map(function (p) {
            return p.id === dealtToId ? _objectSpread(_objectSpread({}, p), {}, {
              life: p.life - delta
            }) : p;
          });
        });
      }
      return _objectSpread(_objectSpread({}, prev), {}, _defineProperty({}, dealtToId, newByTarget));
    });
  };

  // Dice
  var rollDie = function rollDie(sides) {
    haptic(25);
    setRolling(sides);
    if (diceTimerRef.current) clearTimeout(diceTimerRef.current);
    diceTimerRef.current = setTimeout(function () {
      var result = Math.floor(Math.random() * sides) + 1;
      setDiceRolls(function (prev) {
        return [{
          sides: sides,
          result: result,
          at: Date.now(),
          id: "".concat(Date.now(), "-").concat(Math.random())
        }].concat(_toConsumableArray(prev)).slice(0, 10);
      });
      setRolling(null);
      haptic(35);
    }, 450);
  };
  var flipCoin = function flipCoin() {
    haptic(25);
    setRolling('coin');
    if (diceTimerRef.current) clearTimeout(diceTimerRef.current);
    diceTimerRef.current = setTimeout(function () {
      var result = Math.random() < 0.5 ? 'Heads' : 'Tails';
      setDiceRolls(function (prev) {
        return [{
          sides: 'coin',
          result: result,
          at: Date.now(),
          id: "".concat(Date.now(), "-").concat(Math.random())
        }].concat(_toConsumableArray(prev)).slice(0, 10);
      });
      setRolling(null);
      haptic(35);
    }, 450);
  };
  var randomPlayer = function randomPlayer() {
    haptic(25);
    setRolling('player');
    if (diceTimerRef.current) clearTimeout(diceTimerRef.current);
    diceTimerRef.current = setTimeout(function () {
      var pick = players[Math.floor(Math.random() * players.length)];
      setDiceRolls(function (prev) {
        return [{
          sides: 'player',
          result: pick.name,
          at: Date.now(),
          id: "".concat(Date.now(), "-").concat(Math.random())
        }].concat(_toConsumableArray(prev)).slice(0, 10);
      });
      setRolling(null);
      haptic(35);
    }, 450);
  };
  var clearRolls = function clearRolls() {
    haptic(20);
    setDiceRolls([]);
  };

  // Phase + turn
  var advancePhase = function advancePhase() {
    haptic(18);
    if (phaseIndex >= PHASES.length - 1) {
      // wrap to next turn + next player
      setPhaseIndex(0);
      setTurnNumber(function (t) {
        return t + 1;
      });
      setActivePlayerIndex(function (i) {
        return (i + 1) % players.length;
      });
    } else {
      setPhaseIndex(function (i) {
        return i + 1;
      });
    }
  };
  var retreatPhase = function retreatPhase() {
    haptic(18);
    if (phaseIndex <= 0) {
      if (turnNumber > 1) {
        setTurnNumber(function (t) {
          return t - 1;
        });
        setActivePlayerIndex(function (i) {
          return (i - 1 + players.length) % players.length;
        });
        setPhaseIndex(PHASES.length - 1);
      }
    } else {
      setPhaseIndex(function (i) {
        return i - 1;
      });
    }
  };
  var resetTurnTracker = function resetTurnTracker() {
    haptic(25);
    setPhaseIndex(0);
    setTurnNumber(1);
    setActivePlayerIndex(0);
    showToast("Turn tracker reset");
  };

  // --- Batch 3 handlers ---

  // Day/Night
  var toggleDayNight = function toggleDayNight() {
    haptic(20);
    if (dayNight === null) setDayNight('day');else if (dayNight === 'day') setDayNight('night');else setDayNight('day');
  };
  var clearDayNight = function clearDayNight() {
    haptic(15);
    setDayNight(null);
  };

  // Monarch / Initiative
  var setMonarchPlayer = function setMonarchPlayer(pid) {
    haptic(20);
    setMonarch(monarch === pid ? null : pid);
  };
  var setInitiativePlayer = function setInitiativePlayer(pid) {
    haptic(20);
    setInitiative(initiative === pid ? null : pid);
  };
  var toggleCitysBlessing = function toggleCitysBlessing(pid) {
    haptic(15);
    setCitysBlessing(function (prev) {
      return prev.includes(pid) ? prev.filter(function (p) {
        return p !== pid;
      }) : [].concat(_toConsumableArray(prev), [pid]);
    });
  };

  // Oracle text fetch
  var showOracle = /*#__PURE__*/function () {
    var _ref27 = _asyncToGenerator(/*#__PURE__*/_regenerator().m(function _callee4(token) {
      var res, _data$card_faces3, data, _t4;
      return _regenerator().w(function (_context4) {
        while (1) switch (_context4.p = _context4.n) {
          case 0:
            haptic(15);
            setOracleFor(token.id);
            if (!(oracleText && oracleFor === token.id)) {
              _context4.n = 1;
              break;
            }
            return _context4.a(2);
          case 1:
            // already loaded
            setOracleLoading(true);
            _context4.p = 2;
            _context4.n = 3;
            return fetch("https://api.scryfall.com/cards/".concat(encodeURIComponent(token.originalId || token.id)));
          case 3:
            res = _context4.v;
            if (!res.ok) {
              _context4.n = 5;
              break;
            }
            _context4.n = 4;
            return res.json();
          case 4:
            data = _context4.v;
            setOracleText(data.oracle_text || ((_data$card_faces3 = data.card_faces) === null || _data$card_faces3 === void 0 || (_data$card_faces3 = _data$card_faces3[0]) === null || _data$card_faces3 === void 0 ? void 0 : _data$card_faces3.oracle_text) || "(No rules text)");
            _context4.n = 6;
            break;
          case 5:
            setOracleText("Couldn't fetch rules text.");
          case 6:
            _context4.n = 8;
            break;
          case 7:
            _context4.p = 7;
            _t4 = _context4.v;
            setOracleText("Couldn't reach Scryfall.");
          case 8:
            setOracleLoading(false);
          case 9:
            return _context4.a(2);
        }
      }, _callee4, null, [[2, 7]]);
    }));
    return function showOracle(_x5) {
      return _ref27.apply(this, arguments);
    };
  }();

  // Card zoom (long-press)
  var showZoom = function showZoom(imageUrl) {
    var tokenId = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;
    haptic(20);
    // Find battlefield index for swipe navigation
    var idx = tokenId ? battlefield.findIndex(function (t) {
      return t.id === tokenId;
    }) : -1;
    setZoomImage({
      url: imageUrl,
      tokenId: tokenId,
      battlefieldIndex: idx
    });
  };

  // Secret menu -- 7 taps on title within 3s window

  var handleTitleTap = function handleTitleTap() {
    if (titleTapResetRef.current) clearTimeout(titleTapResetRef.current);
    var next = titleTapRef.current + 1;
    titleTapRef.current = next;
    setTitleTapCount(next);
    // The seal traces another seventh with every tap (src/sanctum/seal.js).
    if (window.TQ && window.TQ.sealProgress) window.TQ.sealProgress(next);
    // Progressive haptics -- quiet at first, intensifying near the unlock
    if (next < 4) haptic(8);else if (next < 6) haptic(15);else if (next === 6) haptic(25);else if (next >= 7) {
      haptic([40, 60, 40, 60, 80]);
      if (window.TQ && window.TQ.sealBreak) window.TQ.sealBreak();
      setSanctumOpen(true);
      titleTapRef.current = 0;
      setTitleTapCount(0);
      return;
    }
    // Reset counter if 3 seconds pass without another tap
    titleTapResetRef.current = setTimeout(function () {
      titleTapRef.current = 0;
      setTitleTapCount(0);
      if (window.TQ && window.TQ.sealHide) window.TQ.sealHide();
    }, 3000);
  };

  // Presets
  var savePreset = function savePreset(name) {
    if (!name.trim() || battlefield.length === 0) return;
    haptic(25);
    var stripped = battlefield.map(function (t) {
      return {
        id: t.id,
        originalId: t.originalId,
        isCopy: t.isCopy,
        originalName: t.originalName,
        name: t.name,
        smallImage: t.smallImage,
        power: t.power,
        toughness: t.toughness,
        type_line: t.type_line,
        colors: t.colors
      };
    });
    var id = "preset:".concat(Date.now());
    setPresets(function (prev) {
      return [].concat(_toConsumableArray(prev), [{
        id: id,
        name: name.trim(),
        tokens: stripped,
        createdAt: Date.now()
      }]);
    });
    setSavePresetOpen(false);
    setSavePresetName("");
    showToast("Preset \"".concat(name.trim(), "\" saved"));
  };
  var loadPreset = function loadPreset(preset) {
    haptic(25);
    setBattlefield(function (prev) {
      pushUndo(prev);
      return preset.tokens.map(function (t) {
        return _objectSpread(_objectSpread({}, t), {}, {
          count: 1,
          powerMod: 0,
          toughnessMod: 0,
          ptExpanded: false,
          counters: {}
        });
      });
    });
    setPresetMenuOpen(false);
    showToast("Loaded \"".concat(preset.name, "\""));
  };
  var deletePreset = function deletePreset(presetId) {
    haptic(25);
    setPresets(function (prev) {
      return prev.filter(function (p) {
        return p.id !== presetId;
      });
    });
  };
  var totalTokens = battlefield.reduce(function (sum, t) {
    return sum + t.count;
  }, 0);
  var uniqueTypes = battlefield.length;
  return /*#__PURE__*/React.createElement("div", {
    className: "min-h-screen w-full tq-font-".concat(settings.fontSize),
    style: {
      background: "radial-gradient(ellipse at top, var(--tq-surface) 0%, var(--tq-surface-deep) 50%, #05030a 100%)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pointer-events-none fixed inset-0 opacity-30 mix-blend-overlay",
    style: {
      backgroundImage: "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200'%3E%3Cfilter id='n'%3E%3CfeTurbulence baseFrequency='0.9'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E\")"
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "relative max-w-6xl mx-auto px-3 sm:px-6",
    style: {
      paddingBottom: 'calc(5rem + env(safe-area-inset-bottom))'
    }
  }, /*#__PURE__*/React.createElement("header", {
    className: "sticky top-0 z-30 -mx-3 sm:-mx-6 mb-4",
    style: {
      paddingLeft: '0.75rem',
      paddingRight: '0.75rem',
      paddingTop: 'max(0.5rem, env(safe-area-inset-top))',
      paddingBottom: '0.5rem',
      background: "linear-gradient(to bottom, rgba(10, 6, 4, 0.97) 0%, rgba(10, 6, 4, 0.92) 100%)",
      borderBottom: "1px solid rgba(201, 169, 97, 0.25)",
      backdropFilter: "blur(8px)",
      WebkitBackdropFilter: "blur(8px)",
      boxShadow: "0 2px 12px rgba(0, 0, 0, 0.3)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "max-w-6xl mx-auto"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-center mb-1"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: handleTitleTap,
    className: "active:scale-[0.98] transition-transform",
    style: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      padding: 0
    },
    "aria-label": "Token Queen"
  }, /*#__PURE__*/React.createElement("h1", {
    className: "uppercase text-base sm:text-lg tracking-[0.35em]",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 600,
      color: "var(--tq-gold-deep)",
      textShadow: titleTapCount >= 5 ? "0 0 12px rgba(212, 184, 122, 0.6), 0 1px 2px rgba(0,0,0,0.7)" : "0 1px 2px rgba(0,0,0,0.7)",
      background: "linear-gradient(180deg, var(--tq-gold-bright) 0%, var(--tq-gold-deep) 50%, var(--tq-brass) 100%)",
      WebkitBackgroundClip: "text",
      WebkitTextFillColor: "transparent",
      backgroundClip: "text",
      lineHeight: 1.2,
      transition: 'text-shadow 0.2s ease'
    }
  }, "Token Queen"))), /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between gap-2 min-h-[2rem]"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2 flex-shrink-0"
  }, totalTokens > 0 ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "flex flex-col items-start leading-none"
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-base font-bold",
    style: {
      fontFamily: "'JetBrains Mono', monospace",
      color: "var(--tq-gold-deep)"
    }
  }, totalTokens), /*#__PURE__*/React.createElement("span", {
    className: "text-[10px] tracking-[0.2em] uppercase mt-0.5",
    style: {
      color: "var(--tq-ink-dim)",
      fontFamily: "'Cinzel', serif"
    }
  }, "token", totalTokens === 1 ? "" : "s")), /*#__PURE__*/React.createElement("div", {
    className: "h-5 w-px",
    style: {
      background: "rgba(201, 169, 97, 0.25)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "flex flex-col items-start leading-none"
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-base font-bold",
    style: {
      fontFamily: "'JetBrains Mono', monospace",
      color: "var(--tq-gold-deep)"
    }
  }, uniqueTypes), /*#__PURE__*/React.createElement("span", {
    className: "text-[10px] tracking-[0.2em] uppercase mt-0.5",
    style: {
      color: "var(--tq-ink-dim)",
      fontFamily: "'Cinzel', serif"
    }
  }, "type", uniqueTypes === 1 ? "" : "s"))) : /*#__PURE__*/React.createElement("span", {
    className: "text-[10px] italic",
    style: {
      color: "var(--tq-ink-faint)",
      fontFamily: "'Crimson Pro', serif"
    }
  }, "Empty battlefield")), /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-1.5 flex-shrink-0"
  }, pet && function () {
    var cd = COLOR_DATA[pet.core];
    var hungry = petHunger(pet) < 30;
    var bored = petHappiness(pet) < 30;
    var needsAttention = hungry || bored;
    return /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        haptic(15);
        setSanctumOpen(true);
      },
      className: "flex items-center justify-center active:scale-90 transition-all",
      style: {
        width: '28px',
        height: '28px',
        borderRadius: '50%',
        background: "radial-gradient(circle at 35% 35%, ".concat(cd.bg, ", ").concat(cd.symbol, ")"),
        border: "1.5px solid ".concat(cd.symbol),
        boxShadow: needsAttention ? "0 0 12px ".concat(cd.glow, ", 0 0 4px ").concat(cd.glow, " inset") : "0 0 6px ".concat(cd.glow, "88"),
        animation: needsAttention ? 'petPulse 1.6s ease-in-out infinite' : 'none',
        cursor: 'pointer',
        padding: 0
      },
      "aria-label": "Companion: ".concat(needsAttention ? hungry ? 'hungry' : 'bored' : 'content'),
      title: "Companion: ".concat(needsAttention ? hungry ? 'hungry' : 'bored' : 'content')
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'Cinzel', serif",
        fontWeight: 700,
        fontSize: '0.7rem',
        color: cd.textOnBg,
        textShadow: "0 0 4px ".concat(cd.glow)
      }
    }, pet.core));
  }(), undoStack.length > 0 && /*#__PURE__*/React.createElement("button", {
    onClick: undo,
    className: "flex items-center justify-center w-8 h-8 active:scale-90 transition-all",
    style: {
      color: "var(--tq-gold)",
      background: "linear-gradient(180deg, rgba(201, 169, 97, 0.1), rgba(201, 169, 97, 0.02))",
      border: "1px solid rgba(201, 169, 97, 0.35)",
      borderRadius: "2px"
    },
    "aria-label": "Undo last action",
    title: "Undo"
  }, /*#__PURE__*/React.createElement(Undo, {
    style: {
      fontSize: '0.9rem'
    }
  })), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      haptic(30);
      setCopyOpen(true);
    },
    className: "flex items-center justify-center w-8 h-8 active:scale-90 transition-all",
    style: {
      color: "var(--tq-gold-deep)",
      background: "linear-gradient(180deg, rgba(201, 169, 97, 0.15), rgba(201, 169, 97, 0.05))",
      border: "1px solid rgba(201, 169, 97, 0.4)",
      borderRadius: "2px"
    },
    "aria-label": "Copy creature as token",
    title: "Copy"
  }, /*#__PURE__*/React.createElement(Copy, {
    style: {
      fontSize: '0.85rem'
    }
  })), battlefield.length > 0 && /*#__PURE__*/React.createElement("button", {
    onClick: requestWipe,
    className: "flex items-center justify-center w-8 h-8 active:scale-90 transition-all",
    style: {
      color: "var(--tq-danger)",
      background: "linear-gradient(180deg, rgba(160, 48, 44, 0.15), rgba(160, 48, 44, 0.05))",
      border: "1px solid rgba(160, 48, 44, 0.4)",
      borderRadius: "2px"
    },
    "aria-label": "Clear battlefield",
    title: "Wipe"
  }, /*#__PURE__*/React.createElement(Trash2, {
    style: {
      fontSize: '0.85rem'
    }
  })), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      haptic(15);
      setSettingsOpen(true);
    },
    className: "flex items-center justify-center w-8 h-8 active:scale-90 transition-all",
    style: {
      color: "var(--tq-ink-dim)",
      background: "linear-gradient(180deg, rgba(154, 135, 101, 0.08), rgba(154, 135, 101, 0.02))",
      border: "1px solid rgba(154, 135, 101, 0.3)",
      borderRadius: "2px"
    },
    "aria-label": "Settings",
    title: "Settings"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '1rem',
      lineHeight: 1
    }
  }, "\u2699")))))), activeTab === 'battlefield' && /*#__PURE__*/React.createElement("div", {
    className: "tab-enter",
    key: "battlefield"
  }, favourites.length > 0 && /*#__PURE__*/React.createElement("section", {
    className: "mb-5"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2 mb-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-1 h-4",
    style: {
      background: "linear-gradient(180deg, var(--tq-gold-deep), var(--tq-gold) 50%, transparent)",
      borderRadius: "1px",
      boxShadow: "0 0 4px rgba(212, 184, 122, 0.3)"
    }
  }), /*#__PURE__*/React.createElement("h2", {
    className: "text-[10px] tracking-[0.3em] uppercase flex items-center gap-1.5",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement(Star, {
    fill: "var(--tq-gold)",
    style: {
      color: "var(--tq-gold)",
      fontSize: '0.75rem'
    }
  }), "Favourites")), /*#__PURE__*/React.createElement("div", {
    className: "no-scrollbar flex gap-2 overflow-x-auto pb-2"
  }, favourites.map(function (f) {
    return /*#__PURE__*/React.createElement("div", {
      key: f.id,
      className: "relative flex-shrink-0",
      style: {
        width: "64px"
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return addToBattlefield(f);
      },
      className: "block w-full active:scale-95 transition-transform",
      style: {
        borderRadius: "4.75% / 3.5%",
        overflow: "hidden",
        border: "1px solid rgba(201, 169, 97, 0.4)"
      },
      "aria-label": "Summon ".concat(f.name)
    }, f.smallImage ? /*#__PURE__*/React.createElement("img", {
      src: f.smallImage,
      alt: f.name,
      className: "w-full h-auto block"
    }) : /*#__PURE__*/React.createElement("div", {
      className: "aspect-[5/7] flex items-center justify-center text-[9px] p-1 text-center",
      style: {
        background: "#2a1f14",
        color: "var(--tq-gold)"
      }
    }, f.name)), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick(e) {
        e.stopPropagation();
        toggleFavourite(f);
      },
      className: "absolute -top-1.5 -right-1.5 w-5 h-5 flex items-center justify-center active:scale-90",
      style: {
        background: "rgba(10, 6, 4, 0.95)",
        border: "1px solid rgba(201, 169, 97, 0.7)",
        borderRadius: "50%",
        color: "var(--tq-gold)",
        boxShadow: "0 2px 6px rgba(0,0,0,0.4)"
      },
      "aria-label": "Unfavourite ".concat(f.name)
    }, /*#__PURE__*/React.createElement(XIcon, {
      style: {
        fontSize: '0.625rem'
      }
    })));
  }))), /*#__PURE__*/React.createElement("section", {
    className: "mb-5"
  }, /*#__PURE__*/React.createElement("div", {
    className: "relative tq-search-wrap",
    style: {
      background: "linear-gradient(180deg, rgba(26, 17, 10, 0.85), rgba(10, 6, 4, 0.65))",
      border: "1px solid rgba(201, 169, 97, 0.3)",
      borderRadius: "3px",
      boxShadow: "inset 0 1px 3px rgba(0,0,0,0.4), inset 0 0 20px rgba(201, 169, 97, 0.04)",
      transition: 'all 0.25s ease'
    }
  }, /*#__PURE__*/React.createElement(Search, {
    style: {
      color: "var(--tq-ink-warm)",
      fontSize: '1rem',
      position: 'absolute',
      left: '0.85rem',
      top: '50%',
      transform: 'translateY(-50%)'
    }
  }), /*#__PURE__*/React.createElement("input", {
    type: "text",
    value: query,
    onChange: function onChange(e) {
      setQuery(e.target.value);
      setShowSearch(true);
    },
    onFocus: function onFocus() {
      return setShowSearch(true);
    },
    placeholder: "Search tokens\u2026",
    className: "search-green w-full bg-transparent pl-10 pr-10 py-3 text-base outline-none",
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: '#f5e9d0',
      letterSpacing: '0.02em'
    }
  }), query && /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      setQuery("");
      setResults([]);
      setActiveSearch("");
    },
    className: "absolute right-2 top-1/2 -translate-y-1/2 p-1.5 active:scale-90",
    style: {
      color: "var(--tq-ink-dim)"
    },
    "aria-label": "Clear search"
  }, /*#__PURE__*/React.createElement(XIcon, null))), /*#__PURE__*/React.createElement("div", {
    className: "no-scrollbar mt-3 flex gap-2 overflow-x-auto pb-1"
  }, QUICK_SEARCHES.map(function (term) {
    var active = activeSearch === term;
    return /*#__PURE__*/React.createElement("button", {
      key: term,
      onClick: function onClick() {
        return setQuery(term);
      },
      className: "flex-shrink-0 px-3 py-1.5 text-[10px] sm:text-xs tracking-widest uppercase transition-all active:scale-95",
      style: {
        fontFamily: "'Cinzel', serif",
        fontWeight: active ? 600 : 500,
        color: active ? "var(--tq-surface)" : "var(--tq-gold)",
        background: active ? "linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))" : "linear-gradient(180deg, rgba(201, 169, 97, 0.06), rgba(201, 169, 97, 0.01))",
        border: "1px solid ".concat(active ? "var(--tq-gold)" : "rgba(201, 169, 97, 0.3)"),
        borderRadius: "2px",
        boxShadow: active ? "0 2px 8px rgba(201, 169, 97, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.2)" : "inset 0 1px 0 rgba(255, 255, 255, 0.03)"
      }
    }, term);
  }))), /*#__PURE__*/React.createElement("section", {
    className: "mb-5"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2 mb-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-1 h-4",
    style: {
      background: "linear-gradient(180deg, var(--tq-gold-deep), var(--tq-gold) 50%, transparent)",
      borderRadius: "1px",
      boxShadow: "0 0 4px rgba(212, 184, 122, 0.3)"
    }
  }), /*#__PURE__*/React.createElement("h3", {
    className: "text-[10px] tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      fontWeight: 600
    }
  }, "Counters")), /*#__PURE__*/React.createElement("div", {
    className: "no-scrollbar flex gap-2 overflow-x-auto pb-1"
  }, STANDARD_COUNTERS.map(function (ctr) {
    return /*#__PURE__*/React.createElement("button", {
      key: ctr.id,
      onClick: function onClick() {
        haptic(20);
        var stableId = "counter:".concat(ctr.id);
        setBattlefield(function (prev) {
          pushUndo(prev);
          var existing = prev.find(function (t) {
            return t.id === stableId;
          });
          if (existing) return prev.map(function (t) {
            return t.id === stableId ? _objectSpread(_objectSpread({}, t), {}, {
              count: t.count + 1
            }) : t;
          });
          return [{
            id: stableId,
            name: ctr.name,
            type: 'Counter',
            colors: [],
            pt: null,
            text: ctr.text,
            originalId: ctr.id,
            powerMod: 0,
            toughnessMod: 0,
            tapped: false,
            counters: {
              plusOne: 0,
              minusOne: 0
            },
            isCounter: true,
            counterColor: ctr.color,
            count: 1
          }].concat(_toConsumableArray(prev));
        });
        showToast("".concat(ctr.name, " counter added"));
      },
      className: "flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 active:scale-95 transition-transform",
      style: {
        fontFamily: "'Cinzel', serif",
        fontSize: '0.7rem',
        fontWeight: 600,
        letterSpacing: '0.15em',
        textTransform: 'uppercase',
        color: ctr.color,
        background: "linear-gradient(180deg, ".concat(ctr.glow, ", rgba(10, 6, 4, 0.6))"),
        border: "1px solid ".concat(ctr.color, "55"),
        borderRadius: '2px',
        boxShadow: "inset 0 1px 0 rgba(255,255,255,0.04), 0 1px 4px ".concat(ctr.glow)
      }
    }, /*#__PURE__*/React.createElement("span", null, ctr.name));
  }))), (loading || results.length > 0 || error) && showSearch && /*#__PURE__*/React.createElement("section", {
    className: "mb-6"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between mb-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-1 h-4",
    style: {
      background: "linear-gradient(180deg, var(--tq-gold-deep), var(--tq-gold) 50%, transparent)",
      borderRadius: "1px",
      boxShadow: "0 0 4px rgba(212, 184, 122, 0.3)"
    }
  }), /*#__PURE__*/React.createElement("h2", {
    className: "text-[10px] sm:text-xs tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      fontWeight: 600
    }
  }, loading ? "Searching&hellip;" : "Tap to summon")), results.length > 0 && !loading && /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return setShowSearch(false);
    },
    className: "text-[10px] tracking-widest uppercase px-2 py-1 active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)"
    }
  }, "Hide")), loading && /*#__PURE__*/React.createElement("div", {
    className: "flex justify-center py-6"
  }, /*#__PURE__*/React.createElement(Loader2, {
    className: "animate-spin",
    style: {
      color: "var(--tq-gold)",
      fontSize: '1.25rem'
    }
  })), error && !loading && /*#__PURE__*/React.createElement("p", {
    className: "italic text-center py-4 text-sm",
    style: {
      color: "var(--tq-ink-dim)"
    }
  }, error), !loading && results.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2"
  }, results.map(function (card) {
    var _card$image_uris5, _card$image_uris6, _card$card_faces5;
    var img = ((_card$image_uris5 = card.image_uris) === null || _card$image_uris5 === void 0 ? void 0 : _card$image_uris5.small) || ((_card$image_uris6 = card.image_uris) === null || _card$image_uris6 === void 0 ? void 0 : _card$image_uris6.normal) || ((_card$card_faces5 = card.card_faces) === null || _card$card_faces5 === void 0 || (_card$card_faces5 = _card$card_faces5[0]) === null || _card$card_faces5 === void 0 || (_card$card_faces5 = _card$card_faces5.image_uris) === null || _card$card_faces5 === void 0 ? void 0 : _card$card_faces5.small) || "";
    var fav = isFavourite(card.id);
    return /*#__PURE__*/React.createElement("div", {
      key: card.id,
      className: "relative"
    }, /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return addToBattlefield(card);
      },
      className: "group relative block w-full transition-all active:scale-95",
      style: {
        borderRadius: "4.75% / 3.5%",
        overflow: "hidden"
      }
    }, img ? /*#__PURE__*/React.createElement("img", {
      src: img,
      alt: card.name,
      className: "w-full h-auto block"
    }) : /*#__PURE__*/React.createElement("div", {
      className: "aspect-[5/7] flex items-center justify-center text-[10px] p-2 text-center",
      style: {
        background: "#2a1f14",
        color: "var(--tq-gold)"
      }
    }, card.name)), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick(e) {
        e.stopPropagation();
        toggleFavourite(card);
      },
      className: "absolute top-1.5 right-1.5 w-7 h-7 flex items-center justify-center active:scale-90",
      style: {
        background: "rgba(10, 6, 4, 0.85)",
        border: "1px solid ".concat(fav ? "var(--tq-gold)" : "rgba(154, 135, 101, 0.5)"),
        borderRadius: "50%"
      },
      "aria-label": fav ? "Unfavourite" : "Favourite"
    }, /*#__PURE__*/React.createElement(Star, {
      fill: fav ? "var(--tq-gold)" : "none",
      style: {
        color: fav ? "var(--tq-gold)" : "var(--tq-ink-dim)",
        fontSize: '0.875rem'
      }
    })));
  }))), !showSearch && results.length > 0 && /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return setShowSearch(true);
    },
    className: "w-full mb-4 py-2 text-xs tracking-widest uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      border: "1px dashed rgba(201, 169, 97, 0.3)",
      borderRadius: "2px"
    }
  }, "Show results (", results.length, ")"), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between mb-3"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-1 h-4",
    style: {
      background: "linear-gradient(180deg, var(--tq-gold-deep), var(--tq-gold) 50%, transparent)",
      borderRadius: "1px",
      boxShadow: "0 0 4px rgba(212, 184, 122, 0.3)"
    }
  }), /*#__PURE__*/React.createElement("h2", {
    className: "text-[10px] sm:text-xs tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      fontWeight: 600
    }
  }, "Battlefield")), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      haptic(15);
      setPresetMenuOpen(true);
    },
    className: "flex items-center gap-1 text-[10px] uppercase tracking-widest px-2 py-1 active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      border: "1px solid rgba(201, 169, 97, 0.4)",
      borderRadius: "2px"
    },
    "aria-label": "Manage deck presets",
    title: "Presets"
  }, /*#__PURE__*/React.createElement(Layers, {
    style: {
      fontSize: '0.75rem'
    }
  }), "Presets ", presets.length > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--tq-ink-dim)',
      fontFamily: "'JetBrains Mono', monospace"
    }
  }, ". ", presets.length))), battlefield.length > 0 && /*#__PURE__*/React.createElement("p", {
    className: "text-[9px] italic tracking-wide text-center mb-2",
    style: {
      color: "var(--tq-ink-faint)"
    }
  }, "tap top . +1 \xA0.\xA0 tap bottom . -1 \xA0.\xA0 long-press . zoom"), battlefield.length === 0 ? /*#__PURE__*/React.createElement("div", {
    className: "text-center py-16 px-6 relative overflow-hidden",
    style: {
      border: "1px dashed rgba(201, 169, 97, 0.2)",
      borderRadius: "3px",
      background: "radial-gradient(ellipse at center, rgba(26, 17, 10, 0.5), transparent)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": true,
    style: {
      position: 'absolute',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      width: 180,
      height: 180,
      border: '1px solid rgba(201, 169, 97, 0.06)',
      borderRadius: '50%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": true,
    style: {
      position: 'absolute',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      width: 110,
      height: 110,
      border: '1px solid rgba(201, 169, 97, 0.08)',
      borderRadius: '50%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    "aria-hidden": true,
    style: {
      position: 'absolute',
      top: '50%',
      left: '50%',
      transform: 'translate(-50%, -50%)',
      width: 50,
      height: 50,
      border: '1px solid rgba(201, 169, 97, 0.12)',
      borderRadius: '50%'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "relative"
  }, /*#__PURE__*/React.createElement("p", {
    className: "italic text-base mb-1.5",
    style: {
      color: "var(--tq-ink-warm)",
      fontFamily: "'Crimson Pro', serif"
    }
  }, "The battlefield lies still."), /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] tracking-[0.3em] uppercase",
    style: {
      color: "#7a6a52",
      fontFamily: "'Cinzel', serif",
      fontWeight: 600
    }
  }, "Summon a token to begin"))) : /*#__PURE__*/React.createElement("div", {
    className: "grid gap-2 ".concat(battlefield.length <= 2 ? 'grid-cols-2' : battlefield.length <= 4 ? 'grid-cols-3' : battlefield.length <= 8 ? 'grid-cols-3' : 'grid-cols-4')
  }, battlefield.map(function (t) {
    var fav = isFavourite(t.id);
    var compact = battlefield.length > 4;
    return /*#__PURE__*/React.createElement("div", {
      key: t.id,
      className: "relative flex flex-col tq-token-card",
      style: {
        background: "rgba(20, 14, 8, 0.8)",
        border: "1px solid rgba(201, 169, 97, 0.3)",
        borderRadius: "3px",
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "relative select-none flex-shrink-0"
    }, t.smallImage ? /*#__PURE__*/React.createElement("img", {
      src: t.smallImage,
      alt: t.name,
      className: "w-full h-auto block pointer-events-none"
    }) : t.isCounter ? function () {
      var cc = t.counterColor || 'var(--tq-gold)';
      return /*#__PURE__*/React.createElement("div", {
        className: "aspect-[5/7] relative flex flex-col items-center justify-center p-2 text-center pointer-events-none overflow-hidden",
        style: {
          background: "radial-gradient(ellipse at center top, ".concat(cc, "33 0%, rgba(10, 6, 4, 0.95) 70%), linear-gradient(180deg, rgba(20, 14, 8, 0.95), rgba(5, 3, 10, 0.95))"),
          border: "1px solid ".concat(cc, "55")
        }
      }, /*#__PURE__*/React.createElement("span", {
        "aria-hidden": true,
        style: {
          position: 'absolute',
          top: 4,
          left: 4,
          width: 6,
          height: 6,
          borderTop: "1px solid ".concat(cc),
          borderLeft: "1px solid ".concat(cc)
        }
      }), /*#__PURE__*/React.createElement("span", {
        "aria-hidden": true,
        style: {
          position: 'absolute',
          top: 4,
          right: 4,
          width: 6,
          height: 6,
          borderTop: "1px solid ".concat(cc),
          borderRight: "1px solid ".concat(cc)
        }
      }), /*#__PURE__*/React.createElement("span", {
        "aria-hidden": true,
        style: {
          position: 'absolute',
          bottom: 4,
          left: 4,
          width: 6,
          height: 6,
          borderBottom: "1px solid ".concat(cc),
          borderLeft: "1px solid ".concat(cc)
        }
      }), /*#__PURE__*/React.createElement("span", {
        "aria-hidden": true,
        style: {
          position: 'absolute',
          bottom: 4,
          right: 4,
          width: 6,
          height: 6,
          borderBottom: "1px solid ".concat(cc),
          borderRight: "1px solid ".concat(cc)
        }
      }), /*#__PURE__*/React.createElement("div", {
        style: {
          width: '46%',
          aspectRatio: '1 / 1',
          borderRadius: '50%',
          background: "radial-gradient(circle at 30% 30%, ".concat(cc, ", ").concat(cc, "88)"),
          boxShadow: "inset 0 -2px 4px rgba(0,0,0,0.4), 0 0 16px ".concat(cc, "55"),
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'var(--tq-surface-deep)',
          fontFamily: "'Cinzel', serif",
          fontWeight: 800,
          fontSize: compact ? '0.65rem' : '0.85rem',
          letterSpacing: '0.05em'
        }
      }, (t.name || '?').slice(0, 3).toUpperCase()), /*#__PURE__*/React.createElement("p", {
        style: {
          marginTop: 6,
          fontFamily: "'Cinzel', serif",
          color: cc,
          fontSize: compact ? '0.55rem' : '0.7rem',
          letterSpacing: '0.18em',
          textTransform: 'uppercase',
          fontWeight: 600
        }
      }, t.name), /*#__PURE__*/React.createElement("p", {
        style: {
          marginTop: 2,
          fontFamily: "'Crimson Pro', serif",
          color: 'var(--tq-ink-dim)',
          fontSize: compact ? '0.5rem' : '0.6rem',
          fontStyle: 'italic'
        }
      }, "counter"));
    }() : /*#__PURE__*/React.createElement("div", {
      className: "aspect-[5/7] flex items-center justify-center text-xs p-2 text-center pointer-events-none",
      style: {
        background: "#2a1f14",
        color: "var(--tq-gold)"
      }
    }, t.name), /*#__PURE__*/React.createElement("div", {
      className: "absolute inset-0 z-10",
      onClick: function onClick() {
        haptic(20);
        setNumpadFor(t.id);
        setNumpadValue(String(t.count));
      },
      onContextMenu: function onContextMenu(e) {
        e.preventDefault();
        showZoom(t.normalImage || t.smallImage, t.id);
      },
      onTouchStart: function onTouchStart(e) {
        var target = e.currentTarget;
        var timer = setTimeout(function () {
          target.dataset.lp = "1";
          showZoom(t.normalImage || t.smallImage, t.id);
        }, 600);
        target.dataset.lpt = String(timer);
      },
      onTouchEnd: function onTouchEnd(e) {
        var target = e.currentTarget;
        clearTimeout(parseInt(target.dataset.lpt || "0", 10));
        if (target.dataset.lp === "1") {
          target.dataset.lp = "0";
          e.preventDefault();
        }
      },
      onTouchCancel: function onTouchCancel(e) {
        return clearTimeout(parseInt(e.currentTarget.dataset.lpt || "0", 10));
      },
      style: {
        cursor: 'pointer'
      },
      "aria-label": "".concat(t.name, ": tap to edit count, long-press to zoom")
    }), /*#__PURE__*/React.createElement("div", {
      className: "absolute top-1.5 left-1.5 z-30",
      style: {
        minWidth: compact ? "1.5rem" : "1.75rem",
        height: compact ? "1.5rem" : "1.75rem",
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '0 0.25rem',
        background: "rgba(10, 6, 4, 0.92)",
        border: "1.5px solid var(--tq-gold)",
        borderRadius: "2px",
        fontFamily: "'JetBrains Mono', monospace",
        color: "var(--tq-gold-deep)",
        fontWeight: 700,
        fontSize: compact ? "0.8rem" : "0.95rem",
        boxShadow: "0 0 8px rgba(201, 169, 97, 0.4)",
        pointerEvents: 'none'
      }
    }, t.count), t.colors.length > 0 && /*#__PURE__*/React.createElement("div", {
      className: "absolute top-1.5 right-1.5 flex gap-0.5 pointer-events-none z-20"
    }, t.colors.map(function (c) {
      return /*#__PURE__*/React.createElement("span", {
        key: c,
        className: "rounded-full",
        style: {
          width: '0.4rem',
          height: '0.4rem',
          background: COLOR_DOTS[c] || "#666",
          border: "1px solid rgba(0,0,0,0.4)"
        }
      });
    })), t.isCopy && /*#__PURE__*/React.createElement("div", {
      className: "absolute bottom-9 left-1 pointer-events-none z-20 flex items-center gap-0.5 px-1 py-0.5",
      style: {
        background: "rgba(10, 6, 4, 0.9)",
        border: "1px solid var(--tq-info)",
        borderRadius: "2px"
      }
    }, /*#__PURE__*/React.createElement(Copy, {
      style: {
        color: "var(--tq-info)",
        fontSize: '0.45rem'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'Cinzel', serif",
        color: "var(--tq-info)",
        fontSize: "0.4rem",
        fontWeight: 700
      }
    }, "COPY")), /*#__PURE__*/React.createElement("div", {
      className: "absolute bottom-0 left-0 right-0 z-20 px-1 pt-4 pb-1",
      style: {
        background: "linear-gradient(to top, rgba(6, 4, 2, 0.96) 0%, rgba(6, 4, 2, 0.7) 60%, transparent 100%)",
        pointerEvents: 'none'
      }
    }, /*#__PURE__*/React.createElement("p", {
      className: "truncate",
      style: {
        fontFamily: "'Cinzel', serif",
        color: "#f0e8d4",
        fontSize: compact ? "0.55rem" : "0.68rem",
        fontWeight: 600,
        lineHeight: 1.2,
        textShadow: "0 1px 3px rgba(0,0,0,0.9)"
      },
      title: t.name
    }, t.name, t.isCopy ? /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--tq-info)",
        fontStyle: "italic"
      }
    }, " .copy") : null), t.power !== null && t.toughness !== null && function () {
      var pMod = t.powerMod || 0;
      var tMod = t.toughnessMod || 0;
      var hasMod = pMod !== 0 || tMod !== 0;
      var basePwr = parseInt(t.power, 10);
      var baseTgh = parseInt(t.toughness, 10);
      var curP = isNaN(basePwr) ? t.power : basePwr + pMod;
      var curT = isNaN(baseTgh) ? t.toughness : baseTgh + tMod;
      var fmt = function fmt(n) {
        return n > 0 ? "+".concat(n) : "".concat(n);
      };
      return /*#__PURE__*/React.createElement("div", {
        className: "flex items-center gap-1"
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          color: hasMod ? "var(--tq-gold-bright)" : "var(--tq-gold)",
          fontSize: compact ? "0.55rem" : "0.65rem",
          fontFamily: "'JetBrains Mono', monospace",
          fontWeight: 700,
          textShadow: "0 1px 3px rgba(0,0,0,0.9)"
        }
      }, curP, "/", curT), hasMod && /*#__PURE__*/React.createElement("span", {
        style: {
          color: "var(--tq-life)",
          fontSize: "0.5rem",
          padding: "0 2px",
          background: "rgba(107,142,90,0.3)",
          border: "1px solid rgba(107,142,90,0.5)",
          borderRadius: "1px"
        }
      }, fmt(pMod), "/", fmt(tMod)));
    }()), /*#__PURE__*/React.createElement("div", {
      className: "absolute bottom-0 left-0 right-0 z-25 flex items-center justify-end gap-0.5 px-0.5 pb-0.5",
      style: {
        paddingTop: compact ? '22px' : '26px'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: function onClick(e) {
        e.stopPropagation();
        toggleTapped(t.id);
      },
      className: "flex items-center justify-center active:scale-90",
      style: {
        width: compact ? '18px' : '22px',
        height: compact ? '18px' : '22px',
        background: t.tapped ? "rgba(201,169,97,0.25)" : "rgba(6,4,2,0.85)",
        border: "1px solid ".concat(t.tapped ? "var(--tq-gold)" : "rgba(154,135,101,0.5)"),
        borderRadius: "2px",
        color: t.tapped ? "var(--tq-gold)" : "var(--tq-ink-dim)",
        transform: t.tapped ? 'rotate(90deg)' : 'none',
        transition: 'transform 0.2s'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: compact ? '0.5rem' : '0.6rem',
        fontWeight: 700
      }
    }, "\u21BB")), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick(e) {
        e.stopPropagation();
        showOracle(t);
      },
      className: "flex items-center justify-center active:scale-90",
      style: {
        width: compact ? '18px' : '22px',
        height: compact ? '18px' : '22px',
        background: "rgba(6,4,2,0.85)",
        border: "1px solid rgba(154,135,101,0.5)",
        borderRadius: "2px",
        color: "var(--tq-ink-dim)"
      }
    }, /*#__PURE__*/React.createElement(Info, {
      style: {
        fontSize: compact ? '0.55rem' : '0.65rem'
      }
    })), t.power !== null && t.toughness !== null && /*#__PURE__*/React.createElement("button", {
      onClick: function onClick(e) {
        e.stopPropagation();
        togglePTExpanded(t.id);
      },
      className: "flex items-center justify-center active:scale-90",
      style: {
        width: compact ? '18px' : '22px',
        height: compact ? '18px' : '22px',
        background: t.ptExpanded ? "rgba(201,169,97,0.25)" : "rgba(6,4,2,0.85)",
        border: "1px solid ".concat(t.ptExpanded ? "var(--tq-gold)" : "rgba(154,135,101,0.5)"),
        borderRadius: "2px",
        color: t.ptExpanded ? "var(--tq-gold)" : "var(--tq-ink-dim)"
      }
    }, /*#__PURE__*/React.createElement(Sword, {
      style: {
        fontSize: compact ? '0.55rem' : '0.65rem'
      }
    })), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick(e) {
        e.stopPropagation();
        toggleFavourite(t);
      },
      className: "flex items-center justify-center active:scale-90",
      style: {
        width: compact ? '18px' : '22px',
        height: compact ? '18px' : '22px',
        background: fav ? "rgba(201,169,97,0.25)" : "rgba(6,4,2,0.85)",
        border: "1px solid ".concat(fav ? "var(--tq-gold)" : "rgba(154,135,101,0.5)"),
        borderRadius: "2px"
      }
    }, /*#__PURE__*/React.createElement(Star, {
      fill: fav ? "var(--tq-gold)" : "none",
      style: {
        color: fav ? "var(--tq-gold)" : "var(--tq-ink-dim)",
        fontSize: compact ? '0.55rem' : '0.65rem'
      }
    })), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick(e) {
        e.stopPropagation();
        removeAll(t.id);
      },
      className: "flex items-center justify-center active:scale-90",
      style: {
        width: compact ? '18px' : '22px',
        height: compact ? '18px' : '22px',
        background: "rgba(6,4,2,0.85)",
        border: "1px solid rgba(160,48,44,0.5)",
        borderRadius: "2px",
        color: "var(--tq-danger)"
      }
    }, /*#__PURE__*/React.createElement(Trash2, {
      style: {
        fontSize: compact ? '0.55rem' : '0.65rem'
      }
    })))), t.ptExpanded && t.power !== null && t.toughness !== null && /*#__PURE__*/React.createElement("div", {
      className: "px-2 py-1.5",
      style: {
        borderTop: "1px solid rgba(201, 169, 97, 0.15)",
        background: "rgba(10, 6, 4, 0.6)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "flex items-center justify-between gap-1 mb-1"
    }, /*#__PURE__*/React.createElement("span", {
      className: "text-[10px] tracking-[0.2em] uppercase",
      style: {
        fontFamily: "'Cinzel', serif",
        color: "var(--tq-ink-dim)"
      }
    }, "Counters"), (t.powerMod !== 0 || t.toughnessMod !== 0) && /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return resetPT(t.id);
      },
      className: "flex items-center gap-0.5 text-[10px] tracking-widest uppercase px-1 py-0.5 active:scale-95",
      style: {
        fontFamily: "'Cinzel', serif",
        color: "var(--tq-ink-dim)",
        border: "1px solid rgba(154, 135, 101, 0.4)",
        borderRadius: "2px"
      }
    }, /*#__PURE__*/React.createElement(RotateCcw, {
      style: {
        fontSize: '0.5rem'
      }
    }), "Reset")), /*#__PURE__*/React.createElement("div", {
      className: "grid grid-cols-2 gap-1"
    }, /*#__PURE__*/React.createElement("div", {
      className: "flex items-center justify-between gap-0.5",
      style: {
        background: "rgba(232,148,122,0.08)",
        border: "1px solid rgba(232,148,122,0.3)",
        borderRadius: "2px",
        padding: "2px"
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustPT(t.id, 'power', -1);
      },
      className: "w-5 h-5 flex items-center justify-center active:scale-90",
      style: {
        color: "var(--tq-danger)"
      }
    }, /*#__PURE__*/React.createElement(Minus, {
      style: {
        fontSize: '0.625rem'
      }
    })), /*#__PURE__*/React.createElement("div", {
      className: "flex items-center gap-0.5"
    }, /*#__PURE__*/React.createElement(Sword, {
      style: {
        color: "var(--tq-danger)",
        fontSize: '0.55rem'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        color: (t.powerMod || 0) === 0 ? "var(--tq-ink-dim)" : "var(--tq-gold-deep)",
        fontSize: "0.65rem",
        fontWeight: 700,
        minWidth: "1rem",
        textAlign: "center"
      }
    }, (t.powerMod || 0) > 0 ? "+".concat(t.powerMod) : t.powerMod || 0)), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustPT(t.id, 'power', 1);
      },
      className: "w-5 h-5 flex items-center justify-center active:scale-90",
      style: {
        color: "var(--tq-danger)"
      }
    }, /*#__PURE__*/React.createElement(Plus, {
      style: {
        fontSize: '0.625rem'
      }
    }))), /*#__PURE__*/React.createElement("div", {
      className: "flex items-center justify-between gap-0.5",
      style: {
        background: "rgba(159,199,230,0.08)",
        border: "1px solid rgba(159,199,230,0.3)",
        borderRadius: "2px",
        padding: "2px"
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustPT(t.id, 'toughness', -1);
      },
      className: "w-5 h-5 flex items-center justify-center active:scale-90",
      style: {
        color: "var(--tq-info)"
      }
    }, /*#__PURE__*/React.createElement(Minus, {
      style: {
        fontSize: '0.625rem'
      }
    })), /*#__PURE__*/React.createElement("div", {
      className: "flex items-center gap-0.5"
    }, /*#__PURE__*/React.createElement(Shield, {
      style: {
        color: "var(--tq-info)",
        fontSize: '0.55rem'
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        color: (t.toughnessMod || 0) === 0 ? "var(--tq-ink-dim)" : "var(--tq-gold-deep)",
        fontSize: "0.65rem",
        fontWeight: 700,
        minWidth: "1rem",
        textAlign: "center"
      }
    }, (t.toughnessMod || 0) > 0 ? "+".concat(t.toughnessMod) : t.toughnessMod || 0)), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustPT(t.id, 'toughness', 1);
      },
      className: "w-5 h-5 flex items-center justify-center active:scale-90",
      style: {
        color: "var(--tq-info)"
      }
    }, /*#__PURE__*/React.createElement(Plus, {
      style: {
        fontSize: '0.625rem'
      }
    })))), /*#__PURE__*/React.createElement("div", {
      className: "mt-1.5 pt-1.5",
      style: {
        borderTop: "1px dashed rgba(201, 169, 97, 0.15)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "grid grid-cols-2 gap-1"
    }, COUNTER_TYPES.map(function (ct) {
      var _t$counters;
      var value = ((_t$counters = t.counters) === null || _t$counters === void 0 ? void 0 : _t$counters[ct.id]) || 0;
      var active = value > 0;
      return /*#__PURE__*/React.createElement("div", {
        key: ct.id,
        className: "flex items-center justify-between gap-0.5",
        style: {
          background: active ? "".concat(ct.color, "14") : 'transparent',
          border: "1px solid ".concat(active ? ct.color + '55' : 'rgba(154,135,101,0.2)'),
          borderRadius: "2px",
          padding: "1px"
        }
      }, /*#__PURE__*/React.createElement("button", {
        onClick: function onClick() {
          return adjustTokenCounter(t.id, ct.id, -1);
        },
        className: "w-4 h-4 flex items-center justify-center active:scale-90",
        style: {
          color: ct.color,
          opacity: active ? 1 : 0.4
        }
      }, /*#__PURE__*/React.createElement(Minus, {
        style: {
          fontSize: '0.5rem'
        }
      })), /*#__PURE__*/React.createElement("div", {
        className: "flex items-center gap-0.5"
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          fontSize: '0.45rem',
          color: ct.color,
          fontFamily: "'Cinzel', serif",
          fontWeight: 600
        }
      }, ct.short), /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: "'JetBrains Mono', monospace",
          color: active ? "var(--tq-gold-deep)" : "var(--tq-ink-faint)",
          fontSize: "0.6rem",
          fontWeight: 700,
          minWidth: "0.875rem",
          textAlign: "center"
        }
      }, value)), /*#__PURE__*/React.createElement("button", {
        onClick: function onClick() {
          return adjustTokenCounter(t.id, ct.id, 1);
        },
        className: "w-4 h-4 flex items-center justify-center active:scale-90",
        style: {
          color: ct.color
        }
      }, /*#__PURE__*/React.createElement(Plus, {
        style: {
          fontSize: '0.5rem'
        }
      })));
    })))));
  })))), activeTab === 'life' && /*#__PURE__*/React.createElement("section", {
    className: "mb-6 tab-enter",
    key: "life"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex flex-col gap-2 mb-4"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-1 h-4",
    style: {
      background: "linear-gradient(180deg, var(--tq-gold-deep), var(--tq-gold) 50%, transparent)",
      borderRadius: "1px",
      boxShadow: "0 0 4px rgba(212, 184, 122, 0.3)"
    }
  }), /*#__PURE__*/React.createElement("h2", {
    className: "text-[10px] sm:text-xs tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      fontWeight: 600
    }
  }, "Life Totals")), /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-1.5 flex-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center",
    style: {
      border: "1px solid rgba(201, 169, 97, 0.3)",
      borderRadius: "2px",
      overflow: "hidden"
    }
  }, [2, 3, 4].map(function (n) {
    return /*#__PURE__*/React.createElement("button", {
      key: n,
      onClick: function onClick() {
        return setPlayerCount(n);
      },
      className: "text-[10px] active:scale-95 transition-transform",
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        fontWeight: 600,
        color: players.length === n ? "var(--tq-surface)" : "var(--tq-gold)",
        background: players.length === n ? "linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))" : "transparent",
        minWidth: 40,
        flex: "0 0 auto",
        padding: "4px 6px",
        textAlign: "center",
        whiteSpace: "nowrap"
      }
    }, n + "P");
  })), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() { setBigPicture(!bigPicture); },
    title: bigPicture ? "Exit fullscreen" : "Big-picture mode",
    className: "text-[10px] active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 600,
      color: bigPicture ? "var(--tq-surface)" : "var(--tq-gold)",
      background: bigPicture ? "linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))" : "transparent",
      border: "1px solid rgba(201, 169, 97, 0.4)",
      borderRadius: "2px",
      marginLeft: 6,
      padding: "4px 8px",
      letterSpacing: "0.15em"
    }
  }, bigPicture ? "EXIT" : "FULL"), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return setShowResetConfirm(true);
    },
    className: "flex items-center gap-1 text-[10px] uppercase tracking-widest px-2 py-1 active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      border: "1px solid rgba(201, 169, 97, 0.4)",
      borderRadius: "2px"
    },
    title: "Reset all life to 40"
  }, /*#__PURE__*/React.createElement(Undo, {
    style: {
      fontSize: '0.75rem'
    }
  }), "Reset"), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return setShowNewGameMenu(true);
    },
    className: "flex items-center gap-1 text-[10px] uppercase tracking-widest px-2 py-1 active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-life-deep)",
      border: "1px solid rgba(143, 188, 143, 0.4)",
      borderRadius: "2px"
    },
    title: "Start a new game"
  }, /*#__PURE__*/React.createElement(Plus, {
    style: {
      fontSize: '0.75rem'
    }
  }), "New Game"), lifeHistory.length > 0 && /*#__PURE__*/React.createElement("button", {
    onClick: undoLifeChange,
    className: "flex items-center gap-1 text-[10px] uppercase tracking-widest px-2 py-1 active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-info)",
      border: "1px solid rgba(159, 199, 230, 0.4)",
      borderRadius: "2px"
    },
    title: "Undo last life change"
  }, /*#__PURE__*/React.createElement(Undo, {
    style: {
      fontSize: '0.75rem',
      transform: 'scaleX(-1)'
    }
  }), "Undo"))), /*#__PURE__*/React.createElement("div", {
    className: players.length === 2 ? "grid grid-cols-1 gap-3" : players.length === 3 ? "grid grid-cols-1 sm:grid-cols-3 gap-3" : "grid grid-cols-2 gap-3"
  }, players.map(function (p, idx) {
    var isActive = idx === activePlayerIndex;
    var lifeColor = p.life <= 0 ? "var(--tq-danger-deep)" : p.life <= 10 ? "var(--tq-danger)" : "var(--tq-gold-deep)";
    var isFlipped = playerFlipped[idx] || false;
    return /*#__PURE__*/React.createElement("div", {
      key: p.id,
      className: "relative flex flex-col overflow-hidden",
      style: {
        background: "linear-gradient(180deg, rgba(20, 14, 8, 0.9), rgba(10, 6, 4, 0.7))",
        border: "1.5px solid ".concat(isActive ? p.color : "rgba(201, 169, 97, 0.3)"),
        borderRadius: "3px",
        boxShadow: isActive ? "0 0 20px ".concat(p.color, "40, inset 0 1px 0 rgba(255, 255, 255, 0.04)") : "inset 0 1px 0 rgba(255, 255, 255, 0.03)",
        minHeight: "180px",
        transform: isFlipped ? "rotate(180deg)" : "none",
        transition: "transform 0.3s ease"
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "flex items-center justify-between px-3 py-2",
      style: {
        borderBottom: "1px solid ".concat(p.color, "33"),
        background: "linear-gradient(90deg, ".concat(p.color, "15, transparent)")
      }
    }, editPlayerName === p.id ? /*#__PURE__*/React.createElement("input", {
      type: "text",
      value: editPlayerNameValue,
      onChange: function onChange(e) {
        return setEditPlayerNameValue(e.target.value);
      },
      onBlur: function onBlur() {
        return renamePlayer(p.id, editPlayerNameValue);
      },
      onKeyDown: function onKeyDown(e) {
        if (e.key === 'Enter') renamePlayer(p.id, editPlayerNameValue);
        if (e.key === 'Escape') {
          setEditPlayerName(null);
          setEditPlayerNameValue("");
        }
      },
      autoFocus: true,
      maxLength: 20,
      className: "bg-transparent outline-none text-sm flex-1 min-w-0",
      style: {
        fontFamily: "'Cinzel', serif",
        color: "var(--tq-ink)",
        borderBottom: "1px solid ".concat(p.color)
      }
    }) : /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        setEditPlayerName(p.id);
        setEditPlayerNameValue(p.name);
      },
      className: "text-left flex-1 min-w-0 truncate text-sm tracking-wide active:opacity-70",
      style: {
        fontFamily: "'Cinzel', serif",
        color: "var(--tq-ink)",
        fontWeight: 600
      },
      "aria-label": "Rename player"
    }, p.name), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return setCmdrDamageFor(p.id);
      },
      className: "ml-2 px-1.5 py-0.5 text-[9px] tracking-widest uppercase active:scale-95 flex-shrink-0",
      style: {
        fontFamily: "'Cinzel', serif",
        color: p.color,
        border: "1px solid ".concat(p.color, "66"),
        borderRadius: "2px"
      },
      title: "Commander damage"
    }, "C-DMG"), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        // Cycle through adding counters: poison → energy → experience → tax → none
        if ((p.poison || 0) === 0 && (p.energy || 0) === 0 && (p.experience || 0) === 0 && (p.commanderTax || 0) === 0) {
          adjustCounter(p.id, 'poison', 1);
        } else if ((p.poison || 0) > 0 && (p.energy || 0) === 0) {
          adjustCounter(p.id, 'energy', 1);
        } else if ((p.energy || 0) > 0 && (p.experience || 0) === 0) {
          adjustCounter(p.id, 'experience', 1);
        } else if ((p.experience || 0) > 0 && (p.commanderTax || 0) === 0) {
          adjustCounter(p.id, 'commanderTax', 1);
        }
      },
      className: "ml-1 px-1.5 py-0.5 text-[9px] active:scale-95 flex-shrink-0",
      style: {
        fontFamily: "'Cinzel', serif",
        color: p.color,
        border: "1px solid ".concat(p.color, "66"),
        borderRadius: "2px"
      },
      title: "Add counters (\u2620\uFE0F\u2192\u26A1\u2192\u2B50\u2192\uD83D\uDC51)"
    }, "+CTR"), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        var newFlipped = _toConsumableArray(playerFlipped);
        newFlipped[idx] = !newFlipped[idx];
        setPlayerFlipped(newFlipped);
      },
      className: "ml-1 px-1.5 py-0.5 text-[9px] active:scale-95 flex-shrink-0",
      style: {
        fontFamily: "'Cinzel', serif",
        color: p.color,
        border: "1px solid ".concat(p.color, "66"),
        borderRadius: "2px"
      },
      title: "Flip 180\xB0 for opponent view"
    }, "\u27F2")), /*#__PURE__*/React.createElement("div", {
      className: "flex-1 flex items-center justify-center relative"
    }, /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustLife(p.id, -1);
      },
      className: "absolute inset-y-0 left-0 w-1/2 flex items-center justify-start pl-4 active:bg-red-900/10 transition-colors",
      "aria-label": "Decrease life"
    }, /*#__PURE__*/React.createElement(Minus, {
      style: {
        color: "var(--tq-danger)",
        fontSize: '1.25rem',
        opacity: 0.7
      }
    })), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustLife(p.id, 1);
      },
      className: "absolute inset-y-0 right-0 w-1/2 flex items-center justify-end pr-4 active:bg-green-900/10 transition-colors",
      "aria-label": "Increase life"
    }, /*#__PURE__*/React.createElement(Plus, {
      style: {
        color: "var(--tq-life)",
        fontSize: '1.25rem',
        opacity: 0.7
      }
    })), /*#__PURE__*/React.createElement("span", {
      className: "pointer-events-none relative z-10",
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        fontSize: players.length >= 4 ? "3rem" : "4rem",
        fontWeight: 700,
        color: lifeColor,
        textShadow: "0 0 20px ".concat(lifeColor, "66, 0 2px 4px rgba(0,0,0,0.8)"),
        lineHeight: 1
      }
    }, p.life), lifeDelta[p.id] && /*#__PURE__*/React.createElement("span", {
      key: "".concat(p.id, "-").concat(lifeDelta[p.id].delta),
      style: {
        position: 'absolute',
        top: '-8px',
        left: '50%',
        transform: 'translateX(-50%)',
        fontFamily: "'JetBrains Mono', monospace",
        fontWeight: 700,
        fontSize: '1.6rem',
        color: lifeDelta[p.id].delta > 0 ? 'var(--tq-life)' : 'var(--tq-danger)',
        textShadow: "0 0 16px ".concat(lifeDelta[p.id].delta > 0 ? 'rgba(107,142,90,0.8)' : 'rgba(160,48,44,0.8)'),
        pointerEvents: 'none',
        animation: 'lifeDeltaFade 2.5s ease-out forwards',
        whiteSpace: 'nowrap',
        zIndex: 20
      }
    }, lifeDelta[p.id].delta > 0 ? "+".concat(lifeDelta[p.id].delta) : lifeDelta[p.id].delta)), ((p.poison || 0) > 0 || (p.energy || 0) > 0 || (p.experience || 0) > 0 || (p.commanderTax || 0) > 0) && /*#__PURE__*/React.createElement("div", {
      className: "px-2 pb-2 flex flex-wrap gap-1.5 justify-center"
    }, (p.poison || 0) > 0 && /*#__PURE__*/React.createElement("div", {
      className: "flex items-center gap-1 px-2 py-1 rounded",
      style: {
        background: 'rgba(160, 48, 44, 0.15)',
        border: '1px solid rgba(160, 48, 44, 0.3)'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustCounter(p.id, 'poison', -1);
      },
      className: "text-[10px] active:scale-90",
      style: {
        color: 'var(--tq-danger)'
      }
    }, "\u2212"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        fontSize: '0.75rem',
        color: 'var(--tq-danger)',
        fontWeight: 600
      }
    }, "\u2620\uFE0F ", p.poison), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustCounter(p.id, 'poison', 1);
      },
      className: "text-[10px] active:scale-90",
      style: {
        color: 'var(--tq-danger)'
      }
    }, "+")), (p.energy || 0) > 0 && /*#__PURE__*/React.createElement("div", {
      className: "flex items-center gap-1 px-2 py-1 rounded",
      style: {
        background: 'rgba(159, 199, 230, 0.15)',
        border: '1px solid rgba(159, 199, 230, 0.3)'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustCounter(p.id, 'energy', -1);
      },
      className: "text-[10px] active:scale-90",
      style: {
        color: 'var(--tq-info)'
      }
    }, "\u2212"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        fontSize: '0.75rem',
        color: 'var(--tq-info)',
        fontWeight: 600
      }
    }, "\u26A1 ", p.energy), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustCounter(p.id, 'energy', 1);
      },
      className: "text-[10px] active:scale-90",
      style: {
        color: 'var(--tq-info)'
      }
    }, "+")), (p.experience || 0) > 0 && /*#__PURE__*/React.createElement("div", {
      className: "flex items-center gap-1 px-2 py-1 rounded",
      style: {
        background: 'rgba(201, 169, 97, 0.15)',
        border: '1px solid rgba(201, 169, 97, 0.3)'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustCounter(p.id, 'experience', -1);
      },
      className: "text-[10px] active:scale-90",
      style: {
        color: 'var(--tq-gold)'
      }
    }, "\u2212"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        fontSize: '0.75rem',
        color: 'var(--tq-gold)',
        fontWeight: 600
      }
    }, "\u2B50 ", p.experience), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustCounter(p.id, 'experience', 1);
      },
      className: "text-[10px] active:scale-90",
      style: {
        color: 'var(--tq-gold)'
      }
    }, "+")), (p.commanderTax || 0) > 0 && /*#__PURE__*/React.createElement("div", {
      className: "flex items-center gap-1 px-2 py-1 rounded",
      style: {
        background: 'rgba(180, 212, 160, 0.15)',
        border: '1px solid rgba(180, 212, 160, 0.3)'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustCounter(p.id, 'commanderTax', -1);
      },
      className: "text-[10px] active:scale-90",
      style: {
        color: 'var(--tq-life)'
      }
    }, "\u2212"), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        fontSize: '0.75rem',
        color: 'var(--tq-life)',
        fontWeight: 600
      }
    }, "\uD83D\uDC51 ", p.commanderTax), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustCounter(p.id, 'commanderTax', 1);
      },
      className: "text-[10px] active:scale-90",
      style: {
        color: 'var(--tq-life)'
      }
    }, "+"))), /*#__PURE__*/React.createElement("div", {
      className: "flex border-t",
      style: {
        borderColor: "rgba(201, 169, 97, 0.2)"
      }
    }, [-5, -1, 1, 5].map(function (delta) {
      return /*#__PURE__*/React.createElement("button", {
        key: delta,
        onClick: function onClick() {
          return adjustLife(p.id, delta);
        },
        className: "flex-1 py-2 text-xs active:scale-95 transition-transform",
        style: {
          fontFamily: "'JetBrains Mono', monospace",
          fontWeight: 600,
          color: delta > 0 ? "var(--tq-life)" : "var(--tq-danger)",
          background: delta > 0 ? "rgba(107, 142, 90, 0.08)" : "rgba(160, 48, 44, 0.08)",
          borderLeft: delta === -5 ? "none" : "1px solid rgba(201, 169, 97, 0.15)"
        }
      }, delta > 0 ? "+".concat(delta) : delta);
    })));
  })), /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-center gap-2 mt-6"
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-[9px] tracking-widest uppercase",
    style: {
      color: "var(--tq-ink-faint)",
      fontFamily: "'Cinzel', serif"
    }
  }, "Reset to"), [20, 30, 40].map(function (n) {
    return /*#__PURE__*/React.createElement("button", {
      key: n,
      onClick: function onClick() {
        return resetLife(n);
      },
      className: "px-3 py-1 text-[10px] tracking-widest active:scale-95",
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        fontWeight: 600,
        color: "var(--tq-gold)",
        border: "1px solid rgba(201, 169, 97, 0.3)",
        borderRadius: "2px"
      }
    }, n);
  }))), showResetConfirm && /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 z-[100] flex items-center justify-center px-4",
    style: {
      background: 'rgba(5, 3, 10, 0.97)',
      backdropFilter: 'blur(12px) saturate(120%)',
      WebkitBackdropFilter: 'blur(12px) saturate(120%)'
    },
    onClick: function onClick() {
      return setShowResetConfirm(false);
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-full max-w-sm p-6 rounded-lg",
    style: {
      background: 'linear-gradient(180deg, #2d1f14 0%, var(--tq-surface) 100%)',
      border: '2px solid var(--tq-danger)',
      boxShadow: '0 0 30px rgba(212, 138, 134, 0.3)'
    },
    onClick: function onClick(e) {
      return e.stopPropagation();
    }
  }, /*#__PURE__*/React.createElement("h3", {
    className: "text-center mb-4",
    style: {
      fontFamily: "'Cinzel', serif",
      color: 'var(--tq-danger)',
      fontSize: '1.1rem',
      fontWeight: 600
    }
  }, "Reset Life Totals?"), /*#__PURE__*/React.createElement("p", {
    className: "text-center mb-6",
    style: {
      color: 'var(--tq-ink-dim)',
      fontSize: '0.9rem'
    }
  }, "This will reset all players to 40 life and clear commander damage."), /*#__PURE__*/React.createElement("div", {
    className: "flex gap-3"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return setShowResetConfirm(false);
    },
    className: "flex-1 py-3 rounded active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      background: 'rgba(154, 135, 101, 0.2)',
      border: '1px solid rgba(154, 135, 101, 0.4)',
      color: 'var(--tq-ink-dim)',
      fontSize: '0.9rem',
      fontWeight: 600,
      letterSpacing: '0.05em'
    }
  }, "CANCEL"), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return resetLife(40);
    },
    className: "flex-1 py-3 rounded active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      background: 'linear-gradient(180deg, var(--tq-danger), var(--tq-danger-deep))',
      border: '1px solid var(--tq-danger)',
      color: '#ffffff',
      fontSize: '0.9rem',
      fontWeight: 600,
      letterSpacing: '0.05em'
    }
  }, "RESET")))), showNewGameMenu && /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 z-[100] flex items-center justify-center px-4",
    style: {
      background: 'rgba(5, 3, 10, 0.97)',
      backdropFilter: 'blur(12px) saturate(120%)',
      WebkitBackdropFilter: 'blur(12px) saturate(120%)'
    },
    onClick: function onClick() {
      return setShowNewGameMenu(false);
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-full max-w-sm p-6 rounded-lg",
    style: {
      background: 'linear-gradient(180deg, #2d1f14 0%, var(--tq-surface) 100%)',
      border: '2px solid var(--tq-life-deep)',
      boxShadow: '0 0 30px rgba(143, 188, 143, 0.3)'
    },
    onClick: function onClick(e) {
      return e.stopPropagation();
    }
  }, /*#__PURE__*/React.createElement("h3", {
    className: "text-center mb-2",
    style: {
      fontFamily: "'Cinzel', serif",
      color: 'var(--tq-life-deep)',
      fontSize: '1.1rem',
      fontWeight: 600
    }
  }, "Start New Game"), /*#__PURE__*/React.createElement("p", {
    className: "text-center mb-6",
    style: {
      color: 'var(--tq-ink-dim)',
      fontSize: '0.85rem'
    }
  }, "This will reset everything and start fresh"), /*#__PURE__*/React.createElement("div", {
    className: "mb-5"
  }, /*#__PURE__*/React.createElement("label", {
    className: "block mb-2 text-xs uppercase tracking-widest",
    style: {
      fontFamily: "'Cinzel', serif",
      color: 'var(--tq-gold)'
    }
  }, "Players"), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-3 gap-2"
  }, [2, 3, 4].map(function (count) {
    return /*#__PURE__*/React.createElement("button", {
      key: count,
      onClick: function onClick() {
        var life = count === 2 ? 20 : 40;
        startNewGame(count, life);
      },
      className: "py-4 rounded active:scale-95",
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        background: 'rgba(143, 188, 143, 0.15)',
        border: '1px solid rgba(143, 188, 143, 0.4)',
        color: 'var(--tq-life-deep)',
        fontSize: '1.5rem',
        fontWeight: 700
      }
    }, count, "P");
  }))), /*#__PURE__*/React.createElement("div", {
    className: "mb-5"
  }, /*#__PURE__*/React.createElement("label", {
    className: "block mb-2 text-xs uppercase tracking-widest",
    style: {
      fontFamily: "'Cinzel', serif",
      color: 'var(--tq-gold)'
    }
  }, "Format"), /*#__PURE__*/React.createElement("div", {
    className: "space-y-2"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return startNewGame(4, 40);
    },
    className: "w-full py-3 rounded active:scale-95 flex items-center justify-between px-4",
    style: {
      fontFamily: "'Cinzel', serif",
      background: 'rgba(143, 188, 143, 0.15)',
      border: '1px solid rgba(143, 188, 143, 0.4)',
      color: 'var(--tq-gold-deep)',
      fontSize: '0.9rem',
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement("span", null, "Commander"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--tq-life-deep)'
    }
  }, "4P \xB7 40 Life")), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return startNewGame(2, 20);
    },
    className: "w-full py-3 rounded active:scale-95 flex items-center justify-between px-4",
    style: {
      fontFamily: "'Cinzel', serif",
      background: 'rgba(143, 188, 143, 0.15)',
      border: '1px solid rgba(143, 188, 143, 0.4)',
      color: 'var(--tq-gold-deep)',
      fontSize: '0.9rem',
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement("span", null, "Standard / Modern"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--tq-life-deep)'
    }
  }, "2P \xB7 20 Life")))), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return setShowNewGameMenu(false);
    },
    className: "w-full py-2 rounded active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      background: 'rgba(154, 135, 101, 0.2)',
      border: '1px solid rgba(154, 135, 101, 0.4)',
      color: 'var(--tq-ink-dim)',
      fontSize: '0.85rem',
      letterSpacing: '0.05em'
    }
  }, "CANCEL"))), activeTab === 'tools' && /*#__PURE__*/React.createElement("div", {
    className: "space-y-6 mb-6 tab-enter",
    key: "tools"
  }, /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2 mb-3"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-1 h-4",
    style: {
      background: "linear-gradient(180deg, var(--tq-gold-deep), var(--tq-gold) 50%, transparent)",
      borderRadius: "1px",
      boxShadow: "0 0 4px rgba(212, 184, 122, 0.3)"
    }
  }), /*#__PURE__*/React.createElement("h2", {
    className: "text-[10px] sm:text-xs tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      fontWeight: 600
    }
  }, "Game State")), /*#__PURE__*/React.createElement("div", {
    className: "p-3 space-y-3",
    style: {
      background: "linear-gradient(180deg, rgba(20, 14, 8, 0.8), rgba(10, 6, 4, 0.6))",
      border: "1px solid rgba(201, 169, 97, 0.3)",
      borderRadius: "3px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between gap-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2 min-w-0 flex-1"
  }, dayNight === 'night' ? /*#__PURE__*/React.createElement(Moon, {
    style: {
      color: "var(--tq-info)",
      fontSize: '1.1rem'
    }
  }) : /*#__PURE__*/React.createElement(Sun, {
    style: {
      color: "var(--tq-gold-bright)",
      fontSize: '1.1rem'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "min-w-0"
  }, /*#__PURE__*/React.createElement("p", {
    className: "text-[9px] tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)"
    }
  }, "Day / Night"), /*#__PURE__*/React.createElement("p", {
    className: "text-sm",
    style: {
      fontFamily: "'Cinzel', serif",
      color: dayNight ? dayNight === 'night' ? "var(--tq-info)" : "var(--tq-gold-bright)" : "var(--tq-ink-faint)",
      fontWeight: 600
    }
  }, dayNight === 'day' ? 'Day' : dayNight === 'night' ? 'Night' : 'Inactive'))), /*#__PURE__*/React.createElement("div", {
    className: "flex gap-1.5 flex-shrink-0"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: toggleDayNight,
    className: "px-2.5 py-1.5 text-[10px] tracking-widest uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: dayNight ? "var(--tq-surface)" : "var(--tq-gold)",
      background: dayNight ? "linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))" : "transparent",
      border: "1px solid ".concat(dayNight ? "var(--tq-gold)" : "rgba(201, 169, 97, 0.4)"),
      borderRadius: "2px"
    }
  }, dayNight === 'day' ? 'To Night' : dayNight === 'night' ? 'To Day' : 'Begin'), dayNight && /*#__PURE__*/React.createElement("button", {
    onClick: clearDayNight,
    className: "w-7 h-7 flex items-center justify-center active:scale-90",
    style: {
      border: "1px solid rgba(154, 135, 101, 0.3)",
      borderRadius: "2px",
      color: "var(--tq-ink-dim)"
    },
    "aria-label": "Clear day/night"
  }, /*#__PURE__*/React.createElement(XIcon, {
    style: {
      fontSize: '0.75rem'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    className: "h-px",
    style: {
      background: "rgba(201, 169, 97, 0.15)"
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2 mb-2"
  }, /*#__PURE__*/React.createElement(Crown, {
    style: {
      color: monarch ? "var(--tq-gold-deep)" : "var(--tq-ink-faint)",
      fontSize: '1.1rem'
    }
  }), /*#__PURE__*/React.createElement("p", {
    className: "text-[9px] tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)"
    }
  }, "Monarch"), monarch && /*#__PURE__*/React.createElement("span", {
    className: "text-xs",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold-deep)",
      fontWeight: 600
    }
  }, (_players$find = players.find(function (p) {
    return p.id === monarch;
  })) === null || _players$find === void 0 ? void 0 : _players$find.name)), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-2 gap-1.5"
  }, players.map(function (p) {
    return /*#__PURE__*/React.createElement("button", {
      key: p.id,
      onClick: function onClick() {
        return setMonarchPlayer(p.id);
      },
      className: "px-2 py-1.5 text-[10px] tracking-widest uppercase active:scale-95 flex items-center justify-center gap-1.5",
      style: {
        fontFamily: "'Cinzel', serif",
        color: monarch === p.id ? "var(--tq-surface)" : p.color,
        background: monarch === p.id ? "linear-gradient(180deg, ".concat(p.color, "cc, ").concat(p.color, "88)") : 'transparent',
        border: "1px solid ".concat(monarch === p.id ? p.color : p.color + '55'),
        borderRadius: "2px"
      }
    }, monarch === p.id && /*#__PURE__*/React.createElement(Crown, {
      style: {
        fontSize: '0.75rem'
      }
    }), /*#__PURE__*/React.createElement("span", {
      className: "truncate"
    }, p.name));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "h-px",
    style: {
      background: "rgba(201, 169, 97, 0.15)"
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2 mb-2"
  }, /*#__PURE__*/React.createElement(Sword, {
    style: {
      color: initiative ? "var(--tq-danger-soft)" : "var(--tq-ink-faint)",
      fontSize: '1.1rem'
    }
  }), /*#__PURE__*/React.createElement("p", {
    className: "text-[9px] tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)"
    }
  }, "Initiative"), initiative && /*#__PURE__*/React.createElement("span", {
    className: "text-xs",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-danger-soft)",
      fontWeight: 600
    }
  }, (_players$find2 = players.find(function (p) {
    return p.id === initiative;
  })) === null || _players$find2 === void 0 ? void 0 : _players$find2.name)), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-2 gap-1.5"
  }, players.map(function (p) {
    return /*#__PURE__*/React.createElement("button", {
      key: p.id,
      onClick: function onClick() {
        return setInitiativePlayer(p.id);
      },
      className: "px-2 py-1.5 text-[10px] tracking-widest uppercase active:scale-95 flex items-center justify-center gap-1.5",
      style: {
        fontFamily: "'Cinzel', serif",
        color: initiative === p.id ? "var(--tq-surface)" : p.color,
        background: initiative === p.id ? "linear-gradient(180deg, ".concat(p.color, "cc, ").concat(p.color, "88)") : 'transparent',
        border: "1px solid ".concat(initiative === p.id ? p.color : p.color + '55'),
        borderRadius: "2px"
      }
    }, initiative === p.id && /*#__PURE__*/React.createElement(Sword, {
      style: {
        fontSize: '0.75rem'
      }
    }), /*#__PURE__*/React.createElement("span", {
      className: "truncate"
    }, p.name));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "h-px",
    style: {
      background: "rgba(201, 169, 97, 0.15)"
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2 mb-2"
  }, /*#__PURE__*/React.createElement(Sparkles, {
    style: {
      color: citysBlessing.length > 0 ? "#c9a9c9" : "var(--tq-ink-faint)",
      fontSize: '1.1rem'
    }
  }), /*#__PURE__*/React.createElement("p", {
    className: "text-[9px] tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)"
    }
  }, "City's Blessing"), /*#__PURE__*/React.createElement("span", {
    className: "text-[9px]",
    style: {
      color: "var(--tq-ink-faint)"
    }
  }, "(10+ permanents)")), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-2 gap-1.5"
  }, players.map(function (p) {
    var blessed = citysBlessing.includes(p.id);
    return /*#__PURE__*/React.createElement("button", {
      key: p.id,
      onClick: function onClick() {
        return toggleCitysBlessing(p.id);
      },
      className: "px-2 py-1.5 text-[10px] tracking-widest uppercase active:scale-95 flex items-center justify-center gap-1.5",
      style: {
        fontFamily: "'Cinzel', serif",
        color: blessed ? "var(--tq-surface)" : p.color,
        background: blessed ? "linear-gradient(180deg, ".concat(p.color, "cc, ").concat(p.color, "88)") : 'transparent',
        border: "1px solid ".concat(blessed ? p.color : p.color + '55'),
        borderRadius: "2px"
      }
    }, blessed && /*#__PURE__*/React.createElement(Sparkles, {
      style: {
        fontSize: '0.75rem'
      }
    }), /*#__PURE__*/React.createElement("span", {
      className: "truncate"
    }, p.name));
  }))))), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between mb-3"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-1 h-4",
    style: {
      background: "linear-gradient(180deg, var(--tq-gold-deep), var(--tq-gold) 50%, transparent)",
      borderRadius: "1px",
      boxShadow: "0 0 4px rgba(212, 184, 122, 0.3)"
    }
  }), /*#__PURE__*/React.createElement("h2", {
    className: "text-[10px] sm:text-xs tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      fontWeight: 600
    }
  }, "Turn Tracker")), /*#__PURE__*/React.createElement("button", {
    onClick: resetTurnTracker,
    className: "flex items-center gap-1 text-[10px] uppercase tracking-widest px-2 py-1 active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)",
      border: "1px solid rgba(154, 135, 101, 0.3)",
      borderRadius: "2px"
    }
  }, /*#__PURE__*/React.createElement(Undo, {
    style: {
      fontSize: '0.75rem'
    }
  }), "Reset")), /*#__PURE__*/React.createElement("div", {
    className: "p-4",
    style: {
      background: "linear-gradient(180deg, rgba(20, 14, 8, 0.8), rgba(10, 6, 4, 0.6))",
      border: "1px solid rgba(201, 169, 97, 0.3)",
      borderRadius: "3px",
      boxShadow: "inset 0 1px 0 rgba(255, 255, 255, 0.04)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between mb-3"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-baseline gap-2"
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-[9px] tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)"
    }
  }, "Turn"), /*#__PURE__*/React.createElement("span", {
    className: "text-2xl font-bold",
    style: {
      fontFamily: "'JetBrains Mono', monospace",
      color: "var(--tq-gold-deep)",
      textShadow: "0 1px 2px rgba(0,0,0,0.5)"
    }
  }, turnNumber)), players[activePlayerIndex] && /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2 px-2.5 py-1",
    style: {
      background: "".concat(players[activePlayerIndex].color, "18"),
      border: "1px solid ".concat(players[activePlayerIndex].color, "66"),
      borderRadius: "2px"
    }
  }, /*#__PURE__*/React.createElement(User, {
    style: {
      color: players[activePlayerIndex].color,
      fontSize: '0.8rem'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "text-xs tracking-wide",
    style: {
      fontFamily: "'Cinzel', serif",
      color: players[activePlayerIndex].color,
      fontWeight: 600
    }
  }, players[activePlayerIndex].name))), /*#__PURE__*/React.createElement("div", {
    className: "mb-1 px-1"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 2,
      background: "rgba(201, 169, 97, 0.12)",
      borderRadius: 1,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      width: "".concat((phaseIndex + 1) / PHASES.length * 100, "%"),
      background: 'linear-gradient(90deg, var(--tq-gold), var(--tq-gold-bright))',
      transition: 'width 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
      boxShadow: '0 0 6px rgba(245, 217, 143, 0.4)'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "flex gap-1 mb-3 overflow-x-auto no-scrollbar pb-1"
  }, PHASES.map(function (phase, idx) {
    var isCurrent = idx === phaseIndex;
    var isPast = idx < phaseIndex;
    return /*#__PURE__*/React.createElement("button", {
      key: phase,
      onClick: function onClick() {
        haptic(15);
        setPhaseIndex(idx);
      },
      className: "flex-shrink-0 px-2.5 py-1.5 text-[9px] tracking-widest uppercase transition-all active:scale-95",
      style: {
        fontFamily: "'Cinzel', serif",
        fontWeight: isCurrent ? 700 : 500,
        color: isCurrent ? "var(--tq-surface)" : isPast ? "var(--tq-ink-mid)" : "var(--tq-gold)",
        background: isCurrent ? "linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))" : "transparent",
        border: "1px solid ".concat(isCurrent ? "var(--tq-gold)" : "rgba(201, 169, 97, 0.3)"),
        borderRadius: "2px",
        boxShadow: isCurrent ? "0 2px 10px rgba(245, 217, 143, 0.35), inset 0 1px 0 rgba(255,255,255,0.2)" : "none",
        opacity: isPast ? 0.5 : 1
      }
    }, phase);
  })), /*#__PURE__*/React.createElement("div", {
    className: "flex gap-2"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: retreatPhase,
    className: "flex-1 py-2.5 flex items-center justify-center gap-2 active:scale-95 transition-transform",
    style: {
      color: "var(--tq-gold)",
      background: "linear-gradient(180deg, rgba(201, 169, 97, 0.08), rgba(201, 169, 97, 0.02))",
      border: "1px solid rgba(201, 169, 97, 0.3)",
      borderRadius: "2px"
    }
  }, /*#__PURE__*/React.createElement(ChevronLeft, {
    style: {
      fontSize: '0.9rem'
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "text-[10px] tracking-widest uppercase",
    style: {
      fontFamily: "'Cinzel', serif"
    }
  }, "Prev")), /*#__PURE__*/React.createElement("button", {
    onClick: advancePhase,
    className: "flex-[2] py-2.5 flex items-center justify-center gap-2 active:scale-95 transition-transform",
    style: {
      color: "var(--tq-surface)",
      fontWeight: 600,
      background: "linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))",
      border: "1px solid var(--tq-gold)",
      borderRadius: "2px",
      boxShadow: "0 2px 8px rgba(201, 169, 97, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.2)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-[10px] tracking-widest uppercase",
    style: {
      fontFamily: "'Cinzel', serif"
    }
  }, phaseIndex >= PHASES.length - 1 ? "End turn" : "Next phase"), /*#__PURE__*/React.createElement(ChevronRight, {
    style: {
      fontSize: '0.9rem'
    }
  }))))), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between mb-3"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-1 h-4",
    style: {
      background: "linear-gradient(180deg, var(--tq-gold-deep), var(--tq-gold) 50%, transparent)",
      borderRadius: "1px",
      boxShadow: "0 0 4px rgba(212, 184, 122, 0.3)"
    }
  }), /*#__PURE__*/React.createElement("h2", {
    className: "text-[10px] sm:text-xs tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      fontWeight: 600
    }
  }, "Dice & Picks")), diceRolls.length > 0 && /*#__PURE__*/React.createElement("button", {
    onClick: clearRolls,
    className: "text-[10px] tracking-widest uppercase px-2 py-1 active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)",
      border: "1px solid rgba(154, 135, 101, 0.3)",
      borderRadius: "2px"
    }
  }, "Clear")), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-4 gap-2 mb-3"
  }, [4, 6, 8, 10, 12, 20].map(function (sides) {
    return /*#__PURE__*/React.createElement("button", {
      key: sides,
      onClick: function onClick() {
        return rollDie(sides);
      },
      disabled: rolling !== null,
      className: "py-4 active:scale-95 transition-transform disabled:opacity-50",
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        fontWeight: 700,
        fontSize: "1rem",
        color: "var(--tq-gold)",
        background: "linear-gradient(180deg, rgba(201, 169, 97, 0.1), rgba(201, 169, 97, 0.02))",
        border: "1px solid rgba(201, 169, 97, 0.3)",
        borderRadius: "2px",
        boxShadow: "inset 0 1px 0 rgba(255, 255, 255, 0.04)"
      }
    }, "d", sides);
  }), /*#__PURE__*/React.createElement("button", {
    onClick: flipCoin,
    disabled: rolling !== null,
    className: "py-4 flex items-center justify-center active:scale-95 transition-transform disabled:opacity-50",
    style: {
      color: "var(--tq-gold)",
      background: "linear-gradient(180deg, rgba(201, 169, 97, 0.1), rgba(201, 169, 97, 0.02))",
      border: "1px solid rgba(201, 169, 97, 0.3)",
      borderRadius: "2px"
    },
    title: "Flip coin"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Cinzel', serif",
      fontSize: "0.7rem",
      letterSpacing: "0.15em",
      textTransform: "uppercase",
      fontWeight: 600
    }
  }, "Coin")), /*#__PURE__*/React.createElement("button", {
    onClick: randomPlayer,
    disabled: rolling !== null || players.length === 0,
    className: "py-4 flex items-center justify-center gap-1 active:scale-95 transition-transform disabled:opacity-50",
    style: {
      color: "var(--tq-gold)",
      background: "linear-gradient(180deg, rgba(201, 169, 97, 0.1), rgba(201, 169, 97, 0.02))",
      border: "1px solid rgba(201, 169, 97, 0.3)",
      borderRadius: "2px"
    },
    title: "Random player"
  }, /*#__PURE__*/React.createElement(Shuffle, {
    style: {
      fontSize: '0.8rem'
    }
  }))), (rolling || diceRolls[0]) && /*#__PURE__*/React.createElement("div", {
    className: "p-4 text-center mb-3",
    style: {
      background: "linear-gradient(180deg, rgba(20, 14, 8, 0.9), rgba(10, 6, 4, 0.7))",
      border: "1.5px solid rgba(201, 169, 97, 0.4)",
      borderRadius: "3px",
      boxShadow: "0 0 20px rgba(201, 169, 97, 0.1)"
    }
  }, rolling ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("p", {
    className: "text-[9px] tracking-[0.3em] uppercase mb-1",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)"
    }
  }, "Rolling\u2026"), /*#__PURE__*/React.createElement("div", {
    className: "text-4xl font-bold animate-pulse",
    style: {
      fontFamily: "'JetBrains Mono', monospace",
      color: "var(--tq-gold-deep)"
    }
  }, "?")) : diceRolls[0] && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("p", {
    className: "text-[9px] tracking-[0.3em] uppercase mb-1",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-warm)",
      fontWeight: 600
    }
  }, diceRolls[0].sides === 'coin' ? 'Coin flip' : diceRolls[0].sides === 'player' ? 'Random pick' : "d".concat(diceRolls[0].sides)), /*#__PURE__*/React.createElement("div", {
    key: diceRolls[0].id,
    style: {
      fontFamily: diceRolls[0].sides === 'player' || diceRolls[0].sides === 'coin' ? "'Cinzel', serif" : "'JetBrains Mono', monospace",
      fontSize: diceRolls[0].sides === 'player' ? "1.5rem" : "3.25rem",
      fontWeight: 800,
      color: "var(--tq-gold-bright)",
      background: "linear-gradient(180deg, var(--tq-gold-bright) 0%, var(--tq-gold-deep) 50%, var(--tq-brass) 100%)",
      WebkitBackgroundClip: "text",
      WebkitTextFillColor: "transparent",
      backgroundClip: "text",
      filter: "drop-shadow(0 0 12px rgba(245, 217, 143, 0.4))",
      lineHeight: 1.1,
      animation: 'diceResultIn 0.35s cubic-bezier(0.34, 1.56, 0.64, 1)'
    }
  }, diceRolls[0].result))), diceRolls.length > 1 && /*#__PURE__*/React.createElement("div", {
    className: "flex gap-1.5 overflow-x-auto no-scrollbar pb-1"
  }, diceRolls.slice(1).map(function (r) {
    return /*#__PURE__*/React.createElement("div", {
      key: r.id,
      className: "flex-shrink-0 px-2 py-1 text-[10px]",
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        color: "var(--tq-ink-mid)",
        background: "rgba(20, 14, 8, 0.6)",
        border: "1px solid rgba(154, 135, 101, 0.25)",
        borderRadius: "2px"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--tq-ink-faint)"
      }
    }, r.sides === 'coin' ? '🪙' : r.sides === 'player' ? '👤' : "d".concat(r.sides, ":")), " ", /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--tq-gold)",
        fontWeight: 600
      }
    }, r.result));
  })))), /*#__PURE__*/React.createElement("footer", {
    className: "mt-10 pt-5",
    style: {
      borderTop: "1px solid rgba(201, 169, 97, 0.15)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex flex-col items-center gap-3 text-center"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex flex-col items-center gap-1"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-center gap-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "h-px w-6",
    style: {
      background: "linear-gradient(90deg, transparent, rgba(201, 169, 97, 0.5))"
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "text-[10px] tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-mid)"
    }
  }, "Forged by"), /*#__PURE__*/React.createElement("div", {
    className: "h-px w-6",
    style: {
      background: "linear-gradient(90deg, rgba(201, 169, 97, 0.5), transparent)"
    }
  })), /*#__PURE__*/React.createElement("span", {
    className: "text-sm tracking-[0.25em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 600,
      background: "linear-gradient(180deg, var(--tq-gold-bright) 0%, var(--tq-gold-deep) 40%, var(--tq-brass) 100%)",
      WebkitBackgroundClip: "text",
      WebkitTextFillColor: "transparent",
      backgroundClip: "text"
    }
  }, "Sodium Fabrications")), /*#__PURE__*/React.createElement("p", {
    className: "text-center text-[10px] italic px-4",
    style: {
      color: "var(--tq-ink-faint)",
      fontFamily: "'Crimson Pro', serif",
      lineHeight: 1.5
    }
  }, "Card data & art via Scryfall. Saved locally between sessions.", /*#__PURE__*/React.createElement("br", null), "Not affiliated with Wizards of the Coast.")))), copyOpen && /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 z-[100] flex items-start justify-center overflow-y-auto",
    style: {
      background: "rgba(5, 3, 10, 0.96)",
      backdropFilter: "blur(10px) saturate(120%)",
      WebkitBackdropFilter: "blur(10px) saturate(120%)"
    },
    onClick: function onClick() {
      return setCopyOpen(false);
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "relative w-full max-w-2xl my-4 mx-3",
    onClick: function onClick(e) {
      return e.stopPropagation();
    },
    style: {
      background: "radial-gradient(ellipse at top, var(--tq-surface) 0%, var(--tq-surface-deep) 100%)",
      border: "1px solid rgba(201, 169, 97, 0.4)",
      borderRadius: "3px",
      boxShadow: "0 0 40px rgba(0, 0, 0, 0.8)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between px-4 py-3",
    style: {
      borderBottom: "1px solid rgba(201, 169, 97, 0.2)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2"
  }, /*#__PURE__*/React.createElement(Copy, {
    style: {
      color: "var(--tq-info)",
      fontSize: '1rem'
    }
  }), /*#__PURE__*/React.createElement("h2", {
    className: "text-xs tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold-deep)",
      fontWeight: 600
    }
  }, "Copy Token")), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return setCopyOpen(false);
    },
    className: "w-8 h-8 flex items-center justify-center active:scale-90",
    style: {
      color: "var(--tq-ink-dim)"
    },
    "aria-label": "Close"
  }, /*#__PURE__*/React.createElement(XIcon, {
    style: {
      fontSize: '1rem'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "flex gap-2 px-4 pt-3"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return setCopyScope("tokens");
    },
    className: "flex-1 py-1.5 text-[10px] tracking-widest uppercase transition-all active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: copyScope === "tokens" ? "var(--tq-surface)" : "var(--tq-gold)",
      background: copyScope === "tokens" ? "var(--tq-gold)" : "transparent",
      border: "1px solid rgba(201, 169, 97, 0.4)",
      borderRadius: "2px"
    }
  }, "Tokens"), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return setCopyScope("creatures");
    },
    className: "flex-1 py-1.5 text-[10px] tracking-widest uppercase transition-all active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: copyScope === "creatures" ? "var(--tq-surface)" : "var(--tq-gold)",
      background: copyScope === "creatures" ? "var(--tq-gold)" : "transparent",
      border: "1px solid rgba(201, 169, 97, 0.4)",
      borderRadius: "2px"
    }
  }, "All Creatures")), /*#__PURE__*/React.createElement("div", {
    className: "px-4 pt-3"
  }, /*#__PURE__*/React.createElement("div", {
    className: "relative",
    style: {
      background: "rgba(20, 14, 8, 0.6)",
      border: "1px solid rgba(201, 169, 97, 0.3)",
      borderRadius: "2px"
    }
  }, /*#__PURE__*/React.createElement(Search, {
    style: {
      color: "var(--tq-ink-dim)",
      fontSize: '1rem',
      position: 'absolute',
      left: '0.75rem',
      top: '50%',
      transform: 'translateY(-50%)'
    }
  }), /*#__PURE__*/React.createElement("input", {
    type: "text",
    value: copyQuery,
    onChange: function onChange(e) {
      return setCopyQuery(e.target.value);
    },
    autoFocus: true,
    placeholder: copyScope === "tokens" ? "Search tokens to copy..." : "Search creatures to copy...",
    className: "search-green w-full bg-transparent pl-10 pr-10 py-3 text-base outline-none",
    style: {
      fontFamily: "'Crimson Pro', serif"
    }
  }), copyQuery && /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      setCopyQuery("");
      setCopyResults([]);
    },
    className: "absolute right-2 top-1/2 -translate-y-1/2 p-1.5",
    style: {
      color: "var(--tq-ink-dim)"
    },
    "aria-label": "Clear"
  }, /*#__PURE__*/React.createElement(XIcon, null))), /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] italic mt-2 text-center",
    style: {
      color: "var(--tq-ink-faint)"
    }
  }, "Tap a result to summon it as a copy")), /*#__PURE__*/React.createElement("div", {
    className: "px-4 py-3 max-h-[60vh] overflow-y-auto"
  }, copyLoading && /*#__PURE__*/React.createElement("div", {
    className: "flex justify-center py-6"
  }, /*#__PURE__*/React.createElement(Loader2, {
    className: "animate-spin",
    style: {
      color: "var(--tq-gold)",
      fontSize: '1.25rem'
    }
  })), copyError && !copyLoading && /*#__PURE__*/React.createElement("p", {
    className: "italic text-center py-4 text-sm",
    style: {
      color: "var(--tq-ink-dim)"
    }
  }, copyError), !copyLoading && !copyError && copyResults.length === 0 && copyQuery.trim().length < 2 && /*#__PURE__*/React.createElement("p", {
    className: "italic text-center py-4 text-sm",
    style: {
      color: "var(--tq-ink-faint)"
    }
  }, "Type at least 2 characters..."), !copyLoading && copyResults.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2"
  }, copyResults.map(function (card) {
    var _card$image_uris7, _card$image_uris8, _card$card_faces6;
    var img = ((_card$image_uris7 = card.image_uris) === null || _card$image_uris7 === void 0 ? void 0 : _card$image_uris7.small) || ((_card$image_uris8 = card.image_uris) === null || _card$image_uris8 === void 0 ? void 0 : _card$image_uris8.normal) || ((_card$card_faces6 = card.card_faces) === null || _card$card_faces6 === void 0 || (_card$card_faces6 = _card$card_faces6[0]) === null || _card$card_faces6 === void 0 || (_card$card_faces6 = _card$card_faces6.image_uris) === null || _card$card_faces6 === void 0 ? void 0 : _card$card_faces6.small) || "";
    return /*#__PURE__*/React.createElement("button", {
      key: card.id,
      onClick: function onClick() {
        return addAsCopy(card);
      },
      className: "relative block w-full transition-all active:scale-95",
      style: {
        borderRadius: "4.75% / 3.5%",
        overflow: "hidden"
      }
    }, img ? /*#__PURE__*/React.createElement("img", {
      src: img,
      alt: card.name,
      className: "w-full h-auto block"
    }) : /*#__PURE__*/React.createElement("div", {
      className: "aspect-[5/7] flex items-center justify-center text-[10px] p-2 text-center",
      style: {
        background: "#2a1f14",
        color: "var(--tq-gold)"
      }
    }, card.name));
  }))))), numpadFor !== null && function () {
    var target = battlefield.find(function (t) {
      return t.id === numpadFor;
    });
    if (!target) return null;
    var pressKey = function pressKey(k) {
      haptic(15);
      if (k === 'clear') setNumpadValue("");else if (k === 'back') setNumpadValue(function (v) {
        return v.slice(0, -1);
      });else if (numpadValue.length < 3) setNumpadValue(function (v) {
        return (v + k).replace(/^0+(?=\d)/, "");
      });
    };
    var commit = function commit() {
      setCount(numpadFor, numpadValue === "" ? target.count : numpadValue);
      setNumpadFor(null);
      setNumpadValue("");
    };
    var quickDelta = function quickDelta(delta) {
      adjustCount(numpadFor, delta);
      // Update the displayed value to reflect new count
      var newCount = Math.max(0, Math.min(999, target.count + delta));
      setNumpadValue(String(newCount));
    };
    var keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "clear", "0", "back"];
    var displayVal = numpadValue === "" ? String(target.count) : numpadValue;
    return /*#__PURE__*/React.createElement("div", {
      className: "fixed inset-0 z-[105] flex items-end justify-center",
      style: {
        background: "rgba(5, 3, 10, 0.92)",
        backdropFilter: "blur(8px) saturate(120%)",
        WebkitBackdropFilter: "blur(8px) saturate(120%)"
      },
      onClick: function onClick() {
        setNumpadFor(null);
        setNumpadValue("");
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "relative w-full max-w-sm",
      onClick: function onClick(e) {
        return e.stopPropagation();
      },
      style: {
        background: "radial-gradient(ellipse at top, var(--tq-surface) 0%, var(--tq-surface-deep) 100%)",
        border: "1px solid rgba(201, 169, 97, 0.4)",
        borderTopLeftRadius: "6px",
        borderTopRightRadius: "6px",
        boxShadow: "0 -8px 40px rgba(0, 0, 0, 0.8)",
        paddingBottom: 'env(safe-area-inset-bottom)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "flex items-center justify-between px-4 py-2.5",
      style: {
        borderBottom: "1px solid rgba(201, 169, 97, 0.2)"
      }
    }, /*#__PURE__*/React.createElement("p", {
      className: "text-sm truncate",
      style: {
        fontFamily: "'Cinzel', serif",
        color: "var(--tq-ink)",
        fontWeight: 600
      }
    }, target.name), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        haptic(15);
        setNumpadFor(null);
        setNumpadValue("");
      },
      className: "w-10 h-10 flex items-center justify-center active:scale-90",
      style: {
        color: "var(--tq-gold)",
        background: "rgba(20, 14, 8, 0.6)",
        border: "1px solid rgba(201, 169, 97, 0.35)",
        borderRadius: "3px"
      },
      "aria-label": "Close"
    }, /*#__PURE__*/React.createElement(XIcon, {
      style: {
        fontSize: '1rem'
      }
    }))), /*#__PURE__*/React.createElement("div", {
      className: "flex items-center gap-2 px-4 pt-3 pb-2"
    }, [[-5, '-5'], [-1, '-1'], [1, '+1'], [5, '+5']].map(function (_ref28) {
      var _ref29 = _slicedToArray(_ref28, 2),
        d = _ref29[0],
        label = _ref29[1];
      return /*#__PURE__*/React.createElement("button", {
        key: d,
        onClick: function onClick() {
          return quickDelta(d);
        },
        className: "flex-1 py-3 text-base active:scale-95 transition-transform",
        style: {
          fontFamily: "'JetBrains Mono', monospace",
          fontWeight: 700,
          color: d < 0 ? "var(--tq-danger)" : "var(--tq-life)",
          background: d < 0 ? "rgba(160, 48, 44, 0.12)" : "rgba(107, 142, 90, 0.12)",
          border: "1px solid ".concat(d < 0 ? "rgba(160, 48, 44, 0.35)" : "rgba(107, 142, 90, 0.35)"),
          borderRadius: "2px"
        }
      }, label);
    })), /*#__PURE__*/React.createElement("div", {
      className: "px-4 pb-2"
    }, /*#__PURE__*/React.createElement("div", {
      className: "text-center py-3",
      style: {
        background: "rgba(10, 6, 4, 0.6)",
        border: "1.5px solid var(--tq-gold)",
        borderRadius: "2px",
        fontFamily: "'JetBrains Mono', monospace",
        color: "var(--tq-gold-deep)",
        fontWeight: 700,
        fontSize: "2rem",
        boxShadow: "0 0 16px rgba(201, 169, 97, 0.25)"
      }
    }, displayVal)), /*#__PURE__*/React.createElement("div", {
      className: "grid grid-cols-3 gap-1.5 px-4 pb-2"
    }, keys.map(function (k) {
      return /*#__PURE__*/React.createElement("button", {
        key: k,
        onClick: function onClick() {
          return pressKey(k);
        },
        className: "py-3.5 text-base active:scale-95 transition-transform",
        style: {
          fontFamily: "'JetBrains Mono', monospace",
          fontWeight: 600,
          color: k === 'clear' || k === 'back' ? "var(--tq-danger)" : "var(--tq-ink)",
          background: "linear-gradient(180deg, rgba(201, 169, 97, 0.08), rgba(201, 169, 97, 0.02))",
          border: "1px solid rgba(201, 169, 97, 0.25)",
          borderRadius: "2px"
        }
      }, k === 'back' ? '<-' : k === 'clear' ? 'C' : k);
    })), /*#__PURE__*/React.createElement("div", {
      className: "px-4 pb-3"
    }, /*#__PURE__*/React.createElement("button", {
      onClick: commit,
      className: "w-full py-2.5 text-xs tracking-[0.3em] uppercase active:scale-95 transition-transform",
      style: {
        fontFamily: "'Cinzel', serif",
        fontWeight: 600,
        color: "var(--tq-surface)",
        background: "linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))",
        border: "1px solid var(--tq-gold)",
        borderRadius: "2px"
      }
    }, "Set to ", displayVal))));
  }(), wipeConfirmOpen && /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 z-[105] flex items-center justify-center p-4",
    style: {
      background: "rgba(5, 3, 10, 0.96)",
      backdropFilter: "blur(10px) saturate(120%)",
      WebkitBackdropFilter: "blur(10px) saturate(120%)"
    },
    onClick: function onClick() {
      return setWipeConfirmOpen(false);
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "relative w-full max-w-sm",
    onClick: function onClick(e) {
      return e.stopPropagation();
    },
    style: {
      background: "radial-gradient(ellipse at top, var(--tq-surface) 0%, var(--tq-surface-deep) 100%)",
      border: "1px solid rgba(160, 48, 44, 0.5)",
      borderRadius: "3px",
      boxShadow: "0 0 40px rgba(0, 0, 0, 0.8), 0 0 30px rgba(160, 48, 44, 0.15)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "px-5 py-5 text-center"
  }, /*#__PURE__*/React.createElement(AlertTriangle, {
    style: {
      color: "var(--tq-danger)",
      fontSize: '2rem',
      margin: '0 auto 0.75rem'
    }
  }), /*#__PURE__*/React.createElement("h2", {
    className: "text-sm tracking-[0.25em] uppercase mb-2",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-danger)",
      fontWeight: 600
    }
  }, "Wipe battlefield?"), /*#__PURE__*/React.createElement("p", {
    className: "text-sm italic mb-1",
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-gold)"
    }
  }, totalTokens, " token", totalTokens === 1 ? "" : "s", " across ", uniqueTypes, " type", uniqueTypes === 1 ? "" : "s"), /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] italic mb-5",
    style: {
      color: "var(--tq-ink-mid)"
    }
  }, "You can undo this."), /*#__PURE__*/React.createElement("div", {
    className: "flex gap-2"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      haptic(25);
      setWipeConfirmOpen(false);
    },
    className: "flex-1 py-2.5 text-[10px] tracking-widest uppercase active:scale-95 transition-transform",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      background: "transparent",
      border: "1px solid rgba(201, 169, 97, 0.4)",
      borderRadius: "2px"
    }
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    onClick: confirmWipe,
    className: "flex-1 py-2.5 text-[10px] tracking-widest uppercase active:scale-95 transition-transform",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 600,
      color: "#fff",
      background: "linear-gradient(180deg, #c0453f, #8a2d29)",
      border: "1px solid var(--tq-danger-deep)",
      borderRadius: "2px",
      boxShadow: "0 2px 8px rgba(160, 48, 44, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.15)"
    }
  }, "Wipe"))))), sanctumOpen && /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 z-[120]",
    style: {
      background: "radial-gradient(ellipse at top, rgba(40, 25, 60, 0.98) 0%, rgba(5, 3, 10, 0.99) 70%)",
      backdropFilter: "blur(14px) saturate(120%)",
      WebkitBackdropFilter: "blur(14px) saturate(120%)",
      animation: "sanctumIn 0.4s ease-out",
      overflowY: "auto",
      WebkitOverflowScrolling: "touch"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      haptic(15);
      setSanctumOpen(false);
      setHatcheryDoorOpen(false);
    },
    "aria-label": "Close Sanctum",
    className: "fixed top-3 right-3 z-[125] active:scale-90 transition-transform",
    style: {
      width: 40,
      height: 40,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'rgba(10, 6, 4, 0.85)',
      border: '1px solid rgba(201, 169, 97, 0.4)',
      borderRadius: '50%',
      color: 'var(--tq-gold)',
      fontSize: '1.1rem',
      fontFamily: "'Cinzel', serif",
      cursor: 'pointer',
      boxShadow: '0 2px 12px rgba(0,0,0,0.6)',
      top: 'max(0.75rem, env(safe-area-inset-top))'
    }
  }, "\u2715"), /*#__PURE__*/React.createElement("div", {
    className: "relative w-full max-w-md mx-auto my-4 px-3",
    style: {
      paddingTop: 'max(1rem, env(safe-area-inset-top))',
      paddingBottom: 'max(1rem, env(safe-area-inset-bottom))'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "relative",
    style: {
      background: "linear-gradient(180deg, rgba(26, 17, 10, 0.95) 0%, rgba(10, 6, 4, 0.98) 100%)",
      border: "1px solid rgba(201, 169, 97, 0.5)",
      borderRadius: "3px",
      boxShadow: "0 0 60px rgba(212, 184, 122, 0.2), 0 20px 40px rgba(0, 0, 0, 0.8)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "absolute top-0 left-0 w-12 h-12 pointer-events-none",
    style: {
      borderTop: "1px solid var(--tq-gold)",
      borderLeft: "1px solid var(--tq-gold)",
      borderTopLeftRadius: "3px"
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "absolute top-0 right-0 w-12 h-12 pointer-events-none",
    style: {
      borderTop: "1px solid var(--tq-gold)",
      borderRight: "1px solid var(--tq-gold)",
      borderTopRightRadius: "3px"
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "absolute bottom-0 left-0 w-12 h-12 pointer-events-none",
    style: {
      borderBottom: "1px solid var(--tq-gold)",
      borderLeft: "1px solid var(--tq-gold)",
      borderBottomLeftRadius: "3px"
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "absolute bottom-0 right-0 w-12 h-12 pointer-events-none",
    style: {
      borderBottom: "1px solid var(--tq-gold)",
      borderRight: "1px solid var(--tq-gold)",
      borderBottomRightRadius: "3px"
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "px-6 pt-6 pb-4 text-center"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-center gap-3 mb-2"
  }, /*#__PURE__*/React.createElement(Sparkles, {
    style: {
      color: "var(--tq-gold-deep)",
      fontSize: '1rem'
    }
  }), /*#__PURE__*/React.createElement("h2", {
    className: "uppercase tracking-[0.4em] text-base",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 600,
      background: "linear-gradient(180deg, var(--tq-gold-bright) 0%, var(--tq-gold-deep) 50%, var(--tq-brass) 100%)",
      WebkitBackgroundClip: "text",
      WebkitTextFillColor: "transparent",
      backgroundClip: "text"
    }
  }, "The Sanctum"), /*#__PURE__*/React.createElement(Sparkles, {
    style: {
      color: "var(--tq-gold-deep)",
      fontSize: '1rem'
    }
  })), /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] italic",
    style: {
      color: "var(--tq-ink-dim)",
      fontFamily: "'Crimson Pro', serif"
    }
  }, "A hidden chamber, found by those who seek")), /*#__PURE__*/React.createElement("div", {
    className: "px-6 pb-6 space-y-5"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex gap-1 p-1",
    style: {
      background: "rgba(5,3,10,0.5)",
      border: "1px solid rgba(201,169,97,0.18)",
      borderRadius: "3px"
    }
  }, [{
    id: 'companion',
    label: 'Companion'
  }, {
    id: 'games',
    label: 'Games'
  }, {
    id: 'about',
    label: 'About'
  }].map(function (t) {
    var active = sanctumTab === t.id;
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      onClick: function onClick() {
        haptic(15);
        setSanctumTab(t.id);
      },
      className: "flex-1 py-2 text-[9px] tracking-[0.2em] uppercase active:scale-95 transition-all",
      style: {
        fontFamily: "'Cinzel', serif",
        fontWeight: active ? 700 : 500,
        color: active ? "var(--tq-surface-deep)" : "var(--tq-ink-warm)",
        background: active ? "linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))" : "transparent",
        border: active ? "1px solid var(--tq-gold)" : "1px solid transparent",
        borderRadius: "2px",
        boxShadow: active ? "0 2px 6px rgba(201,169,97,0.25)" : "none"
      }
    }, t.label);
  })), sanctumTab === 'about' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "text-center py-6 px-4",
    style: {
      background: "radial-gradient(ellipse at center, rgba(212, 184, 122, 0.08) 0%, transparent 70%)",
      border: "1px solid rgba(201, 169, 97, 0.25)",
      borderRadius: "2px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-center gap-2 mb-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "h-px w-8",
    style: {
      background: "linear-gradient(90deg, transparent, rgba(232, 148, 122, 0.6))"
    }
  }), /*#__PURE__*/React.createElement(Heart, {
    fill: "var(--tq-danger-soft)",
    style: {
      color: "var(--tq-danger-soft)",
      fontSize: '0.9rem'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "h-px w-8",
    style: {
      background: "linear-gradient(90deg, rgba(232, 148, 122, 0.6), transparent)"
    }
  })), /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] tracking-[0.3em] uppercase mb-2",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)"
    }
  }, "A Note"), /*#__PURE__*/React.createElement("p", {
    className: "italic text-base sm:text-lg",
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-ink)",
      lineHeight: 1.4
    }
  }, "Made with love for"), /*#__PURE__*/React.createElement("p", {
    className: "mt-1 text-2xl sm:text-3xl",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 700,
      background: "linear-gradient(180deg, var(--tq-gold-bright) 0%, var(--tq-danger-soft) 100%)",
      WebkitBackgroundClip: "text",
      WebkitTextFillColor: "transparent",
      backgroundClip: "text",
      letterSpacing: "0.15em"
    }
  }, "Dani")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2 mb-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-1 h-3",
    style: {
      background: "linear-gradient(180deg, var(--tq-gold-deep), var(--tq-gold) 50%, transparent)",
      borderRadius: "1px",
      boxShadow: "0 0 4px rgba(212, 184, 122, 0.3)"
    }
  }), /*#__PURE__*/React.createElement("p", {
    className: "text-[9px] tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)"
    }
  }, "About")), /*#__PURE__*/React.createElement("div", {
    className: "px-4 py-3 space-y-2",
    style: {
      background: "rgba(20, 14, 8, 0.5)",
      border: "1px solid rgba(201, 169, 97, 0.2)",
      borderRadius: "2px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex flex-col gap-0.5"
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-[9px] tracking-[0.25em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)"
    }
  }, "App"), /*#__PURE__*/React.createElement("span", {
    className: "text-sm",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink)",
      fontWeight: 600
    }
  }, "Token Queen")), /*#__PURE__*/React.createElement("div", {
    className: "flex flex-col gap-0.5"
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-[9px] tracking-[0.25em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)"
    }
  }, "Codename"), /*#__PURE__*/React.createElement("span", {
    className: "text-sm italic",
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-gold)"
    }
  }, "The Arcanist's Grimoire")), /*#__PURE__*/React.createElement("div", {
    className: "flex flex-col gap-0.5"
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-[9px] tracking-[0.25em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)"
    }
  }, "Forged by"), /*#__PURE__*/React.createElement("span", {
    className: "text-sm",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold-deep)",
      fontWeight: 600
    }
  }, "Sodium Fabrications")), /*#__PURE__*/React.createElement("div", {
    className: "flex flex-col gap-0.5"
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-[9px] tracking-[0.25em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)"
    }
  }, "Card data"), /*#__PURE__*/React.createElement("span", {
    className: "text-sm",
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-ink)"
    }
  }, "Scryfall")), /*#__PURE__*/React.createElement("div", {
    className: "flex flex-col gap-0.5"
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-[9px] tracking-[0.25em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)"
    }
  }, "Crafted in"), /*#__PURE__*/React.createElement("span", {
    className: "text-sm italic",
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-gold)"
    }
  }, "the Izzet League's labs"))), /*#__PURE__*/React.createElement("p", {
    className: "text-[9px] italic text-center mt-2",
    style: {
      color: "var(--tq-ink-faint)",
      fontFamily: "'Crimson Pro', serif"
    }
  }, "Not affiliated with Wizards of the Coast."))), sanctumTab === 'companion' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2 mb-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-1 h-3",
    style: {
      background: "linear-gradient(180deg, var(--tq-gold-deep), var(--tq-gold) 50%, transparent)",
      borderRadius: "1px",
      boxShadow: "0 0 4px rgba(212, 184, 122, 0.3)"
    }
  }), /*#__PURE__*/React.createElement("p", {
    className: "text-[9px] tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)"
    }
  }, pet ? 'Companion' : 'Hatchery')), !pet ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      minHeight: '220px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "px-4 py-5 text-center",
    style: {
      backgroundImage: window.TQ && window.TQ.hatcheryBackdrop ? window.TQ.hatcheryBackdrop({
        lit: unlockedOrbs.length
      }) : 'none',
      backgroundSize: 'cover',
      backgroundPosition: 'center 44%',
      backgroundRepeat: 'no-repeat',
      border: "1px solid rgba(201,169,97,0.28)",
      borderRadius: "3px",
      boxShadow: "inset 0 0 44px rgba(0,0,0,0.72), 0 2px 20px rgba(0,0,0,0.5)",
      minHeight: "252px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex justify-center mb-3"
  }, /*#__PURE__*/React.createElement(PetEgg, {
    orbsLit: unlockedOrbs.length,
    size: 100
  })), hatcheryDoorOpen && /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-center gap-2.5 mb-4",
    style: { position: 'relative', zIndex: 20 }
  }, WUBRG.map(function (c) {
    var lit = unlockedOrbs.includes(c);
    var cd = COLOR_DATA[c];
    return /*#__PURE__*/React.createElement("button", {
      key: c,
      onClick: function onClick() {
        return handleOrbTap(c);
      },
      className: "active:scale-90 transition-all",
      style: {
        width: '40px',
        height: '40px',
        borderRadius: '50%',
        background: 'transparent',
        border: "2px solid ".concat(lit ? cd.symbol : cd.symbol + '44'),
        boxShadow: lit ? "0 0 16px ".concat(cd.glow, ", 0 0 8px ").concat(cd.glow, " inset") : "none",
        opacity: lit ? 1 : 0.45,
        transition: 'all 0.3s ease',
        cursor: 'pointer',
        padding: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        filter: lit ? 'none' : 'grayscale(0.6)'
      },
      "aria-label": "".concat(cd.name, " mana orb")
    }, /*#__PURE__*/React.createElement("img", {
      src: "https://svgs.scryfall.io/card-symbols/" + c + ".svg",
      alt: "{" + c + "}",
      onError: function onError(e) {
        if (e.currentTarget.dataset.tqFb === "1") return;
        e.currentTarget.dataset.tqFb = "1";
        e.currentTarget.src = "img/mana/" + c + ".svg";
      },
      style: { width: 28, height: 28, display: 'block' }
    }));
  })), /*#__PURE__*/React.createElement("p", {
    className: "text-sm italic mb-1",
    style: {
      color: "var(--tq-gold)",
      fontFamily: "'Crimson Pro', serif"
    }
  }, "An egg awaits its spark..."), /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] tracking-[0.2em] uppercase mb-2",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-faint)"
    }
  }, "Solve the runes to hatch"), showDiscoveryHint && /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] italic mt-2",
    style: {
      color: "var(--tq-ink-mid)",
      fontFamily: "'Crimson Pro', serif",
      opacity: 0.85
    }
  }, "the orbs seem to remember an order...")), !hatcheryDoorOpen && /*#__PURE__*/React.createElement("div", {
    onClick: function onClick() {
      haptic([10]);
      if (window.TQ && window.TQ.openSealRiddle) {
        window.TQ.openSealRiddle(function () {
          haptic([20, 30, 60]);
          setHatcheryDoorOpen(true);
        });
      } else {
        setHatcheryDoorOpen(true);
      }
    },
    style: {
      position: 'absolute',
      inset: 0,
      cursor: 'pointer',
      zIndex: 10,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'radial-gradient(ellipse at center, rgba(20,12,6,0.95) 0%, rgba(10,6,4,0.98) 70%, rgba(5,3,2,1) 100%)',
      borderRadius: '2px',
      overflow: 'hidden'
    },
    "aria-label": "Tap to break the seal"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "82%",
    viewBox: "0 0 220 220",
    style: { maxHeight: '90%', filter: 'drop-shadow(0 0 24px rgba(201,169,97,0.35))' },
    xmlns: "http://www.w3.org/2000/svg"
  },
    /*#__PURE__*/React.createElement("defs", null,
      /*#__PURE__*/React.createElement("radialGradient", { id: "sealGlow", cx: "50%", cy: "50%", r: "55%" },
        /*#__PURE__*/React.createElement("stop", { offset: "0%", stopColor: "var(--tq-gold-bright)", stopOpacity: "0.45" }),
        /*#__PURE__*/React.createElement("stop", { offset: "60%", stopColor: "var(--tq-gold)", stopOpacity: "0.15" }),
        /*#__PURE__*/React.createElement("stop", { offset: "100%", stopColor: "var(--tq-gold)", stopOpacity: "0" })
      ),
      /*#__PURE__*/React.createElement("linearGradient", { id: "sealRing", x1: "0%", y1: "0%", x2: "100%", y2: "100%" },
        /*#__PURE__*/React.createElement("stop", { offset: "0%", stopColor: "var(--tq-gold-bright)" }),
        /*#__PURE__*/React.createElement("stop", { offset: "50%", stopColor: "var(--tq-gold)" }),
        /*#__PURE__*/React.createElement("stop", { offset: "100%", stopColor: "#8a6b3a" })
      )
    ),
    /*#__PURE__*/React.createElement("circle", { cx: "110", cy: "110", r: "100", fill: "url(#sealGlow)" }),
    /*#__PURE__*/React.createElement("circle", { cx: "110", cy: "110", r: "92", fill: "none", stroke: "url(#sealRing)", strokeWidth: "2.5" }),
    /*#__PURE__*/React.createElement("circle", { cx: "110", cy: "110", r: "86", fill: "none", stroke: "var(--tq-gold)", strokeWidth: "0.5", strokeDasharray: "3 2", opacity: "0.6" }),
    /*#__PURE__*/React.createElement("circle", { cx: "110", cy: "110", r: "72", fill: "none", stroke: "url(#sealRing)", strokeWidth: "1" }),
    /*#__PURE__*/[0,1,2,3,4,5,6,7,8,9,10,11].map(function (i) {
      var a = i * Math.PI / 6;
      var x1 = 110 + Math.cos(a) * 78;
      var y1 = 110 + Math.sin(a) * 78;
      var x2 = 110 + Math.cos(a) * 86;
      var y2 = 110 + Math.sin(a) * 86;
      return /*#__PURE__*/React.createElement("line", { key: "tick"+i, x1: x1, y1: y1, x2: x2, y2: y2, stroke: "var(--tq-gold)", strokeWidth: "1", opacity: i % 3 === 0 ? "1" : "0.5" });
    }),
    /*#__PURE__*/[0,1,2,3,4].map(function (i) {
      var a = i * 2 * Math.PI / 5 - Math.PI / 2;
      var x = 110 + Math.cos(a) * 50;
      var y = 110 + Math.sin(a) * 50;
      return /*#__PURE__*/React.createElement("g", { key: "pt"+i, transform: "translate("+x+" "+y+")" },
        /*#__PURE__*/React.createElement("circle", { r: "9", fill: "#15100a", stroke: "url(#sealRing)", strokeWidth: "1.5" }),
        /*#__PURE__*/React.createElement("circle", { r: "3", fill: "var(--tq-gold)", opacity: "0.85" },
          /*#__PURE__*/React.createElement("animate", { attributeName: "opacity", values: "0.85;0.35;0.85", dur: (2 + i * 0.2) + "s", repeatCount: "indefinite" })
        )
      );
    }),
    /*#__PURE__*/React.createElement("g", { transform: "translate(110 110)" },
      /*#__PURE__*/React.createElement("polygon", {
        points: "0,-32 8,-10 30,-10 12,4 18,26 0,14 -18,26 -12,4 -30,-10 -8,-10",
        fill: "var(--tq-gold)",
        opacity: "0.9"
      },
        /*#__PURE__*/React.createElement("animateTransform", { attributeName: "transform", type: "rotate", from: "0", to: "360", dur: "60s", repeatCount: "indefinite" })
      ),
      /*#__PURE__*/React.createElement("circle", { r: "8", fill: "#15100a" }),
      /*#__PURE__*/React.createElement("circle", { r: "4", fill: "var(--tq-gold-bright)" },
        /*#__PURE__*/React.createElement("animate", { attributeName: "r", values: "3.5;5;3.5", dur: "2.4s", repeatCount: "indefinite" })
      )
    ),
    /*#__PURE__*/React.createElement("text", {
      x: "110", y: "212", textAnchor: "middle",
      fontFamily: "'Cinzel', serif", fontSize: "8.5", fill: "var(--tq-ink-dim)",
      letterSpacing: "4", opacity: "0.85"
    }, "SPEAK THE WORD")
  )), hatcheryDoorOpen && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      width: '100%',
      height: '100%',
      transformOrigin: 'left center',
      animation: 'doorSwing 0.65s cubic-bezier(0.4,0,0.2,1) forwards',
      pointerEvents: 'none',
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "100%",
    height: "100%",
    viewBox: "0 0 300 220",
    preserveAspectRatio: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "2",
    width: "296",
    height: "216",
    rx: "3",
    fill: "#1a0e06",
    stroke: "#8a6030",
    strokeWidth: "3"
  }), [0, 1, 2, 3, 4].map(function (i) {
    return /*#__PURE__*/React.createElement("rect", {
      key: i,
      x: "6",
      y: 6 + i * 42,
      width: "288",
      height: "38",
      fill: i % 2 === 0 ? '#2a1a0a' : '#221508',
      rx: "1"
    });
  }), [48, 108, 168].map(function (y) {
    return /*#__PURE__*/React.createElement("rect", {
      key: y,
      x: "2",
      y: y,
      width: "296",
      height: "8",
      fill: "#2a2a2a",
      stroke: "#444",
      strokeWidth: "0.8"
    });
  }), /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "22",
    width: "22",
    height: "36",
    rx: "2",
    fill: "#3a3a3a",
    stroke: "#555",
    strokeWidth: "1"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "162",
    width: "22",
    height: "36",
    rx: "2",
    fill: "#3a3a3a",
    stroke: "#555",
    strokeWidth: "1"
  }))))) :
  /*#__PURE__*/
  /* Pet panel -- alive companion */
  React.createElement(PetPanel, {
    pet: pet,
    petHunger: petHunger,
    petHappiness: petHappiness,
    feedReady: feedReady,
    playReady: playReady,
    feedPet: feedPet,
    playWithPet: playWithPet,
    showAdvanced: showPetAdvanced,
    setShowAdvanced: setShowPetAdvanced,
    onRename: function onRename() {
      setPetNameInput(pet.name || '');
      setPetRenameOpen(true);
    },
    onReset: function onReset() {
      return setPetResetConfirmOpen(true);
    },
    onDevJuvenile: devSkipJuvenile,
    onDevAdult: devSkipAdult,
    onDevFeed: devResetFeedCD,
    onDevPlay: devResetPlayCD
  }))), sanctumTab === 'games' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2 mb-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-1 h-3",
    style: {
      background: "linear-gradient(180deg, var(--tq-gold-deep), var(--tq-gold) 50%, transparent)",
      borderRadius: "1px",
      boxShadow: "0 0 4px rgba(212, 184, 122, 0.3)"
    }
  }), /*#__PURE__*/React.createElement("p", {
    className: "text-[9px] tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)"
    }
  }, "Games"), /*#__PURE__*/React.createElement("div", {
    style: { display: "flex", alignItems: "center", gap: 6, marginTop: 4, marginBottom: 4, fontSize: 9, color: "var(--tq-ink-mid)", fontFamily: "'Cinzel', serif", letterSpacing: "0.15em" }
  },
    /*#__PURE__*/React.createElement("span", null, "MEMORY TIER:"),
    ['easy', 'normal', 'hard', 'expert'].map(function (tier) {
      var active = (window.TQ && window.TQ.memoryConfig && window.TQ.memoryConfig.tier) === tier;
      return /*#__PURE__*/React.createElement("button", {
        key: tier,
        onClick: function onClick() {
          if (window.TQ && window.TQ.memoryConfig) {
            window.TQ.memoryConfig.setTier(tier);
            haptic(8);
            setSanctumOpen(false);
            setTimeout(function () { setSanctumOpen(true); }, 20);
          }
        },
        style: {
          padding: "2px 6px",
          background: active ? "rgba(201,169,97,0.25)" : "transparent",
          border: "1px solid " + (active ? "var(--tq-gold)" : "rgba(154,135,101,0.3)"),
          color: active ? "var(--tq-gold-bright)" : "var(--tq-ink-dim)",
          borderRadius: "2px",
          fontFamily: "inherit",
          fontSize: "inherit",
          cursor: "pointer",
          textTransform: "uppercase"
        }
      }, tier);
    })
  )), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-2 gap-2"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      haptic(20);
      setSanctumOpen(false);
      setMemoryOpen(true);
    },
    className: "flex flex-col items-center gap-1.5 py-3 active:scale-95 transition-transform",
    style: {
      background: "radial-gradient(ellipse at top, rgba(201,169,97,0.12), rgba(20,14,8,0.6))",
      border: "1px solid rgba(201,169,97,0.35)",
      borderRadius: "2px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '1.5rem'
    }
  }, "\uD83C\uDCCF"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold-deep)",
      fontSize: "0.7rem",
      letterSpacing: "0.15em",
      textTransform: "uppercase"
    }
  }, "Memory"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-ink-faint)",
      fontSize: "0.6rem",
      fontStyle: "italic"
    }
  }, "Match the tokens")), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      haptic(20);
      setSanctumOpen(false);
      setDragonOpen(true);
    },
    className: "flex flex-col items-center gap-1.5 py-3 active:scale-95 transition-transform",
    style: {
      background: "radial-gradient(ellipse at top, rgba(160,48,44,0.12), rgba(20,14,8,0.6))",
      border: "1px solid rgba(160,48,44,0.35)",
      borderRadius: "2px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '1.5rem'
    }
  }, "\uD83D\uDC09"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-danger)",
      fontSize: "0.7rem",
      letterSpacing: "0.15em",
      textTransform: "uppercase"
    }
  }, "Flappy Dragon"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-ink-faint)",
      fontSize: "0.6rem",
      fontStyle: "italic"
    }
  }, "Dodge the pillars"))))), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      setSanctumOpen(false);
      setHatcheryDoorOpen(false);
    },
    className: "w-full py-3 text-xs tracking-[0.3em] uppercase active:scale-95 transition-transform",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 600,
      color: "var(--tq-gold)",
      background: "linear-gradient(180deg, rgba(201, 169, 97, 0.08), rgba(201, 169, 97, 0.02))",
      border: "1px solid rgba(201, 169, 97, 0.4)",
      borderRadius: "2px"
    }
  }, "Return"))))), memoryOpen && /*#__PURE__*/React.createElement(MemoryGame, {
    onClose: function onClose() {
      return setMemoryOpen(false);
    },
    pet: pet,
    setPet: setPet,
    showToast: showToast,
    haptic: haptic
  }), dragonOpen && /*#__PURE__*/React.createElement(FlappyDragon, {
    onClose: function onClose() {
      return setDragonOpen(false);
    },
    pet: pet,
    setPet: setPet,
    haptic: haptic
  }), bigPicture && activeTab === 'life' && (players.length === 2 || players.length === 4) && /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 z-[115]",
    style: {
      background: "#05030a",
      paddingTop: "env(safe-area-inset-top)",
      paddingBottom: "env(safe-area-inset-bottom)",
      display: "grid",
      gridTemplateColumns: players.length === 2 ? "1fr" : "1fr 1fr",
      gridTemplateRows: players.length === 2 ? "1fr 1fr" : "1fr 1fr",
      gap: "2px"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() { setBigPictureMenu(!bigPictureMenu); haptic(10); },
    style: {
      position: "absolute",
      top: "50%",
      left: "50%",
      transform: "translate(-50%, -50%)",
      zIndex: 30,
      width: "54px",
      height: "54px",
      borderRadius: "50%",
      background: bigPictureMenu
        ? "radial-gradient(circle at 35% 35%, rgba(245,217,143,0.95), rgba(201,169,97,0.85))"
        : "radial-gradient(circle at 35% 35%, rgba(20,14,8,0.98), rgba(10,6,4,0.98))",
      border: "2px solid var(--tq-gold)",
      boxShadow: "0 0 20px rgba(201,169,97,0.4), 0 4px 14px rgba(0,0,0,0.7), 0 0 0 6px rgba(5,3,4,0.95)",
      color: bigPictureMenu ? "var(--tq-surface)" : "var(--tq-gold)",
      fontFamily: "'Cinzel', serif",
      fontSize: bigPictureMenu ? "22px" : "10px",
      fontWeight: 700,
      letterSpacing: "0.18em",
      cursor: "pointer",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    },
    "aria-label": "Big picture menu"
  }, bigPictureMenu ? "×" : "MENU"),
    bigPictureMenu && /*#__PURE__*/React.createElement("div", {
      style: {
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        zIndex: 25,
        width: "260px",
        background: "linear-gradient(180deg, rgba(20,14,8,0.98), rgba(10,6,4,0.98))",
        border: "1px solid rgba(201,169,97,0.45)",
        borderRadius: "10px",
        padding: "84px 18px 18px",
        boxShadow: "0 10px 40px rgba(0,0,0,0.7), 0 0 32px rgba(201,169,97,0.15)",
        color: "var(--tq-ink)",
        fontFamily: "'Crimson Pro', serif",
        textAlign: "center"
      }
    },
      /*#__PURE__*/React.createElement("div", {
        style: { fontFamily: "'Cinzel', serif", fontSize: "10px", letterSpacing: "0.25em", color: "var(--tq-ink-dim)", textTransform: "uppercase", marginBottom: "12px" }
      }, "Big-Picture"),
      /*#__PURE__*/React.createElement("button", {
        onClick: function onClick() { setBigPicture(false); setBigPictureMenu(false); haptic(15); },
        style: { display: "block", width: "100%", margin: "6px 0", padding: "10px", background: "rgba(160,48,44,0.18)", color: "var(--tq-danger)", border: "1px solid var(--tq-danger-deep)66", borderRadius: "4px", fontFamily: "'Cinzel', serif", fontSize: "11px", letterSpacing: "0.18em", cursor: "pointer" }
      }, "× EXIT FULLSCREEN"),
      /*#__PURE__*/React.createElement("button", {
        onClick: function onClick() {
          setBigPictureMenu(false);
          setActiveTab('battlefield');
          haptic(10);
        },
        style: { display: "block", width: "100%", margin: "6px 0", padding: "10px", background: "rgba(20,14,8,0.6)", color: "var(--tq-gold)", border: "1px solid rgba(201,169,97,0.4)", borderRadius: "4px", fontFamily: "'Cinzel', serif", fontSize: "11px", letterSpacing: "0.18em", cursor: "pointer" }
      }, "TOKEN MANAGEMENT"),
      /*#__PURE__*/React.createElement("div", {
        style: { display: "flex", alignItems: "center", justifyContent: "center", gap: "6px", margin: "10px 0 4px" }
      },
        /*#__PURE__*/React.createElement("span", { style: { fontSize: "10px", color: "var(--tq-ink-dim)", letterSpacing: "0.2em", fontFamily: "'Cinzel', serif", marginRight: "4px" } }, "COLOUR"),
        ["var(--tq-gold-deep)", "var(--tq-info)", "#5a4060", "#d97757", "#7faf4f", "#fffbe6"].map(function (col) {
          return /*#__PURE__*/React.createElement("button", {
            key: col,
            onClick: function onClick() {
              setPlayers(function (prev) { return prev.map(function (pl, i) { return i === activePlayerIndex ? Object.assign({}, pl, { color: col }) : pl; }); });
              haptic(8);
            },
            style: { width: "22px", height: "22px", borderRadius: "50%", background: col, border: "2px solid rgba(255,255,255,0.15)", cursor: "pointer", padding: 0 }
          });
        })
      ),
      /*#__PURE__*/React.createElement("div", {
        style: { fontSize: "9px", color: "var(--tq-ink-faint)", marginTop: "6px", fontStyle: "italic" }
      }, "Colour applies to the active (highlighted) player.")
    ), players.map(function (p, idx) {
    var lifeColor = p.life <= 0 ? "var(--tq-danger-deep)" : p.life <= 10 ? "var(--tq-danger)" : "var(--tq-gold-deep)";
    // 2P: top player (idx 0) is rotated 180° so they read it across the table
    // 4P: top-left and top-right rotated 180°, bottom two normal
    var rotate = players.length === 2 ? (idx === 0 ? "180deg" : "0deg") : (idx < 2 ? "180deg" : "0deg");
    return /*#__PURE__*/React.createElement("div", {
      key: p.id,
      style: {
        background: "linear-gradient(180deg, rgba(20,14,8,0.95), rgba(10,6,4,0.92))",
        border: "1px solid " + p.color + "55",
        display: "flex",
        flexDirection: "column",
        alignItems: "stretch",
        justifyContent: "stretch",
        position: "relative",
        overflow: "hidden",
        transform: "rotate(" + rotate + ")"
      }
    },
      /*#__PURE__*/React.createElement("div", {
        style: {
          textAlign: "center",
          padding: "10px 0 4px",
          color: p.color,
          fontFamily: "'Cinzel', serif",
          fontSize: "11px",
          letterSpacing: "0.2em",
          textTransform: "uppercase",
          opacity: 0.85
        }
      }, p.name || ("Player " + (idx + 1))),
      /*#__PURE__*/React.createElement("div", {
        style: { flex: 1, display: "flex", alignItems: "center", justifyContent: "center", padding: "0 8px" }
      },
        /*#__PURE__*/React.createElement("button", {
          onClick: function onClick() { adjustLife(p.id, -1); },
          style: { flex: "0 0 auto", background: "transparent", border: "none", color: "var(--tq-danger-deep)", fontSize: "48px", padding: "0 16px", cursor: "pointer", fontFamily: "'Cinzel', serif" }
        }, "−"),
        /*#__PURE__*/React.createElement("div", {
          style: { flex: 1, textAlign: "center", color: lifeColor, fontFamily: "'Cinzel', serif", fontSize: players.length === 2 ? "150px" : "100px", fontWeight: 700, lineHeight: 1, textShadow: "0 0 24px " + lifeColor + "66" }
        }, p.life),
        /*#__PURE__*/React.createElement("button", {
          onClick: function onClick() { adjustLife(p.id, 1); },
          style: { flex: "0 0 auto", background: "transparent", border: "none", color: "#8aaa70", fontSize: "48px", padding: "0 16px", cursor: "pointer", fontFamily: "'Cinzel', serif" }
        }, "+")
      ),
      /*#__PURE__*/React.createElement("div", {
        style: { display: "flex", justifyContent: "center", gap: "8px", padding: "12px 0 16px" }
      }, [-5, -1, 1, 5].map(function (d) {
        return /*#__PURE__*/React.createElement("button", {
          key: d,
          onClick: function onClick() { adjustLife(p.id, d); },
          style: {
            padding: "6px 12px",
            background: d < 0 ? "rgba(160,48,44,0.18)" : "rgba(138,170,112,0.18)",
            border: "1px solid " + (d < 0 ? "var(--tq-danger-deep)66" : "#8aaa7066"),
            borderRadius: "3px",
            color: d < 0 ? "var(--tq-danger)" : "#a0c87a",
            fontFamily: "'JetBrains Mono', monospace",
            fontSize: "11px",
            cursor: "pointer"
          }
        }, (d > 0 ? "+" : "") + d);
      }))
    );
  })), hatchingOpen && /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 z-[130] flex items-start justify-center overflow-y-auto p-3",
    style: {
      background: "radial-gradient(ellipse at top, rgba(40, 30, 60, 0.97) 0%, rgba(5, 3, 10, 0.99) 70%)",
      backdropFilter: "blur(12px)",
      WebkitBackdropFilter: "blur(12px)",
      animation: "sanctumIn 0.4s ease-out"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "relative w-full max-w-md my-4",
    style: {
      background: "linear-gradient(180deg, rgba(26,17,10,0.98) 0%, rgba(10,6,4,0.99) 100%)",
      border: "1px solid rgba(201,169,97,0.5)",
      borderRadius: "3px",
      boxShadow: "0 0 80px rgba(212,184,122,0.3), 0 20px 50px rgba(0,0,0,0.9)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "absolute top-0 left-0 w-10 h-10 pointer-events-none",
    style: {
      borderTop: "1px solid var(--tq-gold)",
      borderLeft: "1px solid var(--tq-gold)",
      borderTopLeftRadius: "3px"
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "absolute top-0 right-0 w-10 h-10 pointer-events-none",
    style: {
      borderTop: "1px solid var(--tq-gold)",
      borderRight: "1px solid var(--tq-gold)",
      borderTopRightRadius: "3px"
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "px-5 pt-5 pb-3 text-center"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-center gap-2 mb-1"
  }, /*#__PURE__*/React.createElement(Sparkles, {
    style: {
      color: "var(--tq-gold-deep)",
      fontSize: '1rem'
    }
  }), /*#__PURE__*/React.createElement("h2", {
    className: "uppercase tracking-[0.35em] text-sm",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 600,
      background: "linear-gradient(180deg, var(--tq-gold-bright) 0%, var(--tq-gold-deep) 50%, var(--tq-brass) 100%)",
      WebkitBackgroundClip: "text",
      WebkitTextFillColor: "transparent",
      backgroundClip: "text"
    }
  }, "Choose Your Companion"), /*#__PURE__*/React.createElement(Sparkles, {
    style: {
      color: "var(--tq-gold-deep)",
      fontSize: '1rem'
    }
  })), /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] italic",
    style: {
      color: "var(--tq-gold)",
      fontFamily: "'Crimson Pro', serif"
    }
  }, "Three companions await. Only one may bond with you.")), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-3 gap-2 px-3 pb-3"
  }, ceremonyStarters.map(function (typeKey) {
    return /*#__PURE__*/React.createElement(StarterCard, {
      key: typeKey,
      typeKey: typeKey,
      selected: chosenType === typeKey,
      onSelect: function onSelect() {
        haptic(20);
        setChosenType(typeKey);
      }
    });
  })), chosenType && /*#__PURE__*/React.createElement("div", {
    className: "mx-3 mb-3 px-3 py-2.5",
    style: {
      background: "linear-gradient(135deg, ".concat(COLOR_DATA[PET_TYPES[chosenType].color].symbol, "10, transparent)"),
      border: "1px solid ".concat(COLOR_DATA[PET_TYPES[chosenType].color].symbol, "33"),
      borderRadius: "2px",
      transition: 'all 0.3s ease'
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] tracking-[0.2em] uppercase mb-1",
    style: {
      fontFamily: "'Cinzel', serif",
      color: COLOR_DATA[PET_TYPES[chosenType].color].symbol,
      fontWeight: 600
    }
  }, PET_TYPES[chosenType].emoji, " ", PET_TYPES[chosenType].name), /*#__PURE__*/React.createElement("p", {
    className: "text-sm italic",
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-ink)",
      lineHeight: 1.45
    }
  }, ((_COLOR_LORE$PET_TYPES = COLOR_LORE[PET_TYPES[chosenType].color]) === null || _COLOR_LORE$PET_TYPES === void 0 ? void 0 : _COLOR_LORE$PET_TYPES.text) || PET_TYPES[chosenType].flavor)), /*#__PURE__*/React.createElement("div", {
    className: "flex gap-2 px-3 pb-4"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      haptic(15);
      setCeremonyStarters(pickCeremonyStarters());
      setChosenType(null);
    },
    className: "flex items-center justify-center gap-1.5 px-3 py-2.5 text-[10px] tracking-[0.2em] uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-dim)",
      border: "1px solid rgba(154,135,101,0.35)",
      borderRadius: "2px",
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(Shuffle, {
    style: {
      fontSize: '0.7rem'
    }
  }), " New Three"), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      setHatchingOpen(false);
      setChosenType(null);
      setCeremonyStarters([]);
    },
    className: "px-3 py-2.5 text-[10px] tracking-[0.2em] uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      border: "1px solid rgba(201,169,97,0.4)",
      borderRadius: "2px"
    }
  }, "Wait"), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return chosenType && hatchPet(chosenType);
    },
    disabled: !chosenType,
    className: "flex-[2] py-2.5 text-[11px] tracking-[0.3em] uppercase active:scale-95 transition-transform",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 600,
      color: chosenType ? "var(--tq-surface)" : "var(--tq-ink-faint)",
      background: chosenType ? "linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))" : "rgba(154,135,101,0.1)",
      border: "1px solid ".concat(chosenType ? "var(--tq-gold)" : "rgba(154,135,101,0.2)"),
      borderRadius: "2px",
      boxShadow: chosenType ? "0 0 16px rgba(212,184,122,0.3)" : 'none'
    }
  }, "Awaken")))), petRenameOpen && /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 z-[130] flex items-center justify-center p-4",
    style: {
      background: "rgba(5, 3, 10, 0.96)",
      backdropFilter: "blur(10px) saturate(120%)",
      WebkitBackdropFilter: "blur(10px) saturate(120%)"
    },
    onClick: function onClick() {
      setPetRenameOpen(false);
      setPetNameInput('');
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "relative w-full max-w-sm",
    onClick: function onClick(e) {
      return e.stopPropagation();
    },
    style: {
      background: "radial-gradient(ellipse at top, var(--tq-surface) 0%, var(--tq-surface-deep) 100%)",
      border: "1px solid rgba(201, 169, 97, 0.4)",
      borderRadius: "3px",
      boxShadow: "0 0 40px rgba(0, 0, 0, 0.8)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "px-5 py-5"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "text-xs tracking-[0.3em] uppercase mb-3",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold-deep)",
      fontWeight: 600
    }
  }, "Name your companion"), /*#__PURE__*/React.createElement("input", {
    type: "text",
    value: petNameInput,
    onChange: function onChange(e) {
      return setPetNameInput(e.target.value);
    },
    onKeyDown: function onKeyDown(e) {
      if (e.key === 'Enter') renamePet();
    },
    autoFocus: true,
    maxLength: 20,
    placeholder: "A name...",
    className: "w-full px-3 py-2.5 text-base outline-none mb-3",
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-ink)",
      background: "rgba(20, 14, 8, 0.6)",
      border: "1px solid rgba(201, 169, 97, 0.3)",
      borderRadius: "2px"
    }
  }), pet && function () {
    var names = PET_NAMES_BY_COLOR[pet.core] || PET_NAMES_BY_COLOR.G;
    // Shuffle and take 6
    var suggestions = _toConsumableArray(names).sort(function () {
      return Math.random() - 0.5;
    }).slice(0, 6);
    return /*#__PURE__*/React.createElement("div", {
      className: "mb-3"
    }, /*#__PURE__*/React.createElement("p", {
      className: "text-[9px] tracking-[0.2em] uppercase mb-1.5",
      style: {
        fontFamily: "'Cinzel', serif",
        color: "var(--tq-ink-mid)"
      }
    }, "Suggestions"), /*#__PURE__*/React.createElement("div", {
      className: "flex flex-wrap gap-1.5"
    }, suggestions.map(function (name) {
      return /*#__PURE__*/React.createElement("button", {
        key: name,
        onClick: function onClick() {
          haptic(15);
          setPetNameInput(name);
        },
        className: "px-2.5 py-1 text-[10px] tracking-[0.05em] active:scale-95",
        style: {
          fontFamily: "'Crimson Pro', serif",
          color: "var(--tq-gold)",
          background: "rgba(201, 169, 97, 0.08)",
          border: "1px solid rgba(201, 169, 97, 0.25)",
          borderRadius: "2px"
        }
      }, name);
    })));
  }(), /*#__PURE__*/React.createElement("div", {
    className: "flex gap-2"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      setPetRenameOpen(false);
      setPetNameInput('');
    },
    className: "flex-1 py-2 text-[10px] tracking-widest uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      border: "1px solid rgba(201, 169, 97, 0.4)",
      borderRadius: "2px"
    }
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    onClick: renamePet,
    disabled: !petNameInput.trim(),
    className: "flex-1 py-2 text-[10px] tracking-widest uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 600,
      color: !petNameInput.trim() ? "var(--tq-ink-faint)" : "var(--tq-surface)",
      background: !petNameInput.trim() ? "rgba(154, 135, 101, 0.1)" : "linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))",
      border: "1px solid ".concat(!petNameInput.trim() ? "rgba(154, 135, 101, 0.2)" : "var(--tq-gold)"),
      borderRadius: "2px"
    }
  }, "Save"))))), petResetConfirmOpen && /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 z-[130] flex items-center justify-center p-4",
    style: {
      background: "rgba(5, 3, 10, 0.96)",
      backdropFilter: "blur(10px) saturate(120%)",
      WebkitBackdropFilter: "blur(10px) saturate(120%)"
    },
    onClick: function onClick() {
      return setPetResetConfirmOpen(false);
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "relative w-full max-w-sm",
    onClick: function onClick(e) {
      return e.stopPropagation();
    },
    style: {
      background: "radial-gradient(ellipse at top, var(--tq-surface) 0%, var(--tq-surface-deep) 100%)",
      border: "1px solid rgba(160, 48, 44, 0.5)",
      borderRadius: "3px",
      boxShadow: "0 0 40px rgba(0, 0, 0, 0.8), 0 0 30px rgba(160, 48, 44, 0.15)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "px-5 py-5 text-center"
  }, /*#__PURE__*/React.createElement(AlertTriangle, {
    style: {
      color: "var(--tq-danger)",
      fontSize: '2rem',
      margin: '0 auto 0.75rem'
    }
  }), /*#__PURE__*/React.createElement("h2", {
    className: "text-sm tracking-[0.25em] uppercase mb-2",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-danger)",
      fontWeight: 600
    }
  }, "Release your companion?"), /*#__PURE__*/React.createElement("p", {
    className: "text-sm italic mb-1 px-2",
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-gold)",
      lineHeight: 1.5
    }
  }, "Your companion will return to the aether. The egg may be found again."), /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] italic mt-1 mb-5",
    style: {
      color: "var(--tq-ink-mid)"
    }
  }, "This cannot be undone."), /*#__PURE__*/React.createElement("div", {
    className: "flex gap-2"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      haptic(15);
      setPetResetConfirmOpen(false);
    },
    className: "flex-1 py-2.5 text-[10px] tracking-widest uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      border: "1px solid rgba(201, 169, 97, 0.4)",
      borderRadius: "2px"
    }
  }, "Keep"), /*#__PURE__*/React.createElement("button", {
    onClick: resetPet,
    className: "flex-1 py-2.5 text-[10px] tracking-widest uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 600,
      color: "#fff",
      background: "linear-gradient(180deg, #c0453f, #8a2d29)",
      border: "1px solid var(--tq-danger-deep)",
      borderRadius: "2px"
    }
  }, "Release"))))), zoomImage && function () {
    var idx = zoomImage.battlefieldIndex >= 0 ? zoomImage.battlefieldIndex : -1;
    var canNav = idx >= 0 && battlefield.length > 1;
    var token = zoomImage.tokenId ? battlefield.find(function (t) {
      return t.id === zoomImage.tokenId;
    }) : null;
    var hasPT = token && token.power !== null && token.toughness !== null;
    var pMod = token ? token.powerMod || 0 : 0;
    var tMod = token ? token.toughnessMod || 0 : 0;
    var hasMod = pMod !== 0 || tMod !== 0;
    var basePwr = hasPT ? parseInt(token.power, 10) : 0;
    var baseTgh = hasPT ? parseInt(token.toughness, 10) : 0;
    var curP = hasPT ? isNaN(basePwr) ? token.power : basePwr + pMod : null;
    var curT = hasPT ? isNaN(baseTgh) ? token.toughness : baseTgh + tMod : null;
    var fmt = function fmt(n) {
      return n > 0 ? "+".concat(n) : "".concat(n);
    };
    var goTo = function goTo(newIdx) {
      var t = battlefield[newIdx];
      if (!t) return;
      haptic(15);
      setZoomImage({
        url: t.normalImage || t.smallImage,
        tokenId: t.id,
        battlefieldIndex: newIdx
      });
    };

    // Swipe detection refs (stored on the modal div via data attrs)
    var touchStartX = {
      current: null
    };
    return /*#__PURE__*/React.createElement("div", {
      className: "fixed inset-0 flex flex-col items-center justify-center",
      style: {
        zIndex: 200,
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: "#000",
        backgroundImage: "radial-gradient(ellipse at center, rgba(20, 14, 8, 0.95) 0%, rgba(0, 0, 0, 1) 70%)",
        backdropFilter: "blur(12px) saturate(110%)",
        WebkitBackdropFilter: "blur(12px) saturate(110%)",
        padding: "1rem",
        boxSizing: "border-box",
        overflow: "hidden"
      },
      onClick: function onClick() {
        return setZoomImage(null);
      },
      onTouchStart: function onTouchStart(e) {
        touchStartX.current = e.touches[0].clientX;
      },
      onTouchEnd: function onTouchEnd(e) {
        if (touchStartX.current === null || !canNav) return;
        var dx = touchStartX.current - e.changedTouches[0].clientX;
        touchStartX.current = null;
        if (Math.abs(dx) < 50) return; // too small
        if (dx > 0 && idx < battlefield.length - 1) goTo(idx + 1); // swipe left -> next
        else if (dx < 0 && idx > 0) goTo(idx - 1); // swipe right -> prev
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: function onClick(e) {
        e.stopPropagation();
        setZoomImage(null);
      },
      className: "absolute top-4 right-4 w-10 h-10 flex items-center justify-center active:scale-90 z-10",
      style: {
        background: "rgba(10, 6, 4, 0.9)",
        border: "1px solid rgba(201, 169, 97, 0.4)",
        borderRadius: "50%",
        color: "var(--tq-gold)"
      },
      "aria-label": "Close zoom"
    }, /*#__PURE__*/React.createElement(XIcon, {
      style: {
        fontSize: '1.25rem'
      }
    })), canNav && /*#__PURE__*/React.createElement("div", {
      className: "absolute top-4 left-4 flex items-center gap-1 z-10"
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        color: "var(--tq-gold)",
        fontSize: "0.75rem"
      }
    }, idx + 1, "/", battlefield.length)), canNav && idx > 0 && /*#__PURE__*/React.createElement("button", {
      onClick: function onClick(e) {
        e.stopPropagation();
        goTo(idx - 1);
      },
      className: "absolute left-2 top-1/2 -translate-y-1/2 w-10 h-16 flex items-center justify-center active:scale-90 z-10",
      style: {
        background: "rgba(10, 6, 4, 0.7)",
        border: "1px solid rgba(201, 169, 97, 0.3)",
        borderRadius: "2px",
        color: "var(--tq-gold)"
      },
      "aria-label": "Previous token"
    }, /*#__PURE__*/React.createElement(ChevronLeft, {
      style: {
        fontSize: '1.5rem'
      }
    })), canNav && idx < battlefield.length - 1 && /*#__PURE__*/React.createElement("button", {
      onClick: function onClick(e) {
        e.stopPropagation();
        goTo(idx + 1);
      },
      className: "absolute right-2 top-1/2 -translate-y-1/2 w-10 h-16 flex items-center justify-center active:scale-90 z-10",
      style: {
        background: "rgba(10, 6, 4, 0.7)",
        border: "1px solid rgba(201, 169, 97, 0.3)",
        borderRadius: "2px",
        color: "var(--tq-gold)"
      },
      "aria-label": "Next token"
    }, /*#__PURE__*/React.createElement(ChevronRight, {
      style: {
        fontSize: '1.5rem'
      }
    })), canNav && /*#__PURE__*/React.createElement("p", {
      className: "absolute bottom-4 left-1/2 -translate-x-1/2 text-[9px] italic z-10",
      style: {
        color: "rgba(201,169,97,0.4)",
        fontFamily: "'Crimson Pro', serif",
        whiteSpace: 'nowrap'
      }
    }, "swipe left or right to navigate"), /*#__PURE__*/React.createElement("img", {
      src: zoomImage.url,
      alt: token ? token.name : "Card",
      className: "max-w-full",
      style: {
        maxHeight: hasPT ? '68vh' : '82vh',
        borderRadius: "4.75% / 3.5%",
        boxShadow: "0 0 60px rgba(212, 184, 122, 0.25), 0 20px 40px rgba(0,0,0,0.8)"
      },
      onClick: function onClick(e) {
        return e.stopPropagation();
      }
    }), hasPT && token && /*#__PURE__*/React.createElement("div", {
      className: "flex items-center justify-center mt-3",
      style: {
        width: '100%',
        paddingLeft: '12px',
        paddingRight: '12px',
        boxSizing: 'border-box'
      },
      onClick: function onClick(e) {
        return e.stopPropagation();
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "flex items-center gap-1.5 px-2 py-2",
      style: {
        background: "rgba(10, 6, 4, 0.92)",
        border: "1px solid rgba(201, 169, 97, 0.35)",
        borderRadius: "3px",
        boxShadow: "0 4px 20px rgba(0,0,0,0.6)",
        width: '100%'
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "flex items-center gap-1 flex-1"
    }, /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustPT(token.id, 'power', -1);
      },
      className: "flex-shrink-0 flex items-center justify-center active:scale-90",
      style: {
        width: '32px',
        height: '32px',
        background: "rgba(232,148,122,0.15)",
        border: "1px solid rgba(232,148,122,0.5)",
        borderRadius: "2px",
        color: "var(--tq-danger)"
      }
    }, /*#__PURE__*/React.createElement(Minus, {
      style: {
        fontSize: '0.875rem'
      }
    })), /*#__PURE__*/React.createElement("div", {
      className: "text-center flex-1"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'Cinzel', serif",
        color: "var(--tq-ink-dim)",
        fontSize: "0.5rem",
        letterSpacing: "0.15em",
        textTransform: "uppercase"
      }
    }, "Power"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        color: pMod !== 0 ? "var(--tq-gold-bright)" : "var(--tq-gold)",
        fontSize: "1.2rem",
        fontWeight: 700,
        lineHeight: 1.1
      }
    }, curP), pMod !== 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        color: "var(--tq-life)",
        fontSize: "0.55rem"
      }
    }, fmt(pMod))), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustPT(token.id, 'power', 1);
      },
      className: "flex-shrink-0 flex items-center justify-center active:scale-90",
      style: {
        width: '32px',
        height: '32px',
        background: "rgba(232,148,122,0.15)",
        border: "1px solid rgba(232,148,122,0.5)",
        borderRadius: "2px",
        color: "var(--tq-danger)"
      }
    }, /*#__PURE__*/React.createElement(Plus, {
      style: {
        fontSize: '0.875rem'
      }
    }))), /*#__PURE__*/React.createElement("div", {
      className: "flex-shrink-0 text-center px-2",
      style: {
        borderLeft: "1px solid rgba(201,169,97,0.2)",
        borderRight: "1px solid rgba(201,169,97,0.2)",
        minWidth: '3.5rem'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        color: "var(--tq-gold-deep)",
        fontSize: "1.4rem",
        fontWeight: 700,
        lineHeight: 1
      }
    }, curP, "/", curT), hasMod && /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return resetPT(token.id);
      },
      className: "flex items-center justify-center gap-0.5 mt-1 active:scale-95 mx-auto",
      style: {
        fontFamily: "'Cinzel', serif",
        color: "var(--tq-ink-dim)",
        fontSize: "0.5rem",
        letterSpacing: "0.1em",
        textTransform: "uppercase",
        background: "transparent",
        border: "1px solid rgba(154,135,101,0.3)",
        borderRadius: "2px",
        padding: "1px 4px"
      }
    }, /*#__PURE__*/React.createElement(RotateCcw, {
      style: {
        fontSize: '0.45rem'
      }
    }), "reset")), /*#__PURE__*/React.createElement("div", {
      className: "flex items-center gap-1 flex-1"
    }, /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustPT(token.id, 'toughness', -1);
      },
      className: "flex-shrink-0 flex items-center justify-center active:scale-90",
      style: {
        width: '32px',
        height: '32px',
        background: "rgba(159,199,230,0.15)",
        border: "1px solid rgba(159,199,230,0.5)",
        borderRadius: "2px",
        color: "var(--tq-info)"
      }
    }, /*#__PURE__*/React.createElement(Minus, {
      style: {
        fontSize: '0.875rem'
      }
    })), /*#__PURE__*/React.createElement("div", {
      className: "text-center flex-1"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'Cinzel', serif",
        color: "var(--tq-ink-dim)",
        fontSize: "0.5rem",
        letterSpacing: "0.15em",
        textTransform: "uppercase"
      }
    }, "Tough"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        color: tMod !== 0 ? "var(--tq-gold-bright)" : "var(--tq-gold)",
        fontSize: "1.2rem",
        fontWeight: 700,
        lineHeight: 1.1
      }
    }, curT), tMod !== 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        color: "var(--tq-info)",
        fontSize: "0.55rem"
      }
    }, fmt(tMod))), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return adjustPT(token.id, 'toughness', 1);
      },
      className: "flex-shrink-0 flex items-center justify-center active:scale-90",
      style: {
        width: '32px',
        height: '32px',
        background: "rgba(159,199,230,0.15)",
        border: "1px solid rgba(159,199,230,0.5)",
        borderRadius: "2px",
        color: "var(--tq-info)"
      }
    }, /*#__PURE__*/React.createElement(Plus, {
      style: {
        fontSize: '0.875rem'
      }
    }))))));
  }(), oracleFor && function () {
    var target = battlefield.find(function (t) {
      return t.id === oracleFor;
    });
    if (!target) return null;
    return /*#__PURE__*/React.createElement("div", {
      className: "fixed inset-0 z-[105] flex items-center justify-center p-4",
      style: {
        background: "rgba(5, 3, 10, 0.96)",
        backdropFilter: "blur(10px) saturate(120%)",
        WebkitBackdropFilter: "blur(10px) saturate(120%)"
      },
      onClick: function onClick() {
        setOracleFor(null);
        setOracleText("");
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "relative w-full max-w-md",
      onClick: function onClick(e) {
        return e.stopPropagation();
      },
      style: {
        background: "radial-gradient(ellipse at top, var(--tq-surface) 0%, var(--tq-surface-deep) 100%)",
        border: "1px solid rgba(201, 169, 97, 0.4)",
        borderRadius: "3px",
        boxShadow: "0 0 40px rgba(0, 0, 0, 0.8)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "flex items-center justify-between px-4 py-3",
      style: {
        borderBottom: "1px solid rgba(201, 169, 97, 0.2)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "min-w-0 flex items-center gap-2"
    }, /*#__PURE__*/React.createElement(BookOpen, {
      style: {
        color: "var(--tq-gold)",
        fontSize: '1rem'
      }
    }), /*#__PURE__*/React.createElement("h2", {
      className: "text-sm truncate",
      style: {
        fontFamily: "'Cinzel', serif",
        color: "var(--tq-ink)",
        fontWeight: 600
      }
    }, target.name)), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        setOracleFor(null);
        setOracleText("");
      },
      className: "w-8 h-8 flex items-center justify-center active:scale-90",
      style: {
        color: "var(--tq-ink-dim)"
      },
      "aria-label": "Close"
    }, /*#__PURE__*/React.createElement(XIcon, {
      style: {
        fontSize: '1rem'
      }
    }))), /*#__PURE__*/React.createElement("div", {
      className: "px-4 py-4 max-h-[60vh] overflow-y-auto"
    }, target.type_line && /*#__PURE__*/React.createElement("p", {
      className: "text-[10px] italic mb-3",
      style: {
        color: "var(--tq-ink-dim)",
        fontFamily: "'Crimson Pro', serif"
      }
    }, target.type_line), oracleLoading ? /*#__PURE__*/React.createElement("div", {
      className: "flex justify-center py-6"
    }, /*#__PURE__*/React.createElement(Loader2, {
      className: "animate-spin",
      style: {
        color: "var(--tq-gold)",
        fontSize: '1.25rem'
      }
    })) : /*#__PURE__*/React.createElement("div", {
      className: "text-sm whitespace-pre-line tq-oracle-text",
      style: {
        color: "var(--tq-ink)",
        fontFamily: "'Crimson Pro', serif",
        lineHeight: 1.5
      },
      ref: function ref(el) {
        if (el && window.TQ && typeof window.TQ.renderOracleText === 'function') {
          window.TQ.renderOracleText(el, oracleText || "(No rules text)");
        }
      }
    }), target.power !== null && target.toughness !== null && /*#__PURE__*/React.createElement("p", {
      className: "mt-3 text-right",
      style: {
        fontFamily: "'JetBrains Mono', monospace",
        color: "var(--tq-gold)"
      }
    }, target.power, " / ", target.toughness))));
  }(), presetMenuOpen && /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 z-[105] flex items-start justify-center pt-12 p-4",
    style: {
      background: "rgba(5, 3, 10, 0.96)",
      backdropFilter: "blur(10px) saturate(120%)",
      WebkitBackdropFilter: "blur(10px) saturate(120%)"
    },
    onClick: function onClick() {
      return setPresetMenuOpen(false);
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "relative w-full max-w-md",
    onClick: function onClick(e) {
      return e.stopPropagation();
    },
    style: {
      background: "radial-gradient(ellipse at top, var(--tq-surface) 0%, var(--tq-surface-deep) 100%)",
      border: "1px solid rgba(201, 169, 97, 0.4)",
      borderRadius: "3px",
      boxShadow: "0 0 40px rgba(0, 0, 0, 0.8)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between px-4 py-3",
    style: {
      borderBottom: "1px solid rgba(201, 169, 97, 0.2)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2"
  }, /*#__PURE__*/React.createElement(Layers, {
    style: {
      color: "var(--tq-gold)",
      fontSize: '1rem'
    }
  }), /*#__PURE__*/React.createElement("h2", {
    className: "text-xs tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold-deep)",
      fontWeight: 600
    }
  }, "Deck Presets")), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return setPresetMenuOpen(false);
    },
    className: "w-8 h-8 flex items-center justify-center active:scale-90",
    style: {
      color: "var(--tq-ink-dim)"
    },
    "aria-label": "Close"
  }, /*#__PURE__*/React.createElement(XIcon, {
    style: {
      fontSize: '1rem'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "px-4 py-4 max-h-[60vh] overflow-y-auto"
  }, presets.length === 0 ? /*#__PURE__*/React.createElement("p", {
    className: "text-center italic text-sm py-6",
    style: {
      color: "var(--tq-ink-faint)"
    }
  }, "No presets saved.", /*#__PURE__*/React.createElement("br", null), "Build a battlefield, then save it as a preset for next game.") : /*#__PURE__*/React.createElement("div", {
    className: "flex flex-col gap-2"
  }, presets.map(function (p) {
    return /*#__PURE__*/React.createElement("div", {
      key: p.id,
      className: "flex items-center gap-2 px-3 py-2.5",
      style: {
        background: "rgba(20, 14, 8, 0.6)",
        border: "1px solid rgba(201, 169, 97, 0.25)",
        borderRadius: "2px"
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return loadPreset(p);
      },
      className: "flex-1 text-left active:scale-[0.98] transition-transform"
    }, /*#__PURE__*/React.createElement("h3", {
      style: {
        fontFamily: "'Cinzel', serif",
        color: "var(--tq-ink)",
        fontSize: "0.9rem",
        fontWeight: 600
      }
    }, p.name), /*#__PURE__*/React.createElement("p", {
      className: "text-[10px] mt-0.5",
      style: {
        color: "var(--tq-ink-dim)",
        fontFamily: "'Crimson Pro', serif"
      }
    }, p.tokens.length, " token type", p.tokens.length === 1 ? "" : "s")), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return deletePreset(p.id);
      },
      className: "w-8 h-8 flex items-center justify-center active:scale-90 flex-shrink-0",
      style: {
        border: "1px solid rgba(160, 48, 44, 0.4)",
        borderRadius: "2px",
        color: "var(--tq-danger)"
      },
      "aria-label": "Delete ".concat(p.name),
      title: "Delete preset"
    }, /*#__PURE__*/React.createElement(Trash2, {
      style: {
        fontSize: '0.85rem'
      }
    })));
  }))), /*#__PURE__*/React.createElement("div", {
    className: "px-4 pb-4"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      setPresetMenuOpen(false);
      setSavePresetOpen(true);
    },
    disabled: battlefield.length === 0,
    className: "w-full py-2.5 text-xs tracking-[0.3em] uppercase active:scale-95 transition-transform flex items-center justify-center gap-2",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 600,
      color: battlefield.length === 0 ? "var(--tq-ink-faint)" : "var(--tq-surface)",
      background: battlefield.length === 0 ? "rgba(154, 135, 101, 0.1)" : "linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))",
      border: "1px solid ".concat(battlefield.length === 0 ? "rgba(154, 135, 101, 0.2)" : "var(--tq-gold)"),
      borderRadius: "2px"
    }
  }, /*#__PURE__*/React.createElement(Save, {
    style: {
      fontSize: '0.875rem'
    }
  }), "Save current as preset")))), savePresetOpen && /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 z-[105] flex items-center justify-center p-4",
    style: {
      background: "rgba(5, 3, 10, 0.96)",
      backdropFilter: "blur(10px) saturate(120%)",
      WebkitBackdropFilter: "blur(10px) saturate(120%)"
    },
    onClick: function onClick() {
      setSavePresetOpen(false);
      setSavePresetName("");
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "relative w-full max-w-sm",
    onClick: function onClick(e) {
      return e.stopPropagation();
    },
    style: {
      background: "radial-gradient(ellipse at top, var(--tq-surface) 0%, var(--tq-surface-deep) 100%)",
      border: "1px solid rgba(201, 169, 97, 0.4)",
      borderRadius: "3px",
      boxShadow: "0 0 40px rgba(0, 0, 0, 0.8)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "px-5 py-5"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2 mb-3"
  }, /*#__PURE__*/React.createElement(Save, {
    style: {
      color: "var(--tq-gold)",
      fontSize: '1rem'
    }
  }), /*#__PURE__*/React.createElement("h2", {
    className: "text-xs tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold-deep)",
      fontWeight: 600
    }
  }, "Save Preset")), /*#__PURE__*/React.createElement("p", {
    className: "text-xs mb-3",
    style: {
      color: "var(--tq-ink-dim)",
      fontFamily: "'Crimson Pro', serif"
    }
  }, "Saves ", battlefield.length, " token type", battlefield.length === 1 ? "" : "s", " as a reusable preset."), /*#__PURE__*/React.createElement("input", {
    type: "text",
    value: savePresetName,
    onChange: function onChange(e) {
      return setSavePresetName(e.target.value);
    },
    onKeyDown: function onKeyDown(e) {
      if (e.key === 'Enter') savePreset(savePresetName);
    },
    autoFocus: true,
    placeholder: "e.g. Halana & Alena",
    className: "w-full px-3 py-2.5 text-base outline-none mb-3",
    style: {
      fontFamily: "'Crimson Pro', serif",
      color: "var(--tq-ink)",
      background: "rgba(20, 14, 8, 0.6)",
      border: "1px solid rgba(201, 169, 97, 0.3)",
      borderRadius: "2px"
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "flex gap-2"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      setSavePresetOpen(false);
      setSavePresetName("");
    },
    className: "flex-1 py-2 text-[10px] tracking-widest uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)",
      border: "1px solid rgba(201, 169, 97, 0.4)",
      borderRadius: "2px"
    }
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return savePreset(savePresetName);
    },
    disabled: !savePresetName.trim(),
    className: "flex-1 py-2 text-[10px] tracking-widest uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      fontWeight: 600,
      color: !savePresetName.trim() ? "var(--tq-ink-faint)" : "var(--tq-surface)",
      background: !savePresetName.trim() ? "rgba(154, 135, 101, 0.1)" : "linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))",
      border: "1px solid ".concat(!savePresetName.trim() ? "rgba(154, 135, 101, 0.2)" : "var(--tq-gold)"),
      borderRadius: "2px"
    }
  }, "Save"))))), settingsOpen && /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 z-[110] flex items-center justify-center p-4",
    style: {
      background: "rgba(5, 3, 10, 0.97)",
      backdropFilter: "blur(12px) saturate(120%)",
      WebkitBackdropFilter: "blur(12px) saturate(120%)"
    },
    onClick: function onClick() {
      return setSettingsOpen(false);
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "relative w-full max-w-sm",
    onClick: function onClick(e) {
      return e.stopPropagation();
    },
    style: {
      background: "linear-gradient(180deg, rgba(26, 17, 10, 0.98), rgba(10, 6, 4, 0.98))",
      border: "1px solid rgba(212, 184, 122, 0.4)",
      borderRadius: "4px",
      boxShadow: "0 20px 60px rgba(0,0,0,0.8), 0 0 40px rgba(212, 184, 122, 0.1)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between px-5 py-4",
    style: {
      borderBottom: "1px solid rgba(212, 184, 122, 0.18)"
    }
  }, /*#__PURE__*/React.createElement("h2", {
    className: "text-base tracking-[0.3em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold-deep)",
      fontWeight: 600
    }
  }, "Settings"), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      return setSettingsOpen(false);
    },
    className: "text-[var(--tq-ink-dim)] text-xl active:scale-90",
    style: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer'
    },
    "aria-label": "Close"
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "px-5 py-4 space-y-5"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] tracking-[0.25em] uppercase mb-2",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-warm)",
      fontWeight: 600
    }
  }, "Haptic Feedback"), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-4 gap-1.5"
  }, ['off', 'light', 'normal', 'strong'].map(function (opt) {
    return /*#__PURE__*/React.createElement("button", {
      key: opt,
      onClick: function onClick() {
        setSettings(function (s) {
          return _objectSpread(_objectSpread({}, s), {}, {
            hapticIntensity: opt
          });
        });
        haptic(20);
      },
      className: "py-2 text-[9px] tracking-[0.15em] uppercase active:scale-95",
      style: {
        fontFamily: "'Cinzel', serif",
        fontWeight: 600,
        color: settings.hapticIntensity === opt ? "var(--tq-surface-deep)" : "var(--tq-gold)",
        background: settings.hapticIntensity === opt ? "linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))" : "transparent",
        border: "1px solid ".concat(settings.hapticIntensity === opt ? "var(--tq-gold)" : "rgba(201, 169, 97, 0.3)"),
        borderRadius: "2px"
      }
    }, opt);
  }))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    className: "text-[10px] tracking-[0.25em] uppercase mb-2",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-ink-warm)",
      fontWeight: 600
    }
  }, "Text Size"), /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-3 gap-1.5"
  }, [['small', 'S'], ['normal', 'M'], ['large', 'L']].map(function (_ref30) {
    var _ref31 = _slicedToArray(_ref30, 2),
      opt = _ref31[0],
      label = _ref31[1];
    return /*#__PURE__*/React.createElement("button", {
      key: opt,
      onClick: function onClick() {
        setSettings(function (s) {
          return _objectSpread(_objectSpread({}, s), {}, {
            fontSize: opt
          });
        });
        haptic(15);
      },
      className: "py-2 active:scale-95",
      style: {
        fontFamily: "'Cinzel', serif",
        fontWeight: 600,
        fontSize: opt === 'small' ? '0.7rem' : opt === 'large' ? '0.9rem' : '0.8rem',
        color: settings.fontSize === opt ? "var(--tq-surface-deep)" : "var(--tq-gold)",
        background: settings.fontSize === opt ? "linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))" : "transparent",
        border: "1px solid ".concat(settings.fontSize === opt ? "var(--tq-gold)" : "rgba(201, 169, 97, 0.3)"),
        borderRadius: "2px"
      }
    }, label);
  }))), /*#__PURE__*/React.createElement("div", {
    className: "space-y-2"
  }, /*#__PURE__*/React.createElement("label", {
    className: "flex items-center justify-between py-2 cursor-pointer"
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-[11px] tracking-[0.15em] uppercase",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-gold)"
    }
  }, "Scroll-to-top button"), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      setSettings(function (s) {
        return _objectSpread(_objectSpread({}, s), {}, {
          showScrollTop: !s.showScrollTop
        });
      });
      haptic(15);
    },
    style: {
      width: 40,
      height: 22,
      borderRadius: 11,
      background: settings.showScrollTop ? "var(--tq-gold)" : "rgba(154,135,101,0.2)",
      border: "1px solid rgba(201,169,97,0.3)",
      position: 'relative',
      cursor: 'pointer',
      transition: 'background 0.2s'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 2,
      left: settings.showScrollTop ? 20 : 2,
      width: 16,
      height: 16,
      borderRadius: '50%',
      background: settings.showScrollTop ? "var(--tq-surface-deep)" : "var(--tq-ink-dim)",
      transition: 'left 0.2s'
    }
  })))), /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      storage.set('onboardingSeen', false);
      setOnboardingStep(0);
      setSettingsOpen(false);
      haptic(20);
    },
    className: "w-full py-2.5 text-[10px] tracking-[0.2em] uppercase active:scale-95",
    style: {
      fontFamily: "'Cinzel', serif",
      color: "var(--tq-info)",
      background: "rgba(63,100,140,0.1)",
      border: "1px solid rgba(63,100,140,0.35)",
      borderRadius: "2px"
    }
  }, "Show Tour Again")))), showScrollTop && settings.showScrollTop && /*#__PURE__*/React.createElement("button", {
    onClick: function onClick() {
      haptic(15);
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    },
    className: "fixed z-[55] active:scale-90 transition-all",
    style: {
      bottom: 'calc(5.5rem + env(safe-area-inset-bottom))',
      right: '1rem',
      width: 44,
      height: 44,
      borderRadius: '50%',
      background: "linear-gradient(180deg, rgba(26, 17, 10, 0.95), rgba(10, 6, 4, 0.95))",
      border: "1px solid rgba(212, 184, 122, 0.5)",
      color: "var(--tq-gold-deep)",
      boxShadow: "0 6px 20px rgba(0,0,0,0.6), 0 0 12px rgba(212, 184, 122, 0.15)",
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      animation: 'fabIn 0.25s ease-out'
    },
    "aria-label": "Scroll to top"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '1.2rem',
      lineHeight: 1,
      transform: 'translateY(-1px)'
    }
  }, "\u2191")), onboardingStep >= 0 && onboardingStep <= 3 && /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 flex items-center justify-center px-4",
    style: {
      zIndex: 9999,
      background: "rgba(5, 3, 10, 0.92)",
      backdropFilter: "blur(8px)",
      WebkitBackdropFilter: "blur(8px)",
      pointerEvents: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-full max-w-md px-5 py-5",
    style: {
      background: "linear-gradient(180deg, rgba(26, 17, 10, 0.99), rgba(10, 6, 4, 0.99))",
      border: "1px solid rgba(212, 184, 122, 0.5)",
      borderRadius: "4px",
      boxShadow: "0 8px 40px rgba(0,0,0,0.8), 0 0 32px rgba(212, 184, 122, 0.18)",
      animation: 'sanctumIn 0.3s ease-out',
      pointerEvents: 'auto'
    }
  }, function () {
    var steps = [{
      title: 'Welcome to Token Queen',
      body: 'Your companion for Magic: the Gathering — tokens, life totals, and a hidden chamber for your companion. Let me show you around.'
    }, {
      title: 'The Battlefield',
      body: 'Search Scryfall for any token, or tap the counter chips to add Energy, Poison, Experience and more. Tap a card to set its count, long-press to zoom.'
    }, {
      title: 'Life & Tools',
      body: 'Track life totals up to 4 players with commander damage, poison, energy. Tools has turn phases, dice, monarch, mana pool, keyword index.'
    }, {
      title: 'The Sanctum',
      body: 'Tap the title 7 times to find the secret chamber. Your companion lives there — feed it, play with it, and watch it grow.'
    }];
    var step = steps[onboardingStep];
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: "flex items-center gap-1 mb-3"
    }, [0, 1, 2, 3].map(function (i) {
      return /*#__PURE__*/React.createElement("span", {
        key: i,
        style: {
          width: i === onboardingStep ? 16 : 6,
          height: 4,
          borderRadius: 2,
          background: i <= onboardingStep ? 'var(--tq-gold-deep)' : 'rgba(201,169,97,0.2)',
          transition: 'all 0.3s'
        }
      });
    })), /*#__PURE__*/React.createElement("h3", {
      className: "text-base tracking-[0.2em] uppercase mb-2",
      style: {
        fontFamily: "'Cinzel', serif",
        color: 'var(--tq-gold-bright)',
        fontWeight: 600
      }
    }, step.title), /*#__PURE__*/React.createElement("p", {
      className: "text-sm leading-relaxed mb-4",
      style: {
        fontFamily: "'Crimson Pro', serif",
        color: 'var(--tq-gold-deep)'
      }
    }, step.body), /*#__PURE__*/React.createElement("div", {
      className: "flex gap-2"
    }, /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        haptic(15);
        setOnboardingStep(-1);
      },
      className: "flex-1 py-2.5 text-[10px] tracking-[0.2em] uppercase active:scale-95",
      style: {
        fontFamily: "'Cinzel', serif",
        color: 'var(--tq-ink-dim)',
        background: 'transparent',
        border: '1px solid rgba(154,135,101,0.3)',
        borderRadius: '2px'
      }
    }, "Skip"), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        haptic(20);
        setOnboardingStep(onboardingStep === 3 ? -1 : onboardingStep + 1);
      },
      className: "flex-[2] py-2.5 text-[10px] tracking-[0.2em] uppercase active:scale-95",
      style: {
        fontFamily: "'Cinzel', serif",
        fontWeight: 700,
        color: 'var(--tq-surface-deep)',
        background: 'linear-gradient(180deg, var(--tq-gold-bright), var(--tq-gold))',
        border: '1px solid var(--tq-gold)',
        borderRadius: '2px',
        boxShadow: '0 2px 8px rgba(201,169,97,0.3)'
      }
    }, onboardingStep === 3 ? 'Begin' : 'Next')));
  }())), toast && /*#__PURE__*/React.createElement("div", {
    className: "fixed left-1/2 -translate-x-1/2 z-[60] pointer-events-none px-5 py-2.5",
    style: {
      bottom: 'calc(5.5rem + env(safe-area-inset-bottom))',
      fontFamily: "'Cinzel', serif",
      fontSize: "0.72rem",
      letterSpacing: "0.22em",
      textTransform: "uppercase",
      fontWeight: 600,
      color: "var(--tq-gold-bright)",
      background: "linear-gradient(180deg, rgba(26, 17, 10, 0.98), rgba(10, 6, 4, 0.98))",
      border: "1px solid rgba(212, 184, 122, 0.5)",
      borderRadius: "3px",
      boxShadow: "0 8px 32px rgba(0, 0, 0, 0.6), 0 0 16px rgba(212, 184, 122, 0.15), inset 0 1px 0 rgba(245, 217, 143, 0.1)",
      animation: "toastIn 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)"
    }
  }, toast), cmdrDamageFor && function () {
    var target = players.find(function (p) {
      return p.id === cmdrDamageFor;
    });
    if (!target) return null;
    var dealers = players.filter(function (p) {
      return p.id !== cmdrDamageFor;
    });
    return /*#__PURE__*/React.createElement("div", {
      className: "fixed inset-0 z-[105] flex items-center justify-center p-4",
      style: {
        background: "rgba(5, 3, 10, 0.96)",
        backdropFilter: "blur(10px) saturate(120%)",
        WebkitBackdropFilter: "blur(10px) saturate(120%)"
      },
      onClick: function onClick() {
        return setCmdrDamageFor(null);
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "relative w-full max-w-md",
      onClick: function onClick(e) {
        return e.stopPropagation();
      },
      style: {
        background: "radial-gradient(ellipse at top, var(--tq-surface) 0%, var(--tq-surface-deep) 100%)",
        border: "1px solid ".concat(target.color, "66"),
        borderRadius: "3px",
        boxShadow: "0 0 40px rgba(0, 0, 0, 0.8), 0 0 30px ".concat(target.color, "20")
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "flex items-center justify-between px-4 py-3",
      style: {
        borderBottom: "1px solid ".concat(target.color, "33")
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "flex items-center gap-2 min-w-0"
    }, /*#__PURE__*/React.createElement(Crown, {
      style: {
        color: target.color,
        fontSize: '1rem'
      }
    }), /*#__PURE__*/React.createElement("div", {
      className: "min-w-0"
    }, /*#__PURE__*/React.createElement("h2", {
      className: "text-[9px] tracking-[0.3em] uppercase",
      style: {
        fontFamily: "'Cinzel', serif",
        color: "var(--tq-ink-dim)"
      }
    }, "Commander damage to"), /*#__PURE__*/React.createElement("p", {
      className: "text-sm truncate",
      style: {
        fontFamily: "'Cinzel', serif",
        color: target.color,
        fontWeight: 600
      }
    }, target.name))), /*#__PURE__*/React.createElement("button", {
      onClick: function onClick() {
        return setCmdrDamageFor(null);
      },
      className: "w-8 h-8 flex items-center justify-center active:scale-90 flex-shrink-0",
      style: {
        color: "var(--tq-ink-dim)"
      },
      "aria-label": "Close"
    }, /*#__PURE__*/React.createElement(XIcon, {
      style: {
        fontSize: '1rem'
      }
    }))), /*#__PURE__*/React.createElement("div", {
      className: "p-4 space-y-2.5"
    }, dealers.map(function (d) {
      var dmg = (commanderDamage[target.id] || {})[d.id] || 0;
      var lethal = dmg >= 21;
      return /*#__PURE__*/React.createElement("div", {
        key: d.id,
        className: "flex items-center gap-2",
        style: {
          background: "rgba(10, 6, 4, 0.4)",
          border: "1px solid ".concat(d.color, "33"),
          borderRadius: "2px"
        }
      }, /*#__PURE__*/React.createElement("div", {
        className: "flex items-center gap-2 flex-1 min-w-0 px-3 py-2"
      }, /*#__PURE__*/React.createElement(User, {
        style: {
          color: d.color,
          fontSize: '0.75rem',
          flexShrink: 0
        }
      }), /*#__PURE__*/React.createElement("span", {
        className: "text-xs truncate",
        style: {
          fontFamily: "'Cinzel', serif",
          color: "var(--tq-ink)",
          fontWeight: 500
        }
      }, d.name)), /*#__PURE__*/React.createElement("div", {
        className: "flex items-center"
      }, /*#__PURE__*/React.createElement("button", {
        onClick: function onClick() {
          return adjustCmdrDamage(target.id, d.id, -1);
        },
        className: "w-9 h-9 flex items-center justify-center active:scale-90",
        style: {
          color: "var(--tq-danger)",
          borderLeft: "1px solid ".concat(d.color, "33")
        },
        "aria-label": "Decrease"
      }, /*#__PURE__*/React.createElement(Minus, {
        style: {
          fontSize: '0.9rem'
        }
      })), /*#__PURE__*/React.createElement("span", {
        className: "w-10 text-center",
        style: {
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: "1.1rem",
          fontWeight: 700,
          color: lethal ? "#ff6b67" : dmg > 0 ? "var(--tq-gold-deep)" : "var(--tq-ink-mid)",
          textShadow: lethal ? "0 0 12px rgba(255, 107, 103, 0.6)" : "none"
        }
      }, dmg), /*#__PURE__*/React.createElement("button", {
        onClick: function onClick() {
          return adjustCmdrDamage(target.id, d.id, 1);
        },
        className: "w-9 h-9 flex items-center justify-center active:scale-90",
        style: {
          color: "var(--tq-life)",
          borderRight: "1px solid ".concat(d.color, "33")
        },
        "aria-label": "Increase"
      }, /*#__PURE__*/React.createElement(Plus, {
        style: {
          fontSize: '0.9rem'
        }
      }))));
    })), /*#__PURE__*/React.createElement("div", {
      className: "px-4 pb-4 pt-1"
    }, /*#__PURE__*/React.createElement("p", {
      className: "text-[9px] italic text-center",
      style: {
        color: "var(--tq-ink-faint)"
      }
    }, "Damage also reduces life. 21+ from one commander = lethal."))));
  }(), activeTab === 'vault' && /*#__PURE__*/React.createElement("div", {
    className: "min-h-screen tab-enter",
    key: "vault",
    style: {
      background: "var(--tq-bg)",
      paddingBottom: 80
    },
    ref: function ref(el) {
      if (el && window.TQ && typeof window.TQ.mountVault === 'function') {
        window.TQ.mountVault(el);
      }
    }
  }), activeTab === 'reference' && /*#__PURE__*/React.createElement("div", {
    className: "min-h-screen tab-enter",
    key: "reference",
    style: {
      background: "var(--tq-bg)",
      paddingBottom: 80
    },
    ref: function ref(el) {
      if (el && window.TQ && typeof window.TQ.mountReference === 'function') {
        window.TQ.mountReference(el);
      }
    }
  }), activeTab === 'odds' && /*#__PURE__*/React.createElement("div", {
    className: "min-h-screen tab-enter",
    key: "odds",
    style: {
      background: "var(--tq-bg)",
      paddingBottom: 80
    },
    ref: function ref(el) {
      if (el && window.TQ && typeof window.TQ.mountSimulator === 'function') {
        window.TQ.mountSimulator(el);
      }
    }
  }), /*#__PURE__*/React.createElement("nav", {
    className: "fixed bottom-0 left-0 right-0 z-40",
    style: {
      background: "linear-gradient(to top, rgba(5, 3, 4, 0.98) 0%, rgba(10, 6, 4, 0.95) 100%)",
      borderTop: "1px solid rgba(201, 169, 97, 0.25)",
      backdropFilter: "blur(12px)",
      WebkitBackdropFilter: "blur(12px)",
      paddingBottom: 'env(safe-area-inset-bottom)',
      boxShadow: "0 -4px 20px rgba(0, 0, 0, 0.4)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "max-w-6xl mx-auto flex"
  }, [{
    id: 'battlefield',
    label: 'Battlefield',
    Icon: Swords
  }, {
    id: 'life',
    label: 'Life',
    Icon: Heart
  }, {
    id: 'tools',
    label: 'Tools',
    Icon: Wrench
  }, {
    id: 'vault',
    label: 'Vault',
    Icon: Crown
  }, {
    id: 'reference',
    label: 'Rules',
    Icon: BookOpen
  }, {
    id: 'odds',
    label: 'Odds',
    Icon: Dice
  }].map(function (tab) {
    var isActive = activeTab === tab.id;
    return /*#__PURE__*/React.createElement("button", {
      key: tab.id,
      onClick: function onClick() {
        haptic(15);
        setActiveTab(tab.id);
        window.scrollTo({
          top: 0,
          behavior: 'smooth'
        });
      },
      className: "relative flex-1 flex flex-col items-center justify-center gap-1 py-2.5 active:scale-95 transition-all",
      style: {
        color: isActive ? "var(--tq-gold-bright)" : "#7a6a52",
        background: isActive ? "linear-gradient(180deg, rgba(212, 184, 122, 0.14) 0%, rgba(201, 169, 97, 0.04) 60%, transparent 100%)" : "transparent"
      },
      "aria-label": tab.label,
      "aria-pressed": isActive
    }, isActive && /*#__PURE__*/React.createElement("span", {
      "aria-hidden": true,
      style: {
        position: 'absolute',
        top: 0,
        left: '20%',
        right: '20%',
        height: 2,
        background: 'linear-gradient(90deg, transparent, var(--tq-gold-deep) 50%, transparent)',
        boxShadow: '0 0 8px rgba(212, 184, 122, 0.6)'
      }
    }), /*#__PURE__*/React.createElement(tab.Icon, {
      style: {
        fontSize: isActive ? '1.15rem' : '1.05rem',
        filter: isActive ? 'drop-shadow(0 0 8px rgba(245, 217, 143, 0.5))' : 'none',
        transition: 'all 0.2s ease'
      }
    }), /*#__PURE__*/React.createElement("span", {
      className: "tq-tab-label text-[9px] tracking-[0.18em] uppercase",
      style: {
        fontFamily: "'Cinzel', serif",
        fontWeight: isActive ? 700 : 500,
        letterSpacing: isActive ? '0.1em' : '0.08em',
        whiteSpace: 'nowrap',
        transition: 'letter-spacing 0.2s ease'
      }
    }, tab.label));
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'none'
    },
    id: "tq-styles-injected"
  }));
}

// Wait for DOM to be ready
if (typeof window !== 'undefined') {
  var startApp = function startApp() {
    try {
      var root = document.getElementById('root');
      if (!root) {
        console.error('Root element not found');
        alert('ERROR: Root element not found. App cannot start.');
        return;
      }

      // Hide any loading screens before mounting
      var hideLoading = function hideLoading() {
        ['initial-loading', 'splash-screen', 'loading-screen'].forEach(function (id) {
          var el = document.getElementById(id);
          if (el) {
            el.style.display = 'none';
          }
        });
        document.querySelectorAll('[class*="summoning"]').forEach(function (el) {
          el.style.display = 'none';
        });
      };
      hideLoading();
      ReactDOM.createRoot(root).render(/*#__PURE__*/React.createElement(TokenTracker, null));

      // Give it a moment to render, then check if still stuck
      setTimeout(function () {
        if (document.querySelector('[class*="summoning"]')) {
          console.error('Still showing summoning screen after mount!');
          hideLoading(); // Try again
        }
      }, 1000);
    } catch (error) {
      console.error('Failed to start app:', error);
      alert("CRITICAL ERROR: ".concat(error.message, "\n\nTap OK to see details"));

      // Show error to user
      document.body.innerHTML = "\n        <div style=\"display: flex; align-items: center; justify-content: center; height: 100vh; background: var(--tq-surface-deep); color: var(--tq-gold); font-family: sans-serif; padding: 20px; text-align: center;\">\n          <div>\n            <h1 style=\"margin-bottom: 10px; color: var(--tq-danger);\">App Failed to Start</h1>\n            <p style=\"color: var(--tq-gold); margin: 20px 0;\">".concat(error.message, "</p>\n            <pre style=\"background: var(--tq-surface); padding: 10px; border-radius: 4px; font-size: 11px; text-align: left; overflow: auto; max-width: 90vw;\">").concat(error.stack || 'No stack trace', "</pre>\n            <button onclick=\"location.reload()\" style=\"margin-top: 20px; padding: 10px 20px; background: var(--tq-gold); border: none; color: var(--tq-surface-deep); cursor: pointer; font-size: 16px; border-radius: 4px;\">Reload App</button>\n          </div>\n        </div>\n      ");
    }
  };
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startApp);
  } else {
    startApp();
  }
}
